import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://dkyhgjuwztkdhucbleei.supabase.co';

// =================================================================================
// !! ==> ACTION REQUIRED: REPLACE THE KEY BELOW <== !!
// =================================================================================
// To connect to your database, you must replace the placeholder text below
// with your actual Supabase 'anon' key.
//
// How to find your key:
// 1. Go to your Supabase project dashboard.
// 2. Click the 'Settings' icon (gear icon) in the left sidebar.
// 3. Click 'API' in the settings list.
// 4. Find the 'anon' 'public' key under 'Project API keys' and copy it.
// 5. Paste it here, replacing 'YOUR_SUPABASE_ANON_KEY_HERE'.
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRreWhnanV3enRrZGh1Y2JsZWVpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg1OTgyMjgsImV4cCI6MjA4NDE3NDIyOH0.V4LgzBMM7ptcT4QOjzuo_l5-HIiAGbleEL9okkem8wU';
// =================================================================================


export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/*
 * =================================================================================
 * == Supabase Table & Security Setup ==
 * =================================================================================
 *
 * You MUST set up your database for this application to work.
 *
 * 1. Go to your Supabase project's "SQL Editor".
 * 2. Click "+ New query".
 * 3. Copy the ENTIRE SQL block below, paste it into the editor, and click "RUN".
 *    It is safe to run this script multiple times.
 *
 *    -- 1. Create the 'submissions' table
 *    CREATE TABLE IF NOT EXISTS public.submissions (
 *      id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
 *      created_at timestamptz DEFAULT now() NOT NULL,
 *      type text,
 *      message text
 *    );
 *
 *    -- 2. Create the 'riders' table
 *    CREATE TABLE IF NOT EXISTS public.riders (
 *        id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
 *        created_at timestamptz DEFAULT now() NOT NULL,
 *        name text NOT NULL,
 *        password text NOT NULL
 *    );
 *
 *    -- 3. Create the 'wholesale_users' table
 *    CREATE TABLE IF NOT EXISTS public.wholesale_users (
 *        id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
 *        created_at timestamptz DEFAULT now() NOT NULL,
 *        business_name text NOT NULL UNIQUE,
 *        password text NOT NULL
 *    );
 *    
 *    -- =================================================================================
 *    -- !! ==> SCHEMA MIGRATIONS & UPDATES <== !!
 *    -- This section ensures your tables have all necessary columns and policies.
 *    -- =================================================================================
 *
 *    -- 4. Add structured columns to 'submissions' table if they don't exist
 *    ALTER TABLE public.submissions
 *    ADD COLUMN IF NOT EXISTS status text DEFAULT 'Pending'::text,
 *    ADD COLUMN IF NOT EXISTS rider_id bigint,
 *    ADD COLUMN IF NOT EXISTS customer_mobile TEXT,
 *    ADD COLUMN IF NOT EXISTS customer_name TEXT,
 *    ADD COLUMN IF NOT EXISTS customer_address TEXT,
 *    ADD COLUMN IF NOT EXISTS customer_pincode TEXT,
 *    ADD COLUMN IF NOT EXISTS total_amount NUMERIC,
 *    ADD COLUMN IF NOT EXISTS payment_method TEXT,
 *    ADD COLUMN IF NOT EXISTS transaction_id TEXT;
 *
 *    -- 5. Add 'contact_number' column to 'riders' table
 *    ALTER TABLE public.riders
 *    ADD COLUMN IF NOT EXISTS contact_number TEXT;
 *
 *    -- 6. Enable Row Level Security (RLS) on tables
 *    ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;
 *    ALTER TABLE public.riders ENABLE ROW LEVEL SECURITY;
 *    ALTER TABLE public.wholesale_users ENABLE ROW LEVEL SECURITY;
 *
 *    -- 7. Create/Replace policies for 'submissions'
 *    DROP POLICY IF EXISTS "Public can insert submissions" ON public.submissions;
 *    CREATE POLICY "Public can insert submissions" ON public.submissions FOR INSERT WITH CHECK (true);
 *    
 *    DROP POLICY IF EXISTS "Anyone can read submissions" ON public.submissions;
 *    CREATE POLICY "Anyone can read submissions" ON public.submissions FOR SELECT USING (true);
 *
 *    DROP POLICY IF EXISTS "Anyone can update submissions" ON public.submissions;
 *    CREATE POLICY "Anyone can update submissions" ON public.submissions FOR UPDATE USING (true) WITH CHECK (true);
 *
 *    -- 8. Create/Replace policies for 'riders' table
 *    DROP POLICY IF EXISTS "Anyone can select riders" ON public.riders;
 *    CREATE POLICY "Anyone can select riders" ON public.riders FOR SELECT USING (true);
 *    
 *    DROP POLICY IF EXISTS "Anyone can insert riders" ON public.riders;
 *    CREATE POLICY "Anyone can insert riders" ON public.riders FOR INSERT WITH CHECK (true);
 *    
 *    DROP POLICY IF EXISTS "Anyone can update riders" ON public.riders;
 *    CREATE POLICY "Anyone can update riders" ON public.riders FOR UPDATE USING (true) WITH CHECK (true);
 *    
 *    DROP POLICY IF EXISTS "Anyone can delete riders" ON public.riders;
 *    CREATE POLICY "Anyone can delete riders" ON public.riders FOR DELETE USING (true);
 *
 *    -- 9. Create/Replace policies for 'wholesale_users' table
 *    DROP POLICY IF EXISTS "Anyone can select wholesale users" ON public.wholesale_users;
 *    CREATE POLICY "Anyone can select wholesale users" ON public.wholesale_users FOR SELECT USING (true);
 *    
 *    DROP POLICY IF EXISTS "Anyone can insert wholesale users" ON public.wholesale_users;
 *    CREATE POLICY "Anyone can insert wholesale users" ON public.wholesale_users FOR INSERT WITH CHECK (true);
 *    
 *    DROP POLICY IF EXISTS "Anyone can update wholesale users" ON public.wholesale_users;
 *    CREATE POLICY "Anyone can update wholesale users" ON public.wholesale_users FOR UPDATE USING (true) WITH CHECK (true);
 *    
 *    DROP POLICY IF EXISTS "Anyone can delete wholesale users" ON public.wholesale_users;
 *    CREATE POLICY "Anyone can delete wholesale users" ON public.wholesale_users FOR DELETE USING (true);
 *
 *    -- 10. Add foreign key constraint to submissions table if it doesn't exist
 *    DO $$
 *    BEGIN
 *      IF NOT EXISTS (
 *        SELECT 1 FROM pg_constraint 
 *        WHERE conname = 'submissions_rider_id_fkey' AND conrelid = 'public.submissions'::regclass
 *      ) THEN
 *        ALTER TABLE public.submissions
 *        ADD CONSTRAINT submissions_rider_id_fkey
 *        FOREIGN KEY (rider_id) REFERENCES public.riders(id) ON DELETE SET NULL;
 *      END IF;
 *    END;
 *    $$;
 *
 *    -- 11. Create the 'wholesale_orders' table
 *    CREATE TABLE IF NOT EXISTS public.wholesale_orders (
 *        id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
 *        created_at timestamptz DEFAULT now() NOT NULL,
 *        wholesale_user_id bigint REFERENCES public.wholesale_users(id) ON DELETE SET NULL,
 *        order_details text NOT NULL,
 *        total_units integer NOT NULL,
 *        total_amount numeric NOT NULL,
 *        status text DEFAULT 'Pending'::text NOT NULL
 *    );
 *
 *    -- 12. Enable RLS for 'wholesale_orders'
 *    ALTER TABLE public.wholesale_orders ENABLE ROW LEVEL SECURITY;
 *
 *    -- 13. Create/Replace policies for 'wholesale_orders'
 *    DROP POLICY IF EXISTS "Anyone can select wholesale orders" ON public.wholesale_orders;
 *    CREATE POLICY "Anyone can select wholesale orders" ON public.wholesale_orders FOR SELECT USING (true);
 *    DROP POLICY IF EXISTS "Anyone can insert wholesale orders" ON public.wholesale_orders;
 *    CREATE POLICY "Anyone can insert wholesale orders" ON public.wholesale_orders FOR INSERT WITH CHECK (true);
 *    DROP POLICY IF EXISTS "Anyone can update wholesale orders" ON public.wholesale_orders;
 *    CREATE POLICY "Anyone can update wholesale orders" ON public.wholesale_orders FOR UPDATE USING (true) WITH CHECK(true);
 *    DROP POLICY IF EXISTS "Anyone can delete wholesale orders" ON public.wholesale_orders;
 *    CREATE POLICY "Anyone can delete wholesale orders" ON public.wholesale_orders FOR DELETE USING (true);
 * 
 *    -- 14. Add rider_id to wholesale_orders table for rider assignment
 *    ALTER TABLE public.wholesale_orders
 *    ADD COLUMN IF NOT EXISTS rider_id bigint;
 *
 *    -- 15. Add foreign key constraint to wholesale_orders table if it doesn't exist
 *    DO $$
 *    BEGIN
 *      IF NOT EXISTS (
 *        SELECT 1 FROM pg_constraint 
 *        WHERE conname = 'wholesale_orders_rider_id_fkey' AND conrelid = 'public.wholesale_orders'::regclass
 *      ) THEN
 *        ALTER TABLE public.wholesale_orders
 *        ADD CONSTRAINT wholesale_orders_rider_id_fkey
 *        FOREIGN KEY (rider_id) REFERENCES public.riders(id) ON DELETE SET NULL;
 *      END IF;
 *    END;
 *    $$;
 *
 *    -- 16. Add contact_number to wholesale_users table
 *    ALTER TABLE public.wholesale_users
 *    ADD COLUMN IF NOT EXISTS contact_number TEXT;
 * =================================================================================
 */