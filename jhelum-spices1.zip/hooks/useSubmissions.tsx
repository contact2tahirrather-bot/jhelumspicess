import React, { createContext, useContext, ReactNode } from 'react';
import { Submission } from '../types';
import { supabase } from '../lib/supabaseClient';
import { useAppContext } from './useAppContext';

interface AddSubmissionResult {
  data: Submission | null;
  error: string | null;
}

interface SubmissionsContextType {
  addSubmission: (submission: Partial<Omit<Submission, 'id' | 'created_at' | 'riders'>>) => Promise<AddSubmissionResult>;
}

const SubmissionsContext = createContext<SubmissionsContextType | undefined>(undefined);

export const useSubmissions = () => {
  const context = useContext(SubmissionsContext);
  if (!context) {
    throw new Error('useSubmissions must be used within a SubmissionsProvider');
  }
  return context;
};

interface SubmissionsProviderProps {
    children: ReactNode;
}

export const SubmissionsProvider: React.FC<SubmissionsProviderProps> = ({ children }) => {
  const { setDbError } = useAppContext();

  const addSubmission = async (submission: Partial<Omit<Submission, 'id' | 'created_at' | 'riders'>>): Promise<AddSubmissionResult> => {
    
    try {
      const submissionData = { ...submission };

      if (submission.type === 'Retail Order' && !submission.status) {
          submissionData.status = 'Pending';
      }

      const { data, error } = await supabase
        .from('submissions')
        .insert([submissionData])
        .select()
        .single();

      if (error) {
        // This is a structured error from Supabase (e.g. RLS violation, column not found)
        // We log it as a warning because the UI is designed to handle it gracefully.
        console.warn('Handled Supabase submission error:', error.message);
        setDbError(error.message);
        return { data: null, error: error.message };
      }
      
      return { data, error: null };

    } catch (e: unknown) {
        // This catches network errors, or other unexpected exceptions
        let errorMessage = 'An unexpected error occurred while saving your submission.';
        if (e instanceof Error) {
            errorMessage = e.message;
        } else if (typeof e === 'string') {
            errorMessage = e;
        }
        
        console.error('Caught submission exception:', errorMessage, e);
        setDbError(errorMessage);
        return { data: null, error: errorMessage };
    }
  };

  return (
    <SubmissionsContext.Provider value={{ addSubmission }}>
      {children}
    </SubmissionsContext.Provider>
  );
};