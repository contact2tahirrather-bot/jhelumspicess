import React, { createContext, useState, useContext, ReactNode } from 'react';
import { CartItem, RetailProduct, ProductSize } from '../types';
import { DISCOUNT_CODES, AUTOMATIC_DISCOUNT_MINIMUM_AMOUNT } from '../constants';

interface ShoppingCartContextType {
  cartItems: CartItem[];
  addToCart: (product: RetailProduct, size: ProductSize, quantity: number) => void;
  removeFromCart: (productId: string, size: string) => void;
  updateQuantity: (productId: string, size: string, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotal: number;
  applyDiscount: (code: string) => { success: boolean; message: string };
  removeDiscount: () => void;
  discountCode: string | null;
  discountAmount: number;
  finalTotal: number;
}

const ShoppingCartContext = createContext<ShoppingCartContextType | undefined>(undefined);

export const useShoppingCart = () => {
  const context = useContext(ShoppingCartContext);
  if (!context) {
    throw new Error('useShoppingCart must be used within a ShoppingCartProvider');
  }
  return context;
};

interface ShoppingCartProviderProps {
    children: ReactNode;
}

export const ShoppingCartProvider: React.FC<ShoppingCartProviderProps> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [discountCode, setDiscountCode] = useState<string | null>(null);

  const cartCount = cartItems.reduce((count, item) => count + item.quantity, 0);
  const cartTotal = cartItems.reduce((total, item) => total + item.size.price * item.quantity, 0);

  const addToCart = (product: RetailProduct, size: ProductSize, quantity: number) => {
    if (quantity <= 0) return;
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.product.id === product.id && item.size.size === size.size);
      if (existingItem) {
        return prevItems.map(item =>
          item.product.id === product.id && item.size.size === size.size
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prevItems, { product, size, quantity }];
    });
  };

  const removeFromCart = (productId: string, size: string) => {
    setCartItems(prevItems => prevItems.filter(item => !(item.product.id === productId && item.size.size === size)));
  };

  const updateQuantity = (productId: string, size: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId, size);
    } else {
      setCartItems(prevItems =>
        prevItems.map(item =>
          item.product.id === productId && item.size.size === size
            ? { ...item, quantity }
            : item
        )
      );
    }
  };

  const removeDiscount = () => {
    setDiscountCode(null);
  };
  
  const clearCart = () => {
    setCartItems([]);
    removeDiscount();
  };

  const applyDiscount = (code: string) => {
    const discount = DISCOUNT_CODES.find(d => d.code.toLowerCase() === code.toLowerCase());

    if (!discount) {
      return { success: false, message: 'Invalid or expired promo code.' };
    }

    if (cartTotal < discount.minimumAmount) {
      return { success: false, message: `Code "${discount.code}" is only valid for orders over ₹${discount.minimumAmount}.` };
    }
    
    setDiscountCode(discount.code);
    return { success: true, message: `Success! ${discount.description} applied.` };
  };

  const appliedDiscount = discountCode ? DISCOUNT_CODES.find(d => d.code.toLowerCase() === discountCode.toLowerCase()) : null;

  let discountAmount = 0;
  let isDiscountValid = false;
  
  if (appliedDiscount && cartTotal >= appliedDiscount.minimumAmount) {
    discountAmount = cartTotal * appliedDiscount.percentage;
    isDiscountValid = true;
  }
  
  const finalTotal = cartTotal - discountAmount;

  return (
    <ShoppingCartContext.Provider value={{ 
        cartItems, 
        addToCart, 
        removeFromCart, 
        updateQuantity, 
        clearCart, 
        cartCount, 
        cartTotal,
        applyDiscount,
        removeDiscount,
        discountCode: isDiscountValid ? discountCode : null,
        discountAmount,
        finalTotal,
    }}>
      {children}
    </ShoppingCartContext.Provider>
  );
};