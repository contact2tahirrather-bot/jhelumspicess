export const translations = {
    // Mode Selection Screen
    modeSelection: {
        welcome: { en: 'Welcome', ur: 'خوش آمدید' },
        to: { en: 'to', ur: 'میں' },
        tagline: { en: 'Ghar ka Bharosa', ur: 'گھر کا بھروسہ' },
        retailTitle: { en: 'Retail', ur: 'ریٹیل' },
        retailSubtitle: { en: 'For home cooking', ur: 'گھریلو کھانا پکانے کے لیے' },
        wholesaleTitle: { en: 'Wholesale', ur: 'تھوک' },
        wholesaleSubtitle: { en: 'For businesses & resellers', ur: 'کاروبار اور ری سیلرز کے لیے' },
        wazwanTitle: { en: 'Wazwan', ur: 'وازوان' },
        wazwanSubtitle: { en: 'For events & bulk orders', ur: 'تقریبات اور بلک آرڈرز کے لیے' },
        trackTitle: { en: 'Track Order', ur: 'آرڈر ٹریک کریں' },
        trackSubtitle: { en: 'Check your delivery status', ur: 'اپنے ڈیلیوری کا اسٹیٹس چیک کریں' },
        feedbackTitle: { en: 'Give Feedback', ur: 'رائے دیں' },
        feedbackSubtitle: { en: 'Share your experience', ur: 'اپنا تجربہ شیئر کریں' },
        supportTitle: { en: 'Customer Support', ur: 'کسٹمر سپورٹ' },
        supportSubtitle: { en: 'Get help or ask a question', ur: 'مدد حاصل کریں یا سوال پوچھیں' },
    },

    // Headers
    header: {
        productCatalog: { en: 'Product Catalog', ur: 'پروڈکٹ کیٹلاگ' },
        yourCart: { en: 'Your Cart', ur: 'آپ کی کارٹ' },
        checkout: { en: 'Checkout', ur: 'چیک آؤٹ' },
        completePayment: { en: 'Complete Payment', ur: 'ادائیگی مکمل کریں' },
        orderSuccess: { en: 'Order Submitted', ur: 'آرڈر جمع ہوگیا' },
        wholesaleAccess: { en: 'Wholesale Access', ur: 'تھوک رسائی' },
        wholesalePortal: { en: 'Wholesale Portal', ur: 'تھوک پورٹل' },
        wazwanEnquiry: { en: 'Wazwan & Event Enquiry', ur: 'وازوان اور ایونٹ انکوائری' },
        enquirySubmitted: { en: 'Enquiry Submitted', ur: 'انکوائری جمع ہوگئی' },
        trackYourOrder: { en: 'Track Your Order', ur: 'اپنا آرڈر ٹریک کریں' },
        yourOrders: { en: 'Your Orders', ur: 'آپ کے آرڈرز' },
        giveFeedback: { en: 'Give Feedback', ur: 'رائے دیں' },
        feedbackSent: { en: 'Feedback Sent', ur: 'رائے بھیج دی گئی' },
        customerSupport: { en: 'Customer Support', ur: 'کسٹمر سپورٹ' },
        querySent: { en: 'Query Sent', ur: 'سوال بھیج دیا گیا' },
    },

    // Footer
    footer: {
        tagline: { en: 'Premium Quality, Small Batch', ur: 'پریمیم کوالٹی، چھوٹے بیچ' },
        emailLabel: { en: 'Email', ur: 'ای میل' },
        supportLabel: { en: 'Support', ur: 'سپورٹ' },
        followUs: { en: 'Follow Us', ur: 'ہمیں فالو کریں' },
        rightsReserved: { en: 'All rights reserved.', ur: 'جملہ حقوق محفوظ ہیں' },
    },
    
    // Retail Screen Specific
    retail: {
        powderSpices: { en: 'Powder Spices', ur: 'پاؤڈر مصالحے' },
        wholeSpices: { en: 'Whole Spices', ur: 'ثابت مصالحے' },
    },

    // Products
    products: {
        r1: { name: { en: 'Red Chilli Powder', ur: 'لال مرچ پاؤڈر' }, description: { en: 'Vibrant and fiery, perfect for adding a kick to any dish.', ur: 'متحرک اور تیز، کسی بھی ڈش میں ذائقہ شامل کرنے کے لیے بہترین۔' } },
        r2: { name: { en: 'Turmeric Powder', ur: 'ہلدی پاؤڈر' }, description: { en: 'Golden and aromatic, a staple for color and medicinal properties.', ur: 'سنہری اور خوشبودار، رنگ اور طبی خصوصیات کے لیے ایک اہم جزو۔' } },
        r3: { name: { en: 'Coriander Powder', ur: 'دھنیا پاؤڈر' }, description: { en: 'Mild and earthy (also known as Dhania), adds a fresh, citrusy flavor to dishes.', ur: 'ہلکا اور مٹی والا (دھنیا بھی کہا جاتا ہے)، ڈشوں میں ایک تازہ، کھٹا ذائقہ شامل کرتا ہے۔' } },
        r4: { name: { en: 'Garam Masala', ur: 'گرم مسالہ' }, description: { en: 'A warm and aromatic blend of ground spices for authentic Indian flavor.', ur: 'مستند بھارتی ذائقے کے لیے پسے ہوئے مسالوں کا ایک گرم اور خوشبودار مرکب۔' } },
        r5: { name: { en: 'Kashmiri Mirch Powder', ur: 'کشمیری مرچ پاؤڈر' }, description: { en: 'Known for its vibrant red color and mild heat.', ur: 'اپنے متحرک سرخ رنگ اور ہلکی تیزی کے لیے جانا جاتا ہے۔' } },
        r6: { name: { en: 'Tez Patta (Bay Leaves)', ur: 'تیز پتہ' }, description: { en: 'Aromatic leaves that add a distinct flavor to rice and curries.', ur: 'خوشبودار پتے جو چاول اور سالن میں ایک مخصوص ذائقہ شامل کرتے ہیں۔' } },
        r7: { name: { en: 'Black Cardamom (Badi Elaichi)', ur: 'کالی الائچی' }, description: { en: 'Smoky and intense, perfect for rich and savory dishes.', ur: 'دھواں دار اور شدید، بھرپور اور مزیدار ڈشوں کے لیے بہترین۔' } },
        r8: { name: { en: 'Dry Ginger Powder (Saunth)', ur: 'سونٹھ پاؤڈر' }, description: { en: 'Pungent and spicy, adds a warming kick to teas and curries.', ur: 'تیز اور مسالیدار، چائے اور سالن میں گرمی کا احساس دلاتا ہے۔' } },
        r9: { name: { en: 'Cumin Seeds (Zeera)', ur: 'زیرہ' }, description: { en: 'Earthy and warm, a fundamental spice in many cuisines.', ur: 'مٹی والا اور گرم، بہت سے کھانوں میں ایک بنیادی مسالہ۔' } },
        r10: { name: { en: 'Clove (Laung)', ur: 'لونگ' }, description: { en: 'Aromatic and sweet, great for baking and savory dishes.', ur: 'خوشبودار اور میٹھا، بیکنگ اور مزیدار ڈشوں کے لیے بہترین۔' } },
        r11: { name: { en: 'Black Pepper (Whole)', ur: 'کالی مرچ (ثابت)' }, description: { en: 'Pungent and flavorful peppercorns for fresh grinding.', ur: 'تازہ پیسنے کے لیے تیز اور ذائقہ دار کالی مرچ۔' } },
        r12: { name: { en: 'Cinnamon Stick (Dalchini)', ur: 'دار چینی' }, description: { en: 'Sweet and woody, perfect for both sweet and savory recipes.', ur: 'میٹھی اور لکڑی جیسی، میٹھے اور نمکین دونوں قسم کی ترکیبوں کے لیے بہترین۔' } },
        r13: { name: { en: 'Hing (Asafoetida)', ur: 'ہینگ' }, description: { en: 'A strong, pungent spice that mellows into a savory flavor when cooked.', ur: 'ایک مضبوط، تیز مسالہ جو پکانے پر ایک مزیدار ذائقے میں بدل جاتا ہے۔' } },
        r14: { name: { en: 'Star Anise (Chakra Phool)', ur: 'بادیان کا پھول' }, description: { en: 'Licorice-like flavor, essential for biryanis and garam masala.', ur: 'ملٹھی جیسا ذائقہ، بریانی اور گرم مسالے کے لیے ضروری ہے۔' } },
        r15: { name: { en: 'Chicken Masala', ur: 'چکن مسالہ' }, description: { en: 'A special blend to create flavorful and aromatic chicken curries.', ur: 'ذائقہ دار اور خوشبودار چکن سالن بنانے کے لیے ایک خاص مرکب۔' } },
        r16: { name: { en: 'Meat Masala', ur: 'گوشت مسالہ' }, description: { en: 'A robust spice mix for rich and hearty meat dishes.', ur: 'بھرپور اور لذیذ گوشت کے پکوان کے لیے ایک مضبوط مسالے کا مکس۔' } },
        r17: { name: { en: 'Biryani Masala', ur: 'بریانی مسالہ' }, description: { en: 'An exquisite blend of aromatic spices for crafting the perfect biryani.', ur: 'کامل بریانی تیار کرنے کے لیے خوشبودار مسالوں کا ایک عمدہ مرکب۔' } },
        r18: { name: { en: 'Kitchen King Masala', ur: 'کچن کنگ مسالہ' }, description: { en: 'The king of all masalas, a versatile blend for everyday cooking.', ur: 'تمام مسالوں کا بادشاہ، روزمرہ کے کھانا پکانے کے لیے ایک ورسٹائل مرکب۔' } },
        r19: { name: { en: 'Fennel Powder (Saunf)', ur: 'سونف پاؤڈر' }, description: { en: 'Sweet and aromatic, perfect as a digestive and for flavoring curries.', ur: 'میٹھا اور خوشبودار، ہاضمے کے طور پر اور سالن کو ذائقہ دینے کے لیے بہترین۔' } },
        r20: { name: { en: 'Kasuri Methi', ur: 'قصوری میتھی' }, description: { en: 'Dried fenugreek leaves with a distinctive, savory flavor for finishing dishes.', ur: 'خشک میتھی کے پتے ایک مخصوص، لذیذ ذائقے کے ساتھ پکوان کو مکمل کرنے کے لیے۔' } },
        r21: { name: { en: 'Mint (Pudina)', ur: 'پودینہ' }, description: { en: 'Cool and refreshing dried mint leaves, ideal for chutneys, raitas, and beverages.', ur: 'ٹھنڈے اور تازگی بخش خشک پودینے کے پتے، چٹنیوں، رائتوں اور مشروبات کے لیے مثالی۔' } },
        r22: { name: { en: 'Green Cardamom (Elaichi)', ur: 'سبز الائچی' }, description: { en: 'Aromatic and versatile, perfect for sweets, teas, and savory dishes.', ur: 'خوشبودار اور ورسٹائل، مٹھائیوں، چائے اور لذیذ پکوانوں کے لیے بہترین۔' } },
        r23: { name: { en: 'Black Pepper Powder', ur: 'کالی مرچ پاؤڈر' }, description: { en: 'Finely ground black pepper for a sharp, pungent flavor.', ur: 'تیز، تیکھے ذائقے کے لیے باریک پسی ہوئی کالی مرچ۔' } },
    }
};