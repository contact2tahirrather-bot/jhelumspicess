import React from 'react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = 'w-48 h-48' }) => {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <img 
        src="https://i.postimg.cc/mZSG4rBj/file_00000000c38871fa9bf8b04eafd7acbe.png" 
        alt="Jhelum Spices Logo" 
        className="object-contain w-full h-full"
      />
    </div>
  );
};

export default Logo;