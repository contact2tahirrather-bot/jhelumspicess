import React from 'react';
import { FSSAI_NUMBER, ADMIN_WHATSAPP_NUMBER } from '../constants';
import { useLanguage } from '../hooks/useLanguage';

const InstagramIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.252-.148-4.771-1.691-4.919-4.919-.058-1.265-.069-1.645-.069-4.85s.011-3.584.069-4.85c.149-3.225 1.664 4.771 4.919-4.919 1.266-.058 1.644-.07 4.85-.07zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948s.014 3.667.072 4.947c.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072s3.667-.014 4.947-.072c4.358-.2 6.78-2.618 6.98-6.98.059-1.281.073-1.689.073-4.948s-.014-3.667-.072-4.947c-.2-4.358-2.618-6.78-6.98-6.98-1.281-.058-1.689-.072-4.948-.072zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.162 6.162 6.162 6.162-2.759 6.162-6.162-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.79 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.441 1.441 1.441 1.441-.645 1.441-1.441-.645-1.44-1.441-1.44z"/>
    </svg>
);
const FacebookIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
        <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v2.385z"/>
    </svg>
);
const WhatsAppIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
        <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.894 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 4.315 1.847 6.033l-1.011 3.713 3.717-1.005zm-2.905-7.446c-.187-.306-.307-.514-.424-.514h-.105c-.117 0-.273.085-.411.272-.136.186-.532.512-.532 1.229 0 .718.544 1.424.618 1.522.072.099 1.03 1.636 2.512 2.213.37.142.66.187.82.232.26.072.518.062.71.037.217-.037.533-.217.604-.424s.072-.466.05-.514c-.02-.048-.117-.073-.254-.121-.137-.048-1.29-.636-1.492-.707-.202-.072-.347-.121-.492.121-.121.22-.492.707-.604.832-.113.125-.226.142-.37.099-.144-.043-.631-.237-1.2-.742-.44-.389-.723-.886-.811-1.034s-.089-.225-.011-.347c.079-.121.166-.202.226-.263.06-.062.121-.107.18-.182.06-.075.03-.125-.01-.182-.04-.058-.493-1.176-.673-1.612z" />
    </svg>
);
const YouTubeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
        <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
    </svg>
);


const Footer: React.FC = () => {
  const { t } = useLanguage();
  const formattedSupportNumber = `+${ADMIN_WHATSAPP_NUMBER.slice(0, 2)} ${ADMIN_WHATSAPP_NUMBER.slice(2, 7)} ${ADMIN_WHATSAPP_NUMBER.slice(7)}`;
  return (
    <footer className="bg-gray-100 text-center p-6 border-t border-gray-200">
      <p className="text-lg font-semibold text-gray-800">Jhelum Spices</p>
      <p className="text-sm text-gray-600 mt-1">{t('footer.tagline', 'Premium Quality, Small Batch')}</p>

      <div className="mt-6 text-sm text-gray-700 space-y-2">
        <p>
            {t('footer.emailLabel', 'Email')}: <a href="mailto:jhelumspices4u@gmail.com" className="font-semibold hover:text-red-600">jhelumspices4u@gmail.com</a>
        </p>
        <p>
            {t('footer.supportLabel', 'Support')}: <a href={`tel:+${ADMIN_WHATSAPP_NUMBER}`} className="font-semibold hover:text-red-600">{formattedSupportNumber}</a>
        </p>
      </div>

      <div className="mt-6">
        <p className="text-sm font-medium text-gray-800 mb-3">{t('footer.followUs', 'Follow Us')}</p>
        <div className="flex justify-center items-center gap-6 text-gray-600">
          <a href="https://www.instagram.com/jhelumspices?igsh=MWxnM3VjOTFkNXIxaQ%3D%3D" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="hover:text-pink-500 transition-colors">
            <InstagramIcon />
          </a>
          <a href="https://www.facebook.com/profile.php?id=61586647872699" target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="hover:text-blue-600 transition-colors">
            <FacebookIcon />
          </a>
          <a href={`https://wa.me/${ADMIN_WHATSAPP_NUMBER}`} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="hover:text-green-500 transition-colors">
            <WhatsAppIcon />
          </a>
          <a href="https://www.youtube.com/@JhelumSpices" target="_blank" rel="noopener noreferrer" aria-label="YouTube" className="hover:text-red-600 transition-colors">
            <YouTubeIcon />
          </a>
        </div>
      </div>
      
      <div className="mt-6 text-xs text-gray-500 space-y-1">
        <p>FSSAI No: {FSSAI_NUMBER}</p>
        <p>&copy; {new Date().getFullYear()} Jhelum Spices. {t('footer.rightsReserved', 'All rights reserved.')}</p>
      </div>
    </footer>
  );
};

export default Footer;