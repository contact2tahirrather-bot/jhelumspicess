import React from 'react';
import { ADMIN_WHATSAPP_NUMBER } from '../constants';

const RetailFooter: React.FC = () => {
  const formattedSupportNumber = `+${ADMIN_WHATSAPP_NUMBER.slice(0, 2)} ${ADMIN_WHATSAPP_NUMBER.slice(2, 7)} ${ADMIN_WHATSAPP_NUMBER.slice(7)}`;
  return (
    <footer className="bg-gray-100 text-center p-4 border-t border-gray-200">
      <div className="text-sm text-gray-700 space-y-1">
        <p>
            Need help? Email: <a href="mailto:jhelumspices4u@gmail.com" className="font-semibold hover:text-red-600">jhelumspices4u@gmail.com</a>
        </p>
        <p>
            Or call Support: <a href={`tel:+${ADMIN_WHATSAPP_NUMBER}`} className="font-semibold hover:text-red-600">{formattedSupportNumber}</a>
        </p>
      </div>
    </footer>
  );
};

export default RetailFooter;