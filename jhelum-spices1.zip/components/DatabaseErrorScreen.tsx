import React from 'react';

// The full SQL script from lib/supabaseClient.ts
const SETUP_SQL = `/*
 * =================================================================================
 * == Supabase Table & Security Setup ==
 * =================================================================================
 *
 * You MUST set up your database for this application to work.
 *
 * 1. Go to your Supabase project's "SQL Editor".
 * 2. Click "+ New query".
 * 3. Copy the ENTIRE SQL block below, paste it into the editor, and click "RUN".
 *    It is safe to run this script multiple times.
 */

-- 1. Create the 'submissions' table
CREATE TABLE IF NOT EXISTS public.submissions (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  created_at timestamptz DEFAULT now() NOT NULL,
  type text,
  message text
);

-- 2. Create the 'riders' table
CREATE TABLE IF NOT EXISTS public.riders (
    id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    created_at timestamptz DEFAULT now() NOT NULL,
    name text NOT NULL,
    password text NOT NULL
);

-- 3. Create the 'wholesale_users' table
CREATE TABLE IF NOT EXISTS public.wholesale_users (
    id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    created_at timestamptz DEFAULT now() NOT NULL,
    business_name text NOT NULL UNIQUE,
    password text NOT NULL
);

-- =================================================================================
-- !! ==> SCHEMA MIGRATIONS & UPDATES <== !!
-- This section ensures your tables have all necessary columns and policies.
-- =================================================================================

-- 4. Add structured columns to 'submissions' table if they don't exist
ALTER TABLE public.submissions
ADD COLUMN IF NOT EXISTS status text DEFAULT 'Pending'::text,
ADD COLUMN IF NOT EXISTS rider_id bigint,
ADD COLUMN IF NOT EXISTS customer_mobile TEXT,
ADD COLUMN IF NOT EXISTS customer_name TEXT,
ADD COLUMN IF NOT EXISTS customer_address TEXT,
ADD COLUMN IF NOT EXISTS customer_pincode TEXT,
ADD COLUMN IF NOT EXISTS total_amount NUMERIC,
ADD COLUMN IF NOT EXISTS payment_method TEXT,
ADD COLUMN IF NOT EXISTS transaction_id TEXT;

-- 5. Add 'contact_number' column to 'riders' table
ALTER TABLE public.riders
ADD COLUMN IF NOT EXISTS contact_number TEXT;

-- 6. Enable Row Level Security (RLS) on tables
ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wholesale_users ENABLE ROW LEVEL SECURITY;

-- 7. Create/Replace policies for 'submissions'
DROP POLICY IF EXISTS "Public can insert submissions" ON public.submissions;
CREATE POLICY "Public can insert submissions" ON public.submissions FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Anyone can read submissions" ON public.submissions;
CREATE POLICY "Anyone can read submissions" ON public.submissions FOR SELECT USING (true);

DROP POLICY IF EXISTS "Anyone can update submissions" ON public.submissions;
CREATE POLICY "Anyone can update submissions" ON public.submissions FOR UPDATE USING (true) WITH CHECK (true);

-- 8. Create/Replace policies for 'riders' table
DROP POLICY IF EXISTS "Anyone can select riders" ON public.riders;
CREATE POLICY "Anyone can select riders" ON public.riders FOR SELECT USING (true);

DROP POLICY IF EXISTS "Anyone can insert riders" ON public.riders;
CREATE POLICY "Anyone can insert riders" ON public.riders FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Anyone can update riders" ON public.riders;
CREATE POLICY "Anyone can update riders" ON public.riders FOR UPDATE USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Anyone can delete riders" ON public.riders;
CREATE POLICY "Anyone can delete riders" ON public.riders FOR DELETE USING (true);

-- 9. Create/Replace policies for 'wholesale_users' table
DROP POLICY IF EXISTS "Anyone can select wholesale users" ON public.wholesale_users;
CREATE POLICY "Anyone can select wholesale users" ON public.wholesale_users FOR SELECT USING (true);

DROP POLICY IF EXISTS "Anyone can insert wholesale users" ON public.wholesale_users;
CREATE POLICY "Anyone can insert wholesale users" ON public.wholesale_users FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Anyone can update wholesale users" ON public.wholesale_users;
CREATE POLICY "Anyone can update wholesale users" ON public.wholesale_users FOR UPDATE USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Anyone can delete wholesale users" ON public.wholesale_users;
CREATE POLICY "Anyone can delete wholesale users" ON public.wholesale_users FOR DELETE USING (true);

-- 10. Add foreign key constraint to submissions table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'submissions_rider_id_fkey' AND conrelid = 'public.submissions'::regclass
  ) THEN
    ALTER TABLE public.submissions
    ADD CONSTRAINT submissions_rider_id_fkey
    FOREIGN KEY (rider_id) REFERENCES public.riders(id) ON DELETE SET NULL;
  END IF;
END;
$$;

-- 11. Create the 'wholesale_orders' table
CREATE TABLE IF NOT EXISTS public.wholesale_orders (
    id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    created_at timestamptz DEFAULT now() NOT NULL,
    wholesale_user_id bigint REFERENCES public.wholesale_users(id) ON DELETE SET NULL,
    order_details text NOT NULL,
    total_units integer NOT NULL,
    total_amount numeric NOT NULL,
    status text DEFAULT 'Pending'::text NOT NULL
);

-- 12. Enable RLS for 'wholesale_orders'
ALTER TABLE public.wholesale_orders ENABLE ROW LEVEL SECURITY;

-- 13. Create/Replace policies for 'wholesale_orders'
DROP POLICY IF EXISTS "Anyone can select wholesale orders" ON public.wholesale_orders;
CREATE POLICY "Anyone can select wholesale orders" ON public.wholesale_orders FOR SELECT USING (true);
DROP POLICY IF EXISTS "Anyone can insert wholesale orders" ON public.wholesale_orders;
CREATE POLICY "Anyone can insert wholesale orders" ON public.wholesale_orders FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Anyone can update wholesale orders" ON public.wholesale_orders;
CREATE POLICY "Anyone can update wholesale orders" ON public.wholesale_orders FOR UPDATE USING (true) WITH CHECK(true);
DROP POLICY IF EXISTS "Anyone can delete wholesale orders" ON public.wholesale_orders;
CREATE POLICY "Anyone can delete wholesale orders" ON public.wholesale_orders FOR DELETE USING (true);

-- 14. Add rider_id to wholesale_orders table for rider assignment
ALTER TABLE public.wholesale_orders
ADD COLUMN IF NOT EXISTS rider_id bigint;

-- 15. Add foreign key constraint to wholesale_orders table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'wholesale_orders_rider_id_fkey' AND conrelid = 'public.wholesale_orders'::regclass
  ) THEN
    ALTER TABLE public.wholesale_orders
    ADD CONSTRAINT wholesale_orders_rider_id_fkey
    FOREIGN KEY (rider_id) REFERENCES public.riders(id) ON DELETE SET NULL;
  END IF;
END;
$$;

-- 16. Add contact_number to wholesale_users table
ALTER TABLE public.wholesale_users
ADD COLUMN IF NOT EXISTS contact_number TEXT;
`;

interface DatabaseErrorScreenProps {
  error: string;
  onClose: () => void;
}

const DatabaseErrorScreen: React.FC<DatabaseErrorScreenProps> = ({ error, onClose }) => {
    
    const getDiagnosis = () => {
        const lowerError = error.toLowerCase();
        
        if (lowerError.includes("column") && (lowerError.includes("does not exist") || lowerError.includes("could not find"))) {
            // Try to extract the column name for a more helpful message
            const match = error.match(/column "([^"]+)" of relation|Could not find the '([^']+)' column/);
            const columnName = match ? match[1] || match[2] : null;

            if (columnName) {
                return `Your app code is ahead of your database schema. The column "${columnName}" is missing from a table.`;
            }
            return "Your app code is ahead of your database schema. A required column is missing from a table.";
        }

        if (lowerError.includes("relation") && (lowerError.includes("does not exist") || lowerError.includes("could not find"))) {
            return "A required database table (e.g., 'submissions', 'riders', 'wholesale_users') is missing.";
        }
        if (lowerError.includes("permission denied") || lowerError.includes("rls")) {
            return "Database security rules (Row Level Security) are preventing the app from saving data.";
        }
        if (lowerError.includes("fetch")) {
            return "There might be a network issue or a problem with your Supabase URL/Key in `lib/supabaseClient.ts`.";
        }
        return "An unexpected database error occurred."
    }

    const handleCopy = () => {
        navigator.clipboard.writeText(SETUP_SQL)
            .then(() => alert('SQL script copied to clipboard!'))
            .catch(err => alert('Failed to copy script. Please copy it manually.'));
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col">
                <header className="p-4 border-b bg-orange-50">
                    <h2 className="text-xl font-bold text-orange-800">Database Update Required</h2>
                </header>

                <main className="p-6 overflow-y-auto space-y-4">
                    <div>
                        <h3 className="font-semibold text-gray-800">Diagnosis:</h3>
                        <p className="mt-1 text-sm text-orange-700 bg-orange-50 p-3 rounded-md">{getDiagnosis()}</p>
                    </div>

                    <div>
                        <h3 className="font-semibold text-gray-800">Solution:</h3>
                        <p className="mt-1 text-sm text-gray-600">
                            This is expected after an app update! To sync your database, please run the complete setup script below in your Supabase SQL Editor.
                        </p>
                        <ol className="mt-2 text-sm list-decimal list-inside space-y-1">
                            <li>Go to your <a href="https://app.supabase.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">Supabase Project</a>.</li>
                            <li>Navigate to the <strong>SQL Editor</strong> section.</li>
                            <li>Click <strong>"+ New query"</strong>.</li>
                            <li>Copy the entire script below and paste it into the editor.</li>
                            <li>Click <strong>"RUN"</strong>. It's safe to run this multiple times.</li>
                        </ol>
                    </div>

                    <div className="relative">
                        <button onClick={handleCopy} className="absolute top-2 right-2 bg-gray-700 text-white text-xs font-semibold py-1 px-2 rounded hover:bg-gray-800">Copy</button>
                        <pre className="bg-gray-900 text-white p-4 rounded-md text-xs max-h-60 overflow-auto font-mono">
                            <code>
                                {SETUP_SQL}
                            </code>
                        </pre>
                    </div>
                    <div>
                        <h3 className="font-semibold text-gray-800">Original Error Message:</h3>
                        <p className="mt-1 text-xs text-gray-500 font-mono bg-gray-100 p-2 rounded-md">{error}</p>
                    </div>
                </main>

                <footer className="p-4 border-t bg-gray-50 text-right">
                    <button onClick={onClose} className="bg-orange-600 text-white font-semibold py-2 px-6 rounded-lg hover:bg-orange-700 transition-colors">
                        Close
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default DatabaseErrorScreen;