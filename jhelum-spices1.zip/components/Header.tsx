

import React from 'react';
import { useLanguage } from '../hooks/useLanguage';

interface HeaderProps {
  title: string;
  onBack: () => void;
  rightContent?: React.ReactNode;
  hideLanguageSwitcher?: boolean;
}

const LanguageSwitcher: React.FC = () => {
  const { language, setLanguage } = useLanguage();
  const toggleLanguage = () => setLanguage(language === 'en' ? 'ur' : 'en');

  return (
    <button
      onClick={toggleLanguage}
      className="text-sm font-semibold text-blue-600 hover:text-blue-800 p-2 rounded-md transition-colors bg-blue-100/50"
      aria-label="Change language"
    >
      {language === 'en' ? 'اردو' : 'English'}
    </button>
  );
};

const Header: React.FC<HeaderProps> = ({ title, onBack, rightContent, hideLanguageSwitcher = false }) => {
  const { t } = useLanguage();
  
  return (
    <header className="sticky top-0 bg-white/80 backdrop-blur-lg border-b border-gray-200 p-4 z-10 flex items-center justify-between">
      <button onClick={onBack} className="p-2 -ml-2 text-gray-600 hover:text-red-600 transition-colors">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
      </button>
      <h1 className="text-xl font-semibold text-gray-800 tracking-tight">{t(title, title)}</h1>
      <div className="flex items-center gap-2">
        {rightContent}
        {!hideLanguageSwitcher ? <LanguageSwitcher /> : <div className="w-6 h-6"></div>}
      </div>
    </header>
  );
};

export default Header;