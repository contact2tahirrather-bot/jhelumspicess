import { RetailProduct, WholesaleProduct, WholesaleProductSize, WazwanProduct } from './types';

export const ADMIN_WHATSAPP_NUMBER = '918491968873';
export const ADMIN_PASSWORD = 'TahirAdmin@2026.jhelumallspices';
export const FSSAI_NUMBER = '12345678901234';

export const AUTOMATIC_DISCOUNT_MINIMUM_AMOUNT = 499;

export const DISCOUNT_CODES = [
  {
    code: 'TahirMtech',
    percentage: 0.08,
    minimumAmount: 0, 
    description: '8% off'
  },
  {
    code: 'SPECIALOFFER10',
    percentage: 0.06,
    minimumAmount: AUTOMATIC_DISCOUNT_MINIMUM_AMOUNT,
    description: '6% off'
  }
];


const claims = {
  pure: 'Pure',
  fresh: 'Fresh',
  noColor: 'No Artificial Colour',
  smallBatch: 'Small Batch',
  premium: 'Premium Quality',
};

// ==========================================================
// ==> PRODUCT IMAGE URLS
// ==========================================================
// Using the brand logo as a consistent placeholder for all products.
const PRODUCT_IMAGE_URL = 'https://i.postimg.cc/mZSG4rBj/file_00000000c38871fa9bf8b04eafd7acbe.png';

// ==========================================================
// ==> RETAIL PRODUCT SIZES & PRICING
// ==========================================================

const standardMasalaSizes45 = [
  { size: '50g', price: 45 },
  { size: '100g', price: 90 },
];

const masalaSizes70 = [
  { size: '50g', price: 70 },
  { size: '100g', price: 140 },
];

const chilliSizes = [
  { size: '100g', price: 60 },
  { size: '250g', price: 150 },
  { size: '500g', price: 300 },
];

const turmericSizes = [
  { size: '100g', price: 50 },
  { size: '250g', price: 125 },
  { size: '500g', price: 250 },
];

const tezPattaSizes = [
  { size: '50g', price: 40 },
];

const blackCardamomSizes = [
  { size: '25g', price: 60 },
];

const greenCardamomSizes = [
  { size: '25g', price: 90 },
];

const dryGingerPowderSizes = [
  { size: '50g', price: 50 },
  { size: '100g', price: 100 },
];

const cuminSeedsSizes = [
  { size: '50g', price: 50 },
];

const cloveSizes = [
    { size: '50g', price: 60 },
];

const blackPepperSizes25g = [
    { size: '25g', price: 60 },
];

const blackPepperPowderSizes = [
    { size: '50g', price: 110 },
];

const cinnamonStickSizes = [
    { size: '50g', price: 65 },
];

const hingSizes = [
    { size: '25g', price: 60 },
];

const starAniseSizes = [
    { size: '50g', price: 75 },
];

const kasooriMethiSizes = [
  { size: '25g', price: 40 },
];

const mintSizes = [
  { size: '50g', price: 60 },
];


export const RETAIL_PRODUCTS_POWDER: RetailProduct[] = [
  {
    id: 'r1',
    name: 'Red Chilli Powder',
    description: 'Vibrant and fiery, perfect for adding a kick to any dish.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.pure, claims.fresh, claims.noColor],
    sizes: chilliSizes,
  },
  {
    id: 'r2',
    name: 'Turmeric Powder',
    description: 'Golden and aromatic, a staple for color and medicinal properties.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.pure, claims.fresh, claims.noColor],
    sizes: turmericSizes,
  },
  {
    id: 'r3',
    name: 'Coriander Powder',
    description: 'Mild and earthy (also known as Dhania), adds a fresh, citrusy flavor to dishes.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.pure, claims.fresh, claims.smallBatch],
    sizes: standardMasalaSizes45,
  },
  {
    id: 'r4',
    name: 'Garam Masala',
    description: 'A warm and aromatic blend of ground spices for authentic Indian flavor.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.fresh, claims.smallBatch],
    sizes: standardMasalaSizes45,
  },
  {
    id: 'r5',
    name: 'Kashmiri Mirch Powder',
    description: 'Known for its vibrant red color and mild heat.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.noColor, claims.fresh],
    sizes: chilliSizes,
  },
  {
    id: 'r8',
    name: 'Dry Ginger Powder (Saunth)',
    description: 'Pungent and spicy, adds a warming kick to teas and curries.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.pure, claims.fresh],
    sizes: dryGingerPowderSizes,
  },
  {
    id: 'r15',
    name: 'Chicken Masala',
    description: 'A special blend to create flavorful and aromatic chicken curries.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.smallBatch, claims.fresh],
    sizes: masalaSizes70,
  },
  {
    id: 'r16',
    name: 'Meat Masala',
    description: 'A robust spice mix for rich and hearty meat dishes.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.smallBatch, claims.fresh],
    sizes: masalaSizes70,
  },
  {
    id: 'r17',
    name: 'Biryani Masala',
    description: 'An exquisite blend of aromatic spices for crafting the perfect biryani.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.smallBatch],
    sizes: masalaSizes70,
  },
  {
    id: 'r18',
    name: 'Kitchen King Masala',
    description: 'The king of all masalas, a versatile blend for everyday cooking.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.smallBatch, claims.fresh],
    sizes: masalaSizes70,
  },
  {
    id: 'r19',
    name: 'Fennel Powder (Saunf)',
    description: 'Sweet and aromatic, perfect as a digestive and for flavoring curries.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.pure, claims.fresh],
    sizes: standardMasalaSizes45,
  },
  {
    id: 'r23',
    name: 'Black Pepper Powder',
    description: 'Finely ground black pepper for a sharp, pungent flavor.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.fresh],
    sizes: blackPepperPowderSizes,
  },
];

export const RETAIL_PRODUCTS_WHOLE: RetailProduct[] = [
  {
    id: 'r6',
    name: 'Tez Patta (Bay Leaves)',
    description: 'Aromatic leaves that add a distinct flavor to rice and curries.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.fresh, claims.premium],
    sizes: tezPattaSizes,
  },
  {
    id: 'r7',
    name: 'Black Cardamom (Badi Elaichi)',
    description: 'Smoky and intense, perfect for rich and savory dishes.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.fresh],
    sizes: blackCardamomSizes,
  },
  {
    id: 'r9',
    name: 'Cumin Seeds (Zeera)',
    description: 'Earthy and warm, a fundamental spice in many cuisines.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.pure, claims.fresh],
    sizes: cuminSeedsSizes,
  },
  {
    id: 'r10',
    name: 'Clove (Laung)',
    description: 'Aromatic and sweet, great for baking and savory dishes.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.fresh],
    sizes: cloveSizes,
  },
  {
    id: 'r11',
    name: 'Black Pepper (Whole)',
    description: 'Pungent and flavorful peppercorns for fresh grinding.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.fresh],
    sizes: blackPepperSizes25g,
  },
  {
    id: 'r12',
    name: 'Cinnamon Stick (Dalchini)',
    description: 'Sweet and woody, perfect for both sweet and savory recipes.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.fresh],
    sizes: cinnamonStickSizes,
  },
  {
    id: 'r13',
    name: 'Hing (Asafoetida)',
    description: 'A strong, pungent spice that mellows into a savory flavor when cooked.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.pure, claims.premium],
    sizes: hingSizes,
  },
  {
    id: 'r14',
    name: 'Star Anise (Chakra Phool)',
    description: 'Licorice-like flavor, essential for biryanis and garam masala.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.fresh],
    sizes: starAniseSizes,
  },
  {
    id: 'r20',
    name: 'Kasuri Methi',
    description: 'Dried fenugreek leaves with a distinctive, savory flavor for finishing dishes.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.fresh],
    sizes: kasooriMethiSizes,
  },
  {
    id: 'r21',
    name: 'Mint (Pudina)',
    description: 'Cool and refreshing dried mint leaves, ideal for chutneys, raitas, and beverages.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.pure, claims.fresh],
    sizes: mintSizes,
  },
  {
    id: 'r22',
    name: 'Green Cardamom (Elaichi)',
    description: 'Aromatic and versatile, perfect for sweets, teas, and savory dishes.',
    imageUrl: PRODUCT_IMAGE_URL,
    claims: [claims.premium, claims.fresh],
    sizes: greenCardamomSizes,
  },
];

export const RETAIL_PRODUCTS: RetailProduct[] = [...RETAIL_PRODUCTS_POWDER, ...RETAIL_PRODUCTS_WHOLE].sort((a,b) => a.id.localeCompare(b.id, undefined, {numeric: true}));


// ==========================================================
// ==> WHOLESALE PRODUCTS
// ==========================================================

const getWholesaleSizes = (retailSizes: {size: string, price: number}[]): WholesaleProductSize[] => {
  const largestRetailSize = retailSizes[retailSizes.length - 1];
  const weightInGrams = parseInt(largestRetailSize.size, 10);
  
  if (weightInGrams >= 500) {
    return [{ size: '1kg', price: Math.round(largestRetailSize.price * 1.8), moq: 5 }];
  }
  if (weightInGrams >= 100) {
    return [{ size: '500g', price: Math.round(largestRetailSize.price * 4.5), moq: 5 }];
  }
  return [{ size: '250g', price: Math.round(largestRetailSize.price * 4), moq: 5 }];
};

export const WHOLESALE_PRODUCTS: WholesaleProduct[] = RETAIL_PRODUCTS.map(p => ({
  id: `w-${p.id}`,
  name: p.name,
  description: p.description,
  imageUrl: p.imageUrl,
  claims: p.claims,
  sizes: getWholesaleSizes(p.sizes),
}));


// ==========================================================
// ==> WAZWAN PRODUCTS
// ==========================================================

export const WAZWAN_PRODUCTS: WazwanProduct[] = [
    {
        id: 'wz1',
        name: 'Authentic Wazwan Experience',
        description: 'Complete spice solutions for traditional Kashmiri Wazwan. We provide custom blends and quantities for your events.',
        imageUrl: PRODUCT_IMAGE_URL,
        claims: [claims.premium, claims.smallBatch, 'Authentic Recipe'],
        bulkOnly: true,
    }
];