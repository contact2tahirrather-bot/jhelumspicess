export enum UserMode {
  RETAIL = 'RETAIL',
  WHOLESALE = 'WHOLESALE',
  WAZWAN = 'WAZWAN',
  ADMIN = 'ADMIN',
  RIDER = 'RIDER',
  TRACK = 'TRACK',
  FEEDBACK = 'FEEDBACK',
  SUPPORT = 'SUPPORT',
}

export interface ProductSize {
  size: string;
  price: number;
}

export interface WholesaleProductSize extends ProductSize {
  moq: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  claims: string[];
}

export interface RetailProduct extends Product {
  sizes: ProductSize[];
}

export interface WholesaleProduct extends Product {
  sizes: WholesaleProductSize[];
}

export interface WazwanProduct extends Product {
  bulkOnly: boolean;
}

export interface CartItem {
  product: RetailProduct;
  size: ProductSize;
  quantity: number;
}

export type OrderStatus = 'Pending' | 'Pending Payment Confirmation' | 'Processing' | 'Out for Delivery' | 'Delivered';

export interface Submission {
  id: number;
  type: 'Retail Order' | 'Wholesale Application' | 'Wazwan Enquiry' | 'Wholesale Enquiry' | 'Feedback' | 'Customer Support';
  message: string;
  created_at: string;
  status?: OrderStatus;
  rider_id?: number | null;
  riders?: { name: string; contact_number?: string | null; } | null; // For joined data from Supabase
  
  // Structured data for Retail Orders
  customer_mobile?: string;
  customer_name?: string;
  customer_address?: string;
  customer_pincode?: string;
  total_amount?: number;
  payment_method?: string;
  transaction_id?: string;
}

export interface Rider {
  id: number;
  name: string;
  password: string;
  created_at: string;
  contact_number?: string | null;
}

export interface WholesaleUser {
  id: number;
  business_name: string;
  password: string;
  created_at: string;
  contact_number?: string | null;
  total_units_ordered?: number;
}

export type WholesaleOrderStatus = 'Pending' | 'Confirmed' | 'Out for Delivery' | 'Delivered' | 'Cancelled';

export interface WholesaleOrder {
  id: number;
  created_at: string;
  wholesale_user_id: number;
  wholesale_users?: WholesaleUser | null;
  order_details: string;
  total_units: number;
  total_amount: number;
  status: WholesaleOrderStatus;
  rider_id?: number | null;
  riders?: { name: string; contact_number?: string | null } | null;
}

export type TrackedOrder = (Submission & { orderType: 'Retail' }) | (WholesaleOrder & { orderType: 'Wholesale' });