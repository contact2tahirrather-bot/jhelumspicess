import React, { useState } from 'react';
import { UserMode } from './types';
import ModeSelectionScreen from './screens/ModeSelectionScreen';
import RetailFlow from './screens/retail/RetailFlow';
import WholesaleFlow from './screens/wholesale/WholesaleFlow';
import WazwanFlow from './screens/wazwan/WazwanFlow';
import AdminFlow from './screens/admin/AdminFlow';
import RiderFlow from './screens/rider/RiderFlow';
import TrackOrderFlow from './screens/track/TrackOrderFlow';
import FeedbackFlow from './screens/feedback/FeedbackFlow';
import SupportFlow from './screens/support/SupportFlow';
import { ShoppingCartProvider } from './hooks/useShoppingCart';
import { SubmissionsProvider } from './hooks/useSubmissions';
import { AppProvider } from './hooks/useAppContext';
import DatabaseErrorScreen from './components/DatabaseErrorScreen';
import { LanguageProvider, useLanguage } from './hooks/useLanguage';

const AppContent: React.FC = () => {
  const [mode, setMode] = useState<UserMode | null>(null);
  const [dbError, setDbError] = useState<string | null>(null);
  const { language } = useLanguage();

  const handleModeSelect = (selectedMode: UserMode) => {
    setMode(selectedMode);
  };
  
  const resetMode = () => {
    setMode(null);
  };

  const renderContent = () => {
    switch (mode) {
      case UserMode.RETAIL:
        return <RetailFlow onBackToHome={resetMode} />;
      case UserMode.WHOLESALE:
        return <WholesaleFlow onBackToHome={resetMode} />;
      case UserMode.WAZWAN:
        return <WazwanFlow onBackToHome={resetMode} />;
      case UserMode.ADMIN:
        return <AdminFlow onBackToHome={resetMode} />;
      case UserMode.RIDER:
        return <RiderFlow onBackToHome={resetMode} />;
      case UserMode.TRACK:
        return <TrackOrderFlow onBackToHome={resetMode} />;
       case UserMode.FEEDBACK:
        return <FeedbackFlow onBackToHome={resetMode} />;
       case UserMode.SUPPORT:
        return <SupportFlow onBackToHome={resetMode} />;
      default:
        return <ModeSelectionScreen onModeSelect={handleModeSelect} />;
    }
  };

  return (
    <AppProvider value={{ setDbError }}>
      <SubmissionsProvider>
        <ShoppingCartProvider>
          <div className="bg-gray-50 min-h-screen text-gray-800 antialiased" dir={language === 'ur' ? 'rtl' : 'ltr'}>
            <div className="container mx-auto max-w-lg p-0 bg-white min-h-screen shadow-2xl">
              {dbError && <DatabaseErrorScreen error={dbError} onClose={() => setDbError(null)} />}
              {renderContent()}
            </div>
          </div>
        </ShoppingCartProvider>
      </SubmissionsProvider>
    </AppProvider>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}
