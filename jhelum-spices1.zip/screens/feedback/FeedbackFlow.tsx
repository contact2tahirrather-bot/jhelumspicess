import React from 'react';
import FeedbackScreen from './FeedbackScreen';

interface FeedbackFlowProps {
  onBackToHome: () => void;
}

const FeedbackFlow: React.FC<FeedbackFlowProps> = ({ onBackToHome }) => {
  return <FeedbackScreen onBack={onBackToHome} />;
};

export default FeedbackFlow;
