import React, { useState } from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import { useSubmissions } from '../../hooks/useSubmissions';
import { ADMIN_WHATSAPP_NUMBER } from '../../constants';

interface FeedbackScreenProps {
  onBack: () => void;
}

const StarRating: React.FC<{ rating: number; setRating: (rating: number) => void }> = ({ rating, setRating }) => {
    return (
        <div className="flex justify-center space-x-2">
            {[1, 2, 3, 4, 5].map((star) => (
                <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="focus:outline-none"
                    aria-label={`Rate ${star} out of 5 stars`}
                >
                    <svg
                        className={`w-10 h-10 transition-colors ${
                            star <= rating ? 'text-yellow-400' : 'text-gray-300'
                        }`}
                        fill="currentColor"
                        viewBox="0 0 20 20"
                    >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                </button>
            ))}
        </div>
    );
};


const FeedbackScreen: React.FC<FeedbackScreenProps> = ({ onBack }) => {
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [rating, setRating] = useState(0);
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { addSubmission } = useSubmissions();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) {
        alert('Please select a star rating.');
        return;
    }
    if (!message.trim()) {
        alert('Please enter your feedback message.');
        return;
    }

    setIsSubmitting(true);
    
    const ratingStars = '★'.repeat(rating) + '☆'.repeat(5 - rating);

    const feedbackMessage = `
New Customer Feedback!

*Rating:* ${ratingStars} (${rating}/5)
*Name:* ${name.trim() || 'Not provided'}
*Contact:* ${contact.trim() || 'Not provided'}

*Feedback:*
${message.trim()}
    `.trim().replace(/\n\s*\n/g, '\n\n');

    const { data, error } = await addSubmission({ type: 'Feedback', message: feedbackMessage });

    if (data) {
        const whatsappUrl = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(feedbackMessage)}`;
        window.open(whatsappUrl, '_blank');
        setIsSubmitted(true);
    }
    // Error is handled globally by the App context
    setIsSubmitting(false);
  };
  
  if (isSubmitted) {
    return (
      <div className="flex flex-col h-screen bg-gray-50">
        <Header title="Feedback Sent" onBack={onBack} />
        <div className="flex-grow flex flex-col items-center justify-center text-center p-6">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h2 className="mt-4 text-2xl font-bold text-gray-800">Thank you for your feedback!</h2>
          <p className="mt-2 text-gray-600 max-w-sm">
            We value your opinion and will use it to improve our products and services.
          </p>
          <button onClick={onBack} className="mt-8 bg-purple-600 text-white font-semibold py-2 px-6 rounded-lg hover:bg-purple-700 transition-colors">
            Back to Home
          </button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen">
      <Header title="Give Feedback" onBack={onBack} />
      <main className="flex-grow overflow-y-auto p-6 bg-gray-50">
        <div className="p-4 mb-6 bg-purple-50 border-l-4 border-purple-500 rounded-r-lg">
          <h2 className="font-bold text-purple-900">We Value Your Opinion</h2>
          <p className="text-sm text-purple-800 mt-1">
            Your feedback helps us improve. Please share your experience with our products and services.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-center text-sm font-medium text-gray-700 mb-2">How would you rate your experience?</label>
            <StarRating rating={rating} setRating={setRating} />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-gray-700">Your Feedback</label>
            <textarea
              id="message"
              rows={5}
              required
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell us what you think..."
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
            ></textarea>
          </div>
           <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">Your Name (Optional)</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <div>
            <label htmlFor="contact" className="block text-sm font-medium text-gray-700">Contact (Optional)</label>
            <input
              type="text"
              id="contact"
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              placeholder="Mobile or Email"
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-purple-600 text-white font-semibold py-3 rounded-lg hover:bg-purple-700 transition-colors disabled:bg-gray-400"
          >
            {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
          </button>
        </form>
      </main>
      <Footer />
    </div>
  );
};

export default FeedbackScreen;
