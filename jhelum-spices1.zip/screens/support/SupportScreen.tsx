import React, { useState } from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import { useSubmissions } from '../../hooks/useSubmissions';
import { ADMIN_WHATSAPP_NUMBER } from '../../constants';

interface SupportScreenProps {
  onBack: () => void;
}

const SupportScreen: React.FC<SupportScreenProps> = ({ onBack }) => {
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { addSubmission } = useSubmissions();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) {
        alert('Please enter your query or message.');
        return;
    }

    setIsSubmitting(true);
    
    const supportMessage = `
New Customer Support Query!

*Name:* ${name.trim() || 'Not provided'}
*Contact:* ${contact.trim() || 'Not provided'}

*Query:*
${message.trim()}
    `.trim().replace(/\n\s*\n/g, '\n\n');

    const { data, error } = await addSubmission({ type: 'Customer Support', message: supportMessage });

    if (data) {
        const whatsappUrl = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(supportMessage)}`;
        window.open(whatsappUrl, '_blank');
        setIsSubmitted(true);
    }
    // Error is handled globally by the App context
    setIsSubmitting(false);
  };
  
  if (isSubmitted) {
    return (
      <div className="flex flex-col h-screen bg-gray-50">
        <Header title="Query Sent" onBack={onBack} />
        <div className="flex-grow flex flex-col items-center justify-center text-center p-6">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h2 className="mt-4 text-2xl font-bold text-gray-800">Thank you for reaching out!</h2>
          <p className="mt-2 text-gray-600 max-w-sm">
            Your message has been sent. Our support team will get back to you as soon as possible.
          </p>
          <button onClick={onBack} className="mt-8 bg-orange-600 text-white font-semibold py-2 px-6 rounded-lg hover:bg-orange-700 transition-colors">
            Back to Home
          </button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen">
      <Header title="Customer Support" onBack={onBack} />
      <main className="flex-grow overflow-y-auto p-6 bg-gray-50">
        <div className="p-4 mb-6 bg-orange-50 border-l-4 border-orange-500 rounded-r-lg">
          <h2 className="font-bold text-orange-900">How can we help?</h2>
          <p className="text-sm text-orange-800 mt-1">
            Have a question about your order, our products, or anything else? Fill out the form below and we'll get in touch.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-gray-700">Your Query</label>
            <textarea
              id="message"
              rows={5}
              required
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Please describe your issue or question..."
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500"
            ></textarea>
          </div>
           <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">Your Name (Optional)</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500"
            />
          </div>
          <div>
            <label htmlFor="contact" className="block text-sm font-medium text-gray-700">Contact (Optional)</label>
            <input
              type="text"
              id="contact"
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              placeholder="Mobile or Email"
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500"
            />
          </div>
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-orange-600 text-white font-semibold py-3 rounded-lg hover:bg-orange-700 transition-colors disabled:bg-gray-400"
          >
            {isSubmitting ? 'Submitting...' : 'Send Support Query'}
          </button>
        </form>
      </main>
      <Footer />
    </div>
  );
};

export default SupportScreen;
