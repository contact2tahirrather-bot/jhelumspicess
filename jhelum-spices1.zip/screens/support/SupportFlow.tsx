import React from 'react';
import SupportScreen from './SupportScreen';

interface SupportFlowProps {
  onBackToHome: () => void;
}

const SupportFlow: React.FC<SupportFlowProps> = ({ onBackToHome }) => {
  return <SupportScreen onBack={onBackToHome} />;
};

export default SupportFlow;
