import React from 'react';
import Header from '../../components/Header';
import { Submission, OrderStatus, TrackedOrder, WholesaleOrder, WholesaleOrderStatus } from '../../types';
import { ADMIN_WHATSAPP_NUMBER } from '../../constants';

const retailStatusLevels: OrderStatus[] = ['Pending', 'Processing', 'Out for Delivery', 'Delivered'];
const wholesaleStatusLevels: WholesaleOrderStatus[] = ['Pending', 'Confirmed', 'Out for Delivery', 'Delivered'];


const StatusStep: React.FC<{
    title: string;
    description: React.ReactNode;
    isCompleted: boolean;
    isCurrent: boolean;
    isFirst: boolean;
    isLast: boolean;
    color: 'red' | 'blue';
}> = ({ title, description, isCompleted, isCurrent, isFirst, isLast, color }) => {
    
    const colorClasses = {
        red: {
            bg: 'bg-red-600',
            border: 'border-red-600',
        },
        blue: {
            bg: 'bg-blue-600',
            border: 'border-blue-600',
        }
    };
    
    const activeColor = colorClasses[color];

    let iconClasses = `h-10 w-10 rounded-full flex items-center justify-center ${isCompleted || isCurrent ? activeColor.bg : 'bg-gray-300 border-2 border-white'}`;

    return (
        <div className="relative flex items-start">
            {!isFirst && <div className={`absolute top-0 left-5 -ml-px mt-2 h-full w-0.5 ${isCompleted || isCurrent ? activeColor.bg : 'bg-gray-300'}`}></div>}
            <div className="flex-shrink-0">
                <div className={iconClasses}>
                    {isCompleted ? (
                         <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                    ) : (
                        <span className={`h-3 w-3 rounded-full ${isCurrent ? 'bg-white' : 'bg-gray-400'}`}></span>
                    )}
                </div>
            </div>
            <div className="ml-4 pt-1.5">
                <h3 className={`text-lg font-semibold ${isCompleted || isCurrent ? 'text-gray-800' : 'text-gray-500'}`}>{title}</h3>
                <p className="mt-1 text-sm text-gray-600">{description}</p>
            </div>
        </div>
    );
};


const RetailOrderStatusTimeline: React.FC<{ order: Submission }> = ({ order }) => {
    const currentStatus = order.status || 'Pending';
    const currentStatusIndex = retailStatusLevels.indexOf(currentStatus);
    
    const riderName = order.riders?.name;
    const riderContact = order.riders?.contact_number;
    const canEdit = currentStatus === 'Pending' || currentStatus === 'Processing';

    const handleEditOrder = () => {
        const message = `Hello Jhelum Spices,\n\nI would like to request a change to my Order ID: #${order.id}.\n\nPlease let me know what changes are possible. Thank you.`;
        const whatsappUrl = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
    };

    const getStatusDescription = (status: OrderStatus): React.ReactNode => {
        switch(status) {
            case 'Pending': return 'We have received your order.';
            case 'Processing': return 'Our team is preparing your spices with care.';
            case 'Out for Delivery':
                if (riderName && riderContact) {
                    return <>Your order is on its way! Rider: {riderName} (Contact: <a href={`tel:${riderContact}`} className="text-blue-600 font-semibold hover:underline">{riderContact}</a>).</>;
                }
                return `Your order is on its way! Rider: ${riderName || 'Assigned'}.`;
            case 'Delivered': return `Your order has been delivered by ${order.riders?.name || 'our rider'}. Enjoy!`;
            default: return '';
        }
    }
    
    return (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-xl font-bold text-gray-800">Retail Order #{order.id}</h2>
            <p className="text-gray-600 mt-1 text-sm">Placed on: {new Date(order.created_at).toLocaleString()}</p>
            
            <div className="mt-6 space-y-8">
                {retailStatusLevels.map((status, index) => (
                    <StatusStep
                        key={status}
                        title={status}
                        description={getStatusDescription(status)}
                        isCompleted={index < currentStatusIndex}
                        isCurrent={index === currentStatusIndex}
                        isFirst={index === 0}
                        isLast={index === retailStatusLevels.length - 1}
                        color="red"
                    />
                ))}
            </div>

            {canEdit && (
                <div className="mt-8 pt-6 border-t border-gray-200">
                     <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400 rounded-r-lg">
                        <h4 className="font-semibold text-yellow-900">Need to make a change?</h4>
                        <p className="text-sm text-yellow-800 mt-1">You can request changes to your order until it's out for delivery.</p>
                        <button onClick={handleEditOrder} className="mt-3 w-full bg-yellow-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-yellow-600 transition-colors flex items-center justify-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>
                            <span>Request Edit via WhatsApp</span>
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}

const WholesaleOrderStatusTimeline: React.FC<{ order: WholesaleOrder }> = ({ order }) => {
    const currentStatus = order.status;
    const currentStatusIndex = wholesaleStatusLevels.indexOf(currentStatus);
    
    const riderName = order.riders?.name;
    const riderContact = order.riders?.contact_number;

    const getStatusDescription = (status: WholesaleOrderStatus): React.ReactNode => {
        switch(status) {
            case 'Pending': return 'We have received your order request and will review it shortly.';
            case 'Confirmed': return 'Your order has been confirmed and is being prepared.';
            case 'Out for Delivery':
                if (riderName && riderContact) {
                    return <>Your order is on its way! Rider: {riderName} (Contact: <a href={`tel:${riderContact}`} className="text-blue-600 font-semibold hover:underline">{riderContact}</a>).</>;
                }
                return `Your order is on its way! Rider: ${riderName || 'Assigned'}.`;
            case 'Delivered': return `Your order has been delivered by ${order.riders?.name || 'our rider'}. Thank you!`;
            default: return '';
        }
    }
    
    return (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-xl font-bold text-gray-800">Wholesale Order #{order.id}</h2>
            <p className="text-gray-600 mt-1 text-sm">For: <span className="font-semibold">{order.wholesale_users?.business_name || 'N/A'}</span></p>
            <p className="text-gray-600 text-sm">Placed on: {new Date(order.created_at).toLocaleString()}</p>
            
            {order.status === 'Cancelled' ? (
                <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg text-center">
                    <h3 className="text-lg font-semibold text-red-800">Order Cancelled</h3>
                    <p className="text-sm text-red-700 mt-1">Please contact us for more details about this order.</p>
                </div>
            ) : (
                <div className="mt-6 space-y-8">
                    {wholesaleStatusLevels.map((status, index) => (
                        <StatusStep
                            key={status}
                            title={status}
                            description={getStatusDescription(status)}
                            isCompleted={index < currentStatusIndex}
                            isCurrent={index === currentStatusIndex}
                            isFirst={index === 0}
                            isLast={index === wholesaleStatusLevels.length - 1}
                            color="blue"
                        />
                    ))}
                </div>
            )}
        </div>
    );
}


interface TrackOrderResultsScreenProps {
  onBack: () => void;
  orders: TrackedOrder[];
}

const TrackOrderResultsScreen: React.FC<TrackOrderResultsScreenProps> = ({ onBack, orders }) => {
    return (
        <div className="flex flex-col h-screen bg-gray-50">
            <Header title={`Your Orders (${orders.length})`} onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-4 md:p-6 space-y-6">
                {orders.map(order => {
                    if (order.orderType === 'Retail') {
                        return <RetailOrderStatusTimeline key={`retail-${order.id}`} order={order} />;
                    } else {
                        return <WholesaleOrderStatusTimeline key={`wholesale-${order.id}`} order={order} />;
                    }
                })}
            </main>
        </div>
    );
};

export default TrackOrderResultsScreen;