import React, { useState } from 'react';
import Header from '../../components/Header';
import Logo from '../../components/Logo';
import { TrackedOrder } from '../../types';
import { supabase } from '../../lib/supabaseClient';

interface TrackOrderInputScreenProps {
  onBack: () => void;
  onOrdersFound: (orders: TrackedOrder[]) => void;
}

const TrackOrderInputScreen: React.FC<TrackOrderInputScreenProps> = ({ onBack, onOrdersFound }) => {
  const [mobile, setMobile] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleMobileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Allow only digits, and limit to 10 characters
    if (/^\d*$/.test(value) && value.length <= 10) {
      setMobile(value);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedMobile = mobile.trim();
    
    if (trimmedMobile.length !== 10) {
      setError('Please enter a valid 10-digit mobile number.');
      return;
    }
    
    setLoading(true);
    
    const [retailRes, wholesaleRes] = await Promise.all([
      // 1. Find retail orders
      supabase
        .from('submissions')
        .select('*, riders(*)')
        .eq('type', 'Retail Order')
        .or(`customer_mobile.like.%${trimmedMobile},message.like.%Mobile: ${trimmedMobile}%`),
      // 2. Find wholesale orders by joining through wholesale_users
      supabase
        .from('wholesale_orders')
        .select('*, wholesale_users(*), riders(*)')
        .eq('wholesale_users.contact_number', trimmedMobile)
    ]);

    setLoading(false);

    if (retailRes.error || wholesaleRes.error) {
      setError('Could not fetch order status. Please try again later.');
      console.error('Retail tracking error:', retailRes.error);
      console.error('Wholesale tracking error:', wholesaleRes.error);
    } else {
      const retailOrders = (retailRes.data || []).map(o => ({ ...o, orderType: 'Retail' as const }));
      const wholesaleOrders = (wholesaleRes.data || []).map(o => ({ ...o, orderType: 'Wholesale' as const }));

      const allOrders: TrackedOrder[] = [...retailOrders, ...wholesaleOrders];

      if (allOrders.length === 0) {
        setError('No orders found for this mobile number.');
      } else {
        // Sort all found orders by creation date, descending
        allOrders.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        onOrdersFound(allOrders);
      }
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="Track Your Order" onBack={onBack} />
      <main className="flex-grow flex flex-col items-center justify-center p-6 text-center">
        <Logo className="w-24 h-24" />
        <h2 className="text-2xl font-bold text-gray-800 mt-4">Check Order Status</h2>
        <p className="text-gray-600 mt-2 max-w-xs">Enter your 10-digit mobile number to track your retail or wholesale orders.</p>

        <form onSubmit={handleSubmit} className="w-full max-w-xs mt-8 space-y-4">
          <div>
            <label htmlFor="mobile" className="block text-sm font-medium text-gray-700 sr-only">Mobile Number</label>
            <input
              type="tel"
              id="mobile"
              value={mobile}
              onChange={handleMobileChange}
              className="mt-1 block w-full text-center border-gray-300 rounded-md shadow-sm focus:ring-red-500 focus:border-red-500 text-lg p-2"
              placeholder="9876543210"
              required
            />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-red-600 text-white font-semibold py-2 rounded-lg hover:bg-red-700 transition-colors disabled:bg-gray-400"
          >
            {loading ? 'Searching...' : 'Track Order'}
          </button>
        </form>
      </main>
    </div>
  );
};

export default TrackOrderInputScreen;