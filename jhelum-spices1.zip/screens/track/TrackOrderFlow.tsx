import React, { useState } from 'react';
import TrackOrderInputScreen from './TrackOrderInputScreen';
import TrackOrderResultsScreen from './TrackOrderStatusScreen';
import { TrackedOrder } from '../../types';

interface TrackOrderFlowProps {
  onBackToHome: () => void;
}

const TrackOrderFlow: React.FC<TrackOrderFlowProps> = ({ onBackToHome }) => {
  const [foundOrders, setFoundOrders] = useState<TrackedOrder[] | null>(null);

  if (foundOrders) {
    return <TrackOrderResultsScreen orders={foundOrders} onBack={() => setFoundOrders(null)} />;
  }

  return <TrackOrderInputScreen onBack={onBackToHome} onOrdersFound={setFoundOrders} />;
};

export default TrackOrderFlow;