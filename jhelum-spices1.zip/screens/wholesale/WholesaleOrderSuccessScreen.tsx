import React from 'react';
import { WholesaleOrder } from '../../types';
import RetailFooter from '../../components/RetailFooter';

interface WholesaleOrderSuccessScreenProps {
  order: WholesaleOrder;
  onBack: () => void;
}

const WholesaleOrderSuccessScreen: React.FC<WholesaleOrderSuccessScreenProps> = ({ order, onBack }) => {
  return (
    <div className="flex flex-col h-screen bg-white">
      <main className="flex-grow flex flex-col items-center justify-center text-center p-6">
        <div className="bg-green-100 p-4 rounded-full">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </div>
        <h1 className="mt-6 text-3xl font-bold text-gray-800">Order Request Sent!</h1>
        <p className="mt-3 text-lg text-gray-600 max-w-md">
          Thank you! Your order request has been received.
        </p>
        
        {order.id && (
            <div className="mt-6 text-center">
                <p className="text-sm text-gray-600">Your Order ID is:</p>
                <p className="text-2xl font-bold text-blue-600 bg-blue-50 border border-blue-200 rounded-lg px-4 py-2 mt-1 inline-block">
                    #{order.id}
                </p>
                <p className="text-xs text-gray-500 mt-2">Use this ID for any communication with us.</p>
            </div>
        )}

        <div className="mt-8 text-sm text-gray-500 bg-gray-50 p-4 rounded-lg border border-gray-200 max-w-md space-y-3">
           <h2 className="font-semibold text-gray-700">What's Next?</h2>
            <p>
                Our team will review your order and contact you via your registered number to confirm availability and payment details.
            </p>
             <p className="pt-3 border-t border-gray-200">
                You can track the status of this order in the "Your Order History" section on the main dashboard. You will also receive WhatsApp notifications for major status updates.
            </p>
            <p className="font-medium text-gray-600">
                Need to make a change? You can request edits by contacting us directly until your order status is 'Confirmed'.
            </p>
        </div>
        <button onClick={onBack} className="mt-8 bg-blue-600 text-white font-semibold py-3 px-8 rounded-lg hover:bg-blue-700 transition-colors">
          Back to Dashboard
        </button>
      </main>
      <RetailFooter />
    </div>
  );
};

export default WholesaleOrderSuccessScreen;