import React, { useState } from 'react';
import WholesaleLoginScreen from './WholesaleLoginScreen';
import WholesaleHomeScreen from './WholesaleHomeScreen';
import { WholesaleUser } from '../../types';

interface WholesaleFlowProps {
  onBackToHome: () => void;
}

const WholesaleFlow: React.FC<WholesaleFlowProps> = ({ onBackToHome }) => {
  const [loggedInUser, setLoggedInUser] = useState<WholesaleUser | null>(null);

  const handleLoginSuccess = (user: WholesaleUser) => {
    // The simulation is removed. We just pass the user object.
    // WholesaleHomeScreen will handle fetching real order data for rewards.
    setLoggedInUser(user);
  };

  if (loggedInUser) {
    return <WholesaleHomeScreen user={loggedInUser} onBack={onBackToHome} />;
  }
  
  return <WholesaleLoginScreen onBack={onBackToHome} onLoginSuccess={handleLoginSuccess} />;
};

export default WholesaleFlow;