import React, { useState, useMemo, useEffect } from 'react';
import { WHOLESALE_PRODUCTS } from '../../constants';
import Header from '../../components/Header';
import RetailFooter from '../../components/RetailFooter';
import { WholesaleProduct, WholesaleUser, WholesaleOrder, WholesaleOrderStatus } from '../../types';
import { ADMIN_WHATSAPP_NUMBER } from '../../constants';
import { useSubmissions } from '../../hooks/useSubmissions';
import { supabase } from '../../lib/supabaseClient';
import WholesaleOrderSuccessScreen from './WholesaleOrderSuccessScreen';
import { useLanguage } from '../../hooks/useLanguage';

interface WholesaleHomeScreenProps {
  onBack: () => void;
  user: WholesaleUser;
}

interface OrderSummaryModalProps {
  orderQuantities: Record<string, number>;
  onClose: () => void;
  onOrderPlaced: (newOrder: WholesaleOrder) => void;
  user: WholesaleUser;
}

// Define Reward Tiers with secret gifts
const REWARD_TIERS = [
  { goal: 1000, name: 'Tier 1 Reward', reward: 'Unlock a special surprise gift from us!', icon: '🎁' },
  { goal: 10000, name: 'Tier 2 Reward', reward: 'Another exciting mystery reward is waiting for you.', icon: '🎁' },
  { goal: 20000, name: 'Tier 3 Reward', reward: 'A premium gift to celebrate our partnership.', icon: '🎁' },
  { goal: 40000, name: 'Tier 4 Reward', reward: 'A special token of our appreciation awaits.', icon: '🎁' },
  { goal: 50000, name: 'Tier 5 Reward', reward: 'You\'re a valued partner! An exclusive gift is nearby.', icon: '🎁' },
  { goal: 100000, name: 'Tier 6 Reward', reward: 'Unlock our most exclusive secret reward!', icon: '🎁' },
  { goal: 200000, name: 'Tier 7 Reward', reward: 'A significant milestone deserves a significant reward.', icon: '🎁' },
  { goal: 300000, name: 'Tier 8 Reward', reward: 'Celebrating your continued growth with us.', icon: '🎁' },
  { goal: 400000, name: 'Tier 9 Reward', reward: 'An exceptional reward for an exceptional partner.', icon: '🎁' },
  { goal: 500000, name: 'Tier 10 Reward', reward: 'The ultimate partner reward. Thank you for your loyalty.', icon: '🎁' },
];

const wholesaleStatusLevels: WholesaleOrderStatus[] = ['Pending', 'Confirmed', 'Out for Delivery', 'Delivered'];

const WholesaleOrderStatusTimeline: React.FC<{ order: WholesaleOrder }> = ({ order }) => {
    const currentStatus = order.status;
    const currentStatusIndex = wholesaleStatusLevels.indexOf(currentStatus);
    
    const riderName = order.riders?.name;
    const riderContact = order.riders?.contact_number;

    const getStatusDescription = (status: WholesaleOrderStatus): React.ReactNode => {
        switch(status) {
            case 'Pending': return 'We have received your order request and will review it shortly.';
            case 'Confirmed': return 'Your order has been confirmed. We are now preparing your items.';
            case 'Out for Delivery':
                if (riderName && riderContact) {
                    return (
                        <>
                            Your order is on its way! Rider: {riderName} (Contact:{' '}
                            <a href={`tel:${riderContact}`} className="text-blue-600 font-semibold hover:underline">
                                {riderContact}
                            </a>
                            ).
                        </>
                    );
                } else if (riderName) {
                    return `Your order is on its way! Rider: ${riderName}.`;
                }
                return 'Your order is on its way!';
            case 'Delivered': 
                return 'Your order has been delivered. Thank you for your business!';
            default: return '';
        }
    }
    
    return (
        <div className="mt-4 pt-4 border-t border-gray-200">
            {currentStatus === 'Cancelled' ? (
                <div className="p-3 bg-red-50 border border-red-200 rounded-md text-center">
                    <h3 className="text-lg font-semibold text-red-800">Order Cancelled</h3>
                    <p className="text-sm text-red-700 mt-1">Please contact us for more details.</p>
                </div>
            ) : (
                <div className="space-y-6">
                    {wholesaleStatusLevels.map((status, index) => {
                         const isCompleted = index < currentStatusIndex;
                         const isCurrent = index === currentStatusIndex;
                         return (
                            <div key={status} className="relative flex items-start">
                                {index > 0 && <div className={`absolute top-0 left-4 -ml-px mt-1 h-full w-0.5 ${isCompleted || isCurrent ? 'bg-blue-600' : 'bg-gray-300'}`}></div>}
                                <div className="flex-shrink-0">
                                    <div className={`h-8 w-8 rounded-full flex items-center justify-center ${isCompleted || isCurrent ? 'bg-blue-600' : 'bg-gray-300 border-2 border-white'}`}>
                                        {isCompleted ? (
                                            <svg className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                                        ) : (
                                            <span className={`h-2.5 w-2.5 rounded-full ${isCurrent ? 'bg-white' : 'bg-gray-400'}`}></span>
                                        )}
                                    </div>
                                </div>
                                <div className="ml-3 pt-0.5">
                                    <h3 className={`text-md font-semibold ${isCompleted || isCurrent ? 'text-gray-800' : 'text-gray-500'}`}>{status}</h3>
                                    <p className="mt-1 text-sm text-gray-600">{getStatusDescription(status)}</p>
                                </div>
                            </div>
                         )
                    })}
                </div>
            )}
        </div>
    );
};


const OrderHistory: React.FC<{ user: WholesaleUser }> = ({ user }) => {
  const [history, setHistory] = useState<WholesaleOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedOrderId, setExpandedOrderId] = useState<number | null>(null);

  useEffect(() => {
    const fetchHistory = async () => {
      setLoading(true);
      setError(null);
      const { data, error } = await supabase
        .from('wholesale_orders')
        .select('*, riders(name, contact_number)')
        .eq('wholesale_user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error("Failed to fetch order history:", error.message);
        setError("Could not load your order history. Please try again later.");
      } else {
        setHistory(data || []);
      }
      setLoading(false);
    };

    fetchHistory();
  }, [user.id]);
  
  const StatusBadge: React.FC<{ status: WholesaleOrderStatus }> = ({ status }) => {
    const colors: Record<WholesaleOrderStatus, string> = {
        'Pending': 'bg-gray-100 text-gray-800',
        'Confirmed': 'bg-yellow-100 text-yellow-800',
        'Out for Delivery': 'bg-blue-100 text-blue-800',
        'Delivered': 'bg-green-100 text-green-800',
        'Cancelled': 'bg-red-100 text-red-800',
    };
    return (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${colors[status]}`}>
            {status}
        </span>
    );
  };

  const toggleExpand = (orderId: number) => {
    setExpandedOrderId(prevId => (prevId === orderId ? null : orderId));
  }

  return (
    <div className="p-4 mb-4 bg-white border border-gray-200 rounded-lg shadow-sm">
      <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-500" viewBox="0 0 20 20" fill="currentColor"><path d="M7 3a1 1 0 000 2h6a1 1 0 100-2H7zM4 7a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zM5 11a1 1 0 100 2h4a1 1 0 100-2H5z" /></svg>
        Your Order History & Tracking
      </h2>
      {loading && <p className="text-sm text-gray-500 mt-2">Loading history...</p>}
      {error && <p className="text-sm text-red-500 mt-2">{error}</p>}
      {!loading && !error && history.length === 0 && (
        <p className="text-sm text-gray-500 mt-2">You haven't placed any orders yet.</p>
      )}
      {!loading && !error && history.length > 0 && (
        <div className="mt-4 space-y-3 max-h-96 overflow-y-auto pr-2">
          {history.map(order => (
            <div key={order.id} className="p-3 bg-gray-50 rounded-md border cursor-pointer" onClick={() => toggleExpand(order.id)}>
              <div className="flex justify-between items-start">
                  <div>
                      <p className="font-bold text-gray-800">Order #{order.id}</p>
                      <p className="text-xs text-gray-500">{new Date(order.created_at).toLocaleDateString()}</p>
                  </div>
                  <StatusBadge status={order.status} />
              </div>
              <div className="mt-2 text-sm space-y-1 border-t pt-2">
                 <p><span className="font-semibold">Total:</span> ₹{order.total_amount.toLocaleString()}</p>
                 <p><span className="font-semibold">Units:</span> {order.total_units.toLocaleString()}</p>
                 {order.riders?.name && <p><span className="font-semibold">Rider:</span> {order.riders.name}</p>}
              </div>
              {expandedOrderId === order.id && <WholesaleOrderStatusTimeline order={order} />}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};


const RewardsProgress: React.FC<{ totalUnitsOrdered: number }> = ({ totalUnitsOrdered }) => {
  const nextTier = REWARD_TIERS.find(tier => totalUnitsOrdered < tier.goal);

  const progressPercentage = useMemo(() => {
    if (!nextTier) return 100;
    const previousTierGoal = REWARD_TIERS.slice().reverse().find(tier => tier.goal < nextTier.goal)?.goal || 0;
    const tierRange = nextTier.goal - previousTierGoal;
    const progressInTier = totalUnitsOrdered - previousTierGoal;
    return Math.min(100, Math.max(0, (progressInTier / tierRange) * 100));
  }, [totalUnitsOrdered, nextTier]);

  const nextTierIndex = nextTier ? REWARD_TIERS.indexOf(nextTier) : -1;
  const visibleTiers = nextTierIndex !== -1 
    ? REWARD_TIERS.slice(0, nextTierIndex + 1)
    : REWARD_TIERS; // If all are unlocked, show all

  return (
    <div className="p-4 mb-4 bg-white border border-gray-200 rounded-lg shadow-sm">
      <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
        Your Partner Rewards
      </h2>
      <p className="text-sm text-gray-600 mt-1">Unlock secret rewards as you grow with us. Total units ordered: <span className="font-bold">{totalUnitsOrdered.toLocaleString()}</span></p>

      {nextTier && (
        <div className="mt-4">
          <div className="flex justify-between items-center text-sm font-medium text-gray-700">
            <span>Progress to <span className="font-bold">{nextTier.name}</span></span>
            <span>{Math.floor(progressPercentage)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
            <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: `${progressPercentage}%` }}></div>
          </div>
          <p className="text-xs text-right text-gray-500 mt-1">{nextTier.goal.toLocaleString()} units</p>
        </div>
      )}

      <div className="mt-4 space-y-3">
        {visibleTiers.map(tier => {
          const isUnlocked = totalUnitsOrdered >= tier.goal;
          const isNextGoal = tier === nextTier;

          if (isNextGoal) {
            return (
              <div key={tier.name} className="p-3 rounded-md flex items-center gap-4 bg-gray-100 border-2 border-dashed border-gray-300">
                <div className="text-3xl">🤫</div>
                <div>
                  <h3 className="font-semibold text-gray-700">Secret Reward Unlocks Next!</h3>
                  <p className="text-sm text-gray-600">Keep ordering to reveal your next surprise.</p>
                  <p className="text-xs font-medium text-gray-500">Requires: {tier.goal.toLocaleString()} units</p>
                </div>
              </div>
            );
          }

          return (
            <div key={tier.name} className="p-3 rounded-md flex items-center gap-4 transition-all bg-green-50 border border-green-200">
              <div className="text-3xl">{tier.icon}</div>
              <div>
                <h3 className="font-semibold text-green-800">{tier.name} - Unlocked!</h3>
                <p className="text-sm text-green-700">We will contact you to arrange delivery of your secret gift.</p>
                <p className="text-xs font-medium text-green-600">Requires: {tier.goal.toLocaleString()} units</p>
              </div>
              <div className="ml-auto flex-shrink-0">
                <div className="bg-green-600 rounded-full text-white p-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};


const OrderSummaryModal: React.FC<OrderSummaryModalProps> = ({ orderQuantities, onClose, onOrderPlaced, user }) => {
    const { addSubmission } = useSubmissions();
    const { t } = useLanguage();
    
    const orderedItems = useMemo(() => {
        return WHOLESALE_PRODUCTS.filter(p => (orderQuantities[p.id] || 0) > 0);
    }, [orderQuantities]);

    const totalAmount = useMemo(() => {
        return orderedItems.reduce((total, product) => {
            const quantity = orderQuantities[product.id];
            const price = product.sizes[0].price; // Assuming one size for wholesale
            return total + (quantity * price);
        }, 0);
    }, [orderedItems, orderQuantities]);

    const handleSendOrder = async () => {
        const totalUnits = orderedItems.reduce((sum, p) => sum + (orderQuantities[p.id] || 0), 0);

        const orderLines = orderedItems.map(p => {
            const quantity = orderQuantities[p.id];
            const size = p.sizes[0].size;
            const price = p.sizes[0].price;
            const subtotal = quantity * price;
            return `- ${p.name} (${size}): ${quantity} units @ ₹${price} = ₹${subtotal.toLocaleString()}`;
        }).join('\n');

        const message = `
New Wholesale Order Request!

*Partner:* ${user.business_name}
*Partner ID:* ${user.id}

*Order Details:*
${orderLines}

*Total Units:* ${totalUnits}
*Estimated Total:* ₹${totalAmount.toLocaleString('en-IN')}

Please confirm availability and provide payment details.
        `.trim().replace(/\n\s*\n/g, '\n\n');
        
        // 1. Add to submissions table for a generic log
        addSubmission({ type: 'Wholesale Enquiry', message });

        // 2. Add to the new structured wholesale_orders table for processing and rewards
        const { data: newOrder, error } = await supabase
            .from('wholesale_orders')
            .insert({
                wholesale_user_id: user.id,
                order_details: message,
                total_units: totalUnits,
                total_amount: totalAmount,
                status: 'Pending'
            })
            .select()
            .single();
        
        if (error || !newOrder) {
            console.error('Error saving wholesale order:', error);
            alert('Could not save order details for tracking, but your message is ready to be sent. Please contact support if you have issues.');
        }

        // 3. Open WhatsApp to send the message, including the new Order ID if available
        const finalMessage = newOrder ? `Order ID: #${newOrder.id}\n\n${message}` : message;
        const whatsappUrl = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(finalMessage)}`;
        window.open(whatsappUrl, '_blank');
        
        if (newOrder) {
           onOrderPlaced(newOrder);
        }
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-40 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-white rounded-lg shadow-2xl w-full max-w-lg max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <header className="p-4 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-gray-800">Your Order List</h2>
                    <button onClick={onClose} className="p-2 -mr-2 text-gray-500 hover:text-red-600">&times;</button>
                </header>
                <main className="flex-grow p-4 overflow-y-auto">
                    {orderedItems.length > 0 ? (
                        <ul className="divide-y divide-gray-200">
                            {orderedItems.map(p => {
                                const quantity = orderQuantities[p.id];
                                const price = p.sizes[0].price;
                                const subtotal = quantity * price;
                                return (
                                    <li key={p.id} className="py-3 flex justify-between items-center">
                                        <div>
                                            <p className="font-semibold text-gray-800">{t(`products.${p.id.replace('w-','')}.name`, p.name)}</p>
                                            <p className="text-sm text-gray-600">{quantity} units &times; ₹{price} / {p.sizes[0].size}</p>
                                        </div>
                                        <p className="font-semibold text-lg text-gray-900">₹{subtotal.toLocaleString()}</p>
                                    </li>
                                )
                            })}
                        </ul>
                    ) : (
                        <p className="text-center text-gray-500 py-8">Your order list is empty. Add products from the dashboard.</p>
                    )}
                </main>
                <footer className="p-4 border-t bg-gray-50">
                    <div className="flex justify-between items-center mb-4">
                        <span className="text-lg font-semibold text-gray-800">Estimated Total:</span>
                        <span className="text-2xl font-bold text-gray-900">₹{totalAmount.toLocaleString('en-IN')}</span>
                    </div>
                    <button 
                        onClick={handleSendOrder}
                        disabled={orderedItems.length === 0}
                        className="w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400"
                    >
                        Send Order via WhatsApp
                    </button>
                </footer>
            </div>
        </div>
    );
};


interface ProductListItemProps {
  product: WholesaleProduct;
  isSelected: boolean;
  quantity: number;
  onToggle: (id: string, isChecked: boolean) => void;
  onQuantityChange: (id: string, qty: number) => void;
}

const ProductListItem: React.FC<ProductListItemProps> = ({ 
  product, 
  isSelected,
  quantity, 
  onToggle,
  onQuantityChange,
}) => {
    const { moq, price, size } = product.sizes[0];
    const { t } = useLanguage();

    const handleQuantityInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = parseInt(e.target.value, 10);
        onQuantityChange(product.id, isNaN(val) ? 0 : val);
    };

    const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        onToggle(product.id, e.target.checked);
    };

    return (
        <div className={`p-3 rounded-lg border transition-all duration-200 ${isSelected ? 'bg-blue-50 border-blue-400 shadow-sm' : 'bg-white border-gray-200'}`}>
            <label htmlFor={`checkbox-${product.id}`} className="flex items-center gap-4 cursor-pointer">
                <input 
                    type="checkbox"
                    id={`checkbox-${product.id}`}
                    checked={isSelected}
                    onChange={handleCheckboxChange}
                    className="h-5 w-5 rounded text-blue-600 focus:ring-blue-500 border-gray-300 flex-shrink-0"
                />
                <div className="flex-grow">
                    <p className="font-semibold text-gray-800">{t(`products.${product.id.replace('w-','')}.name`, product.name)}</p>
                    <p className="text-sm text-gray-600">
                        Price: ₹{price}/{size} 
                        <span className="text-xs text-blue-600 font-medium ml-2">(MOQ: {moq})</span>
                    </p>
                </div>
            </label>
            {isSelected && (
                <div className="mt-3 pl-9 flex items-center gap-2" onClick={e => e.stopPropagation()}>
                    <label htmlFor={`qty-${product.id}`} className="text-sm font-medium text-gray-700">Quantity:</label>
                    <input 
                        type="number"
                        id={`qty-${product.id}`}
                        value={quantity}
                        onChange={handleQuantityInputChange}
                        min={moq}
                        className="w-24 text-center border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                     <p className="text-sm font-semibold text-gray-800">
                        = ₹{(quantity * price).toLocaleString()}
                     </p>
                </div>
            )}
        </div>
    );
};


const WholesaleHomeScreen: React.FC<WholesaleHomeScreenProps> = ({ onBack, user }) => {
    const [orderQuantities, setOrderQuantities] = useState<Record<string, number>>({});
    const [showSummary, setShowSummary] = useState(false);
    const [justPlacedOrder, setJustPlacedOrder] = useState<WholesaleOrder | null>(null);
    const [totalUnitsOrdered, setTotalUnitsOrdered] = useState(0);

    const fetchTotalUnits = async () => {
        const { data, error } = await supabase
            .from('wholesale_orders')
            .select('total_units')
            .eq('wholesale_user_id', user.id)
            .eq('status', 'Delivered');
        
        if (!error && data) {
            const sum = data.reduce((acc, order) => acc + (order.total_units || 0), 0);
            setTotalUnitsOrdered(sum);
        }
    };

    useEffect(() => {
        fetchTotalUnits();
    }, [user.id]);

    const handleToggleProduct = (productId: string, isChecked: boolean) => {
        const product = WHOLESALE_PRODUCTS.find(p => p.id === productId);
        if (!product) return;
        setOrderQuantities(prev => ({
            ...prev,
            [productId]: isChecked ? product.sizes[0].moq : 0
        }));
    };

    const handleQuantityChange = (productId: string, qty: number) => {
        setOrderQuantities(prev => ({ ...prev, [productId]: Math.max(0, qty) }));
    };

    const totalItemsInCart = useMemo(() => {
        // FIX: Explicitly type `sum` and `qty` as numbers to resolve TS inference issue.
        return Object.values(orderQuantities).reduce((sum: number, qty: number) => sum + (qty > 0 ? 1 : 0), 0);
    }, [orderQuantities]);

    const handleOrderPlaced = (newOrder: WholesaleOrder) => {
        setJustPlacedOrder(newOrder);
        setOrderQuantities({}); // Clear cart
    };

    if (justPlacedOrder) {
        return <WholesaleOrderSuccessScreen order={justPlacedOrder} onBack={() => {
            setJustPlacedOrder(null);
            fetchTotalUnits(); // Refresh rewards progress
        }} />;
    }

    return (
        <div className="flex flex-col h-screen">
            <Header title="header.wholesalePortal" onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-4 bg-gray-50 pb-24">
                <div className="p-4 mb-4 bg-blue-50 border-l-4 border-blue-500 rounded-r-lg">
                    <h1 className="text-xl font-bold text-blue-900">Welcome, {user.business_name}!</h1>
                    <p className="text-sm text-blue-800 mt-1">Place your bulk orders here. Your order will be sent to our team for confirmation.</p>
                </div>
                
                <RewardsProgress totalUnitsOrdered={totalUnitsOrdered} />
                
                <OrderHistory user={user} />
                
                <div className="mt-4">
                    <h2 className="text-lg font-bold text-gray-800 mb-2">Place a New Order</h2>
                    <div className="space-y-2">
                        {WHOLESALE_PRODUCTS.map(p => (
                            <ProductListItem 
                                key={p.id}
                                product={p}
                                isSelected={(orderQuantities[p.id] || 0) > 0}
                                quantity={orderQuantities[p.id] || 0}
                                onToggle={handleToggleProduct}
                                onQuantityChange={handleQuantityChange}
                            />
                        ))}
                    </div>
                </div>

                {showSummary && (
                    <OrderSummaryModal 
                        orderQuantities={orderQuantities} 
                        onClose={() => setShowSummary(false)}
                        onOrderPlaced={handleOrderPlaced}
                        user={user}
                    />
                )}
            </main>

            {totalItemsInCart > 0 && (
                <div className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto p-4 z-30">
                    <button onClick={() => setShowSummary(true)} className="w-full bg-blue-600 text-white font-bold py-4 px-6 rounded-lg shadow-xl hover:bg-blue-700 transition-all transform hover:scale-105 flex justify-between items-center">
                        <span>View Order ({totalItemsInCart} items)</span>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>
                    </button>
                </div>
            )}
            
            <RetailFooter/>
        </div>
    );
};

export default WholesaleHomeScreen;