import React, { useState } from 'react';
import Header from '../../components/Header';
import Logo from '../../components/Logo';
import { ADMIN_WHATSAPP_NUMBER } from '../../constants';
import RetailFooter from '../../components/RetailFooter';
import { useSubmissions } from '../../hooks/useSubmissions';
import { supabase } from '../../lib/supabaseClient';
import { WholesaleUser } from '../../types';
import { useLanguage } from '../../hooks/useLanguage';


const WholesaleApplicationForm: React.FC<{onBack: () => void, onFormSubmitted: () => void}> = ({ onBack, onFormSubmitted }) => {
  const [businessName, setBusinessName] = useState('');
  const [yourName, setYourName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [secondaryMobile, setSecondaryMobile] = useState('');
  const [address, setAddress] = useState('');
  const [gst, setGst] = useState('');
  const [fssaiNumber, setFssaiNumber] = useState('');
  const { addSubmission } = useSubmissions();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `
New Wholesale Partner Application!

*Business Name:* ${businessName}
*Contact Person:* ${yourName}
*Contact Number:* ${contactNumber}
*Secondary Mobile:* ${secondaryMobile || 'Not provided'}
*Email:* ${email}
*Address:* ${address}
*GST (Optional):* ${gst || 'Not provided'}
*FSSAI Number:* ${fssaiNumber}
    `.trim().replace(/\n\s*\n/g, '\n\n');
    
    addSubmission({ type: 'Wholesale Application', message });

    const whatsappUrl = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    onFormSubmitted();
  };

  return (
    <div className="w-full max-w-sm">
        <h2 className="text-2xl font-bold text-center text-gray-800 mt-4">New Partner Application</h2>
        <p className="text-center text-gray-600 mt-2">Apply for access to bulk pricing. Your application will be reviewed by our team.</p>

        <form onSubmit={handleSubmit} className="w-full mt-8 space-y-4">
            <input type="text" placeholder="Business Name" required value={businessName} onChange={(e) => setBusinessName(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
            <input type="text" placeholder="Your Name" required value={yourName} onChange={(e) => setYourName(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
            <input type="email" placeholder="Email Address" required value={email} onChange={(e) => setEmail(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
            <input type="tel" placeholder="Contact Number" required value={contactNumber} onChange={(e) => setContactNumber(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
            <input type="tel" placeholder="Secondary Mobile (Optional)" value={secondaryMobile} onChange={(e) => setSecondaryMobile(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
            <textarea placeholder="Business Address" rows={3} required value={address} onChange={(e) => setAddress(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"></textarea>
            <input type="text" placeholder="GST Number (Optional)" value={gst} onChange={(e) => setGst(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
            <input type="text" placeholder="FSSAI Number" required value={fssaiNumber} onChange={(e) => setFssaiNumber(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
          <button 
            type="submit" 
            className="w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
          >
            Apply via WhatsApp
          </button>
        </form>
    </div>
  );
}


interface WholesaleLoginScreenProps {
  onBack: () => void;
  onLoginSuccess: (user: WholesaleUser) => void;
}

const WholesaleLoginScreen: React.FC<WholesaleLoginScreenProps> = ({ onBack, onLoginSuccess }) => {
  const [view, setView] = useState<'login' | 'apply' | 'submitted'>('login');
  const { t } = useLanguage();
  
  // Login State
  const [businessName, setBusinessName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!businessName.trim() || !password.trim()) {
      setError('Please enter both business name and password.');
      return;
    }
    setLoading(true);
    
    const { data: user, error: queryError } = await supabase
      .from('wholesale_users')
      .select('*')
      .eq('business_name', businessName.trim())
      .single();

    if (queryError) {
        const lowerErrorMessage = queryError.message.toLowerCase();
        if (lowerErrorMessage.includes('relation') && lowerErrorMessage.includes('does not exist')) {
            setError('Database setup error: The "wholesale_users" table is missing. Please run the SQL script in `lib/supabaseClient.ts`.');
        } else {
            setError('Invalid business name or password.');
        }
        console.error('Wholesale login error:', queryError);
    } else if (!user) {
        setError('Invalid business name or password.');
    } else if (user.password === password.trim()) {
        onLoginSuccess(user as WholesaleUser);
    } else {
        setError('Invalid business name or password.');
    }

    setPassword('');
    setLoading(false);
  };

  const renderContent = () => {
    switch(view) {
        case 'submitted':
            return (
                <div className="flex-grow flex flex-col items-center justify-center text-center p-6">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <h2 className="mt-4 text-2xl font-bold text-gray-800">Application Sent!</h2>
                    <p className="mt-2 text-gray-600 max-w-sm">
                        Please ensure you sent the message on WhatsApp. Our team will review it and contact you shortly.
                    </p>
                    <button onClick={() => setView('login')} className="mt-8 bg-blue-600 text-white font-semibold py-2 px-6 rounded-lg hover:bg-blue-700 transition-colors">
                        Back to Login
                    </button>
                </div>
            );
        case 'apply':
            return <WholesaleApplicationForm onBack={() => setView('login')} onFormSubmitted={() => setView('submitted')} />
        case 'login':
        default:
            return (
                <div className="w-full max-w-xs">
                    <h2 className="text-2xl font-bold text-center text-gray-800 mt-4">Wholesale Partner Login</h2>
                     <form onSubmit={handleLogin} className="w-full mt-8 space-y-4">
                        <input type="text" placeholder="Business Name" required value={businessName} onChange={(e) => setBusinessName(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
                        <input type="password" placeholder="Password" required value={password} onChange={(e) => setPassword(e.target.value)} className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
                        {error && <p className="text-sm text-red-600">{error}</p>}
                        <button type="submit" disabled={loading} className="w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400">
                            {loading ? 'Logging in...' : 'Login'}
                        </button>
                    </form>
                    <div className="text-center mt-6">
                        <button onClick={() => setView('apply')} className="text-sm text-blue-600 hover:underline">
                            Not a partner yet? Apply for an account
                        </button>
                    </div>
                </div>
            );
    }
  }


  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="header.wholesaleAccess" onBack={onBack} />
      <main className="flex-grow overflow-y-auto p-6 flex flex-col items-center">
        <div className="flex justify-center">
            <Logo className="w-24 h-24" />
        </div>
        {renderContent()}
      </main>
      <RetailFooter />
    </div>
  );
};

export default WholesaleLoginScreen;