import React, { useState, useEffect, useMemo } from 'react';
import Header from '../../components/Header';
import { Submission, OrderStatus, Rider, WholesaleOrder, WholesaleOrderStatus } from '../../types';
import { supabase } from '../../lib/supabaseClient';

interface RiderDashboardScreenProps {
  onBack: () => void;
  rider: Rider;
}

const retailStatusSequence: OrderStatus[] = ['Pending', 'Processing', 'Out for Delivery', 'Delivered'];
const wholesaleStatusSequence: WholesaleOrderStatus[] = ['Confirmed', 'Out for Delivery', 'Delivered'];

const RetailStatusBadge: React.FC<{ status: OrderStatus | undefined }> = ({ status }) => {
    if (!status) return null;
    const colors: Record<OrderStatus, string> = {
        'Pending': 'bg-gray-100 text-gray-800',
        'Pending Payment Confirmation': 'bg-orange-100 text-orange-800',
        'Processing': 'bg-yellow-100 text-yellow-800',
        'Out for Delivery': 'bg-blue-100 text-blue-800',
        'Delivered': 'bg-green-100 text-green-800',
    };
    return (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${colors[status]}`}>
            {status}
        </span>
    );
};

const WholesaleStatusBadge: React.FC<{ status: WholesaleOrderStatus }> = ({ status }) => {
    const colors: Record<WholesaleOrderStatus, string> = {
        'Pending': 'bg-gray-100 text-gray-800',
        'Confirmed': 'bg-yellow-100 text-yellow-800',
        'Out for Delivery': 'bg-blue-100 text-blue-800',
        'Delivered': 'bg-green-100 text-green-800',
        'Cancelled': 'bg-red-100 text-red-800',
    };
    return (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${colors[status]}`}>
            {status}
        </span>
    );
};

interface OrderDetails {
    name: string;
    mobile: string;
    address: string;
    pincode: string;
    totalAmount: string;
    paymentMethod: string;
}

const RetailOrderCard: React.FC<{ order: Submission, onStatusChange: (id: number, newStatus: OrderStatus) => void }> = ({ order, onStatusChange }) => {
    
    const details = useMemo<OrderDetails>(() => {
        const hasValidStructuredData = order.customer_name && order.customer_name.trim() !== '';

        if (hasValidStructuredData) {
            return {
                name: order.customer_name,
                mobile: order.customer_mobile || 'N/A',
                address: order.customer_address || 'N/A',
                pincode: order.customer_pincode || '',
                totalAmount: `₹${(order.total_amount || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                paymentMethod: order.payment_method || 'N/A',
            };
        }

        const message = order.message;
        const extractPlainText = (key: string): string => {
            const regex = new RegExp(`^${key}:\\s*(.+)`, 'm');
            const match = message.match(regex);
            return match ? match[1].trim() : 'N/A';
        };
        const extractMarkdown = (key: string): string => {
            const regex = new RegExp(`\\*${key}:\\*\\s*(.+)`);
            const match = message.match(regex);
            return match ? match[1].trim() : 'N/A';
        };
        return {
            name: extractPlainText('Name'),
            mobile: extractPlainText('Mobile'),
            address: extractPlainText('Address'),
            pincode: extractPlainText('Pincode'),
            totalAmount: extractMarkdown('Total Amount'),
            paymentMethod: extractMarkdown('Payment Method'),
        };
    }, [order]);

    const handleUpdateStatus = () => {
        const currentStatus = order.status || 'Pending';
        const currentIndex = retailStatusSequence.indexOf(currentStatus);
        if (currentIndex < retailStatusSequence.length - 1) {
            const newStatus = retailStatusSequence[currentIndex + 1];
            onStatusChange(order.id, newStatus);
        }
    };

    const nextStatus = useMemo(() => {
        const currentStatus = order.status || 'Pending';
        const currentIndex = retailStatusSequence.indexOf(currentStatus);
        return currentIndex < retailStatusSequence.length - 1 ? retailStatusSequence[currentIndex + 1] : null;
    }, [order.status]);

    return (
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden flex flex-col">
            <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
                <h3 className="text-lg font-bold text-gray-800">Retail Order #{order.id}</h3>
                <RetailStatusBadge status={order.status} />
            </div>
             <div className="p-4 space-y-4">
                <div>
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Customer</h4>
                    <p className="text-lg font-bold text-gray-800">{details.name}</p>
                    <a href={`tel:${details.mobile}`} className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800 transition-colors mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" /></svg>
                        <span className="text-md">{details.mobile}</span>
                    </a>
                </div>
                <div>
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Delivery Address</h4>
                    <p className="text-md text-gray-700">{details.address}, {details.pincode}</p>
                    <a 
                        href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(details.address + ', ' + details.pincode)}`}
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800 transition-colors mt-1"
                    >
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>
                        <span className="text-sm font-medium">Get Directions</span>
                    </a>
                </div>
                <div className="pt-3 border-t">
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Amount to Collect</h4>
                    <p className="text-xl font-bold text-gray-900">{details.totalAmount}</p>
                    <p className={`text-sm font-semibold ${details.paymentMethod === 'Cash on Delivery' ? 'text-red-600' : 'text-green-600'}`}>
                        {details.paymentMethod}
                    </p>
                </div>
            </div>
            {nextStatus && (
                <div className="p-4 bg-gray-50 border-t">
                    <button 
                        onClick={handleUpdateStatus}
                        className="w-full bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors"
                    >
                        Mark as "{nextStatus}"
                    </button>
                </div>
            )}
        </div>
    );
}

const WholesaleOrderCard: React.FC<{ order: WholesaleOrder, onStatusChange: (id: number, newStatus: WholesaleOrderStatus) => void }> = ({ order, onStatusChange }) => {
    
    const details = useMemo(() => {
        const partnerName = order.wholesale_users?.business_name || 'N/A';
        const contactNumber = order.wholesale_users?.contact_number || 'N/A';
        const addressMatch = order.order_details.match(/Address:\s*(.+)/m);
        const address = addressMatch ? addressMatch[1].trim() : 'See details in message';
        
        return { partnerName, contactNumber, address };
    }, [order]);

    const handleUpdateStatus = () => {
        const currentIndex = wholesaleStatusSequence.indexOf(order.status);
        if (currentIndex !== -1 && currentIndex < wholesaleStatusSequence.length - 1) {
            const newStatus = wholesaleStatusSequence[currentIndex + 1];
            onStatusChange(order.id, newStatus);
        }
    };

    const nextStatus = useMemo(() => {
        const currentIndex = wholesaleStatusSequence.indexOf(order.status);
        return (currentIndex !== -1 && currentIndex < wholesaleStatusSequence.length - 1) ? wholesaleStatusSequence[currentIndex + 1] : null;
    }, [order.status]);

    return (
        <div className="bg-white border-2 border-purple-200 rounded-lg shadow-sm overflow-hidden flex flex-col">
            <div className="p-4 border-b bg-purple-50 flex justify-between items-center">
                <h3 className="text-lg font-bold text-purple-800">Wholesale Order #{order.id}</h3>
                <WholesaleStatusBadge status={order.status} />
            </div>
            <div className="p-4 space-y-4">
                <div>
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Business</h4>
                    <p className="text-lg font-bold text-gray-800">{details.partnerName}</p>
                    <a href={`tel:${details.contactNumber}`} className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800 transition-colors mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" /></svg>
                        <span className="text-md">{details.contactNumber}</span>
                    </a>
                </div>
                <div>
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Delivery Address</h4>
                    <p className="text-md text-gray-700">{details.address}</p>
                </div>
                <div className="pt-3 border-t">
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Amount to Collect</h4>
                    <p className="text-xl font-bold text-gray-900">₹{order.total_amount.toLocaleString()}</p>
                    <p className="text-sm font-semibold text-green-600">Payment to be Confirmed</p>
                </div>
            </div>
            {nextStatus && (
                <div className="p-4 bg-purple-50 border-t">
                    <button 
                        onClick={handleUpdateStatus}
                        className="w-full bg-purple-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors"
                    >
                        Mark as "{nextStatus}"
                    </button>
                </div>
            )}
        </div>
    );
}

const RiderDashboardScreen: React.FC<RiderDashboardScreenProps> = ({ onBack, rider }) => {
  const [retailOrders, setRetailOrders] = useState<Submission[]>([]);
  const [wholesaleOrders, setWholesaleOrders] = useState<WholesaleOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
      setLoading(true);
      setError(null);
      
      const [retailRes, wholesaleRes] = await Promise.all([
        supabase
          .from('submissions')
          .select('*')
          .eq('type', 'Retail Order')
          .eq('rider_id', rider.id)
          .neq('status', 'Delivered')
          .order('created_at', { ascending: true }),
        supabase
          .from('wholesale_orders')
          .select('*, wholesale_users(*)')
          .eq('rider_id', rider.id)
          .neq('status', 'Delivered')
          .neq('status', 'Cancelled')
          .order('created_at', { ascending: true })
      ]);

      if (retailRes.error) {
          console.error('Error fetching retail orders:', retailRes.error);
          setError(`Failed to load retail orders: ${retailRes.error.message}.`);
          setLoading(false);
          return;
      }
      if (wholesaleRes.error) {
        console.error('Error fetching wholesale orders:', wholesaleRes.error);
        setError(`Failed to load wholesale orders: ${wholesaleRes.error.message}.`);
        setLoading(false);
        return;
      }
      
      setRetailOrders(retailRes.data as Submission[] || []);
      setWholesaleOrders(wholesaleRes.data as WholesaleOrder[] || []);
      setLoading(false);
  };

  useEffect(() => {
    fetchData();

    const channel = supabase.channel(`rider-all-orders-${rider.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'submissions', filter: `rider_id=eq.${rider.id}` }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'wholesale_orders', filter: `rider_id=eq.${rider.id}` }, () => fetchData())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [rider.id]);


  const handleRetailStatusChange = async (id: number, newStatus: OrderStatus) => {
    const originalOrders = [...retailOrders];
    setRetailOrders(prevOrders => prevOrders.map(o => o.id === id ? {...o, status: newStatus } : o));

    const { error } = await supabase.from('submissions').update({ status: newStatus }).eq('id', id);

    if (error) {
      alert('Error: Could not update status. Please try again.');
      setRetailOrders(originalOrders);
    } else {
        const order = originalOrders.find(o => o.id === id);
        if (order?.customer_mobile) {
            let message = '';
            switch (newStatus) {
                case 'Out for Delivery':
                    const contactInfo = rider.contact_number ? ` (Contact: ${rider.contact_number})` : '';
                    message = `Great news from Jhelum Spices! Your order #${order.id} is out for delivery with our rider, ${rider.name}${contactInfo}. They will contact you shortly.`;
                    break;
                case 'Delivered':
                    message = `Your Jhelum Spices order #${order.id} has been delivered! Thank you for your purchase. We hope you enjoy our premium spices.`;
                    break;
            }
            if (message) {
                const customerNumber = order.customer_mobile.startsWith('91') ? order.customer_mobile : `91${order.customer_mobile}`;
                window.open(`https://wa.me/${customerNumber}?text=${encodeURIComponent(message)}`, '_blank');
            }
       }
    }
  };

  const handleWholesaleStatusChange = async (id: number, newStatus: WholesaleOrderStatus) => {
    const originalOrders = [...wholesaleOrders];
    setWholesaleOrders(prevOrders => prevOrders.map(o => o.id === id ? { ...o, status: newStatus } : o));

    const { error } = await supabase.from('wholesale_orders').update({ status: newStatus }).eq('id', id);
    if (error) {
        alert('Error: Could not update wholesale order status. Please try again.');
        setWholesaleOrders(originalOrders);
    }
  };

  const renderContent = () => {
    if (loading) return <div className="text-center p-8">Loading your assigned orders...</div>;
    if (error) return <div className="text-center p-8 text-red-600 bg-red-50 rounded-lg">{error}</div>;
    
    const hasRetail = retailOrders.length > 0;
    const hasWholesale = wholesaleOrders.length > 0;

    if (!hasRetail && !hasWholesale) {
        return <div className="text-center p-8 text-gray-600">You have no active orders assigned.</div>;
    }
    
    return (
        <div className="space-y-6">
            {hasWholesale && (
                <div>
                    <h2 className="text-xl font-bold text-gray-800 mb-4">Your Assigned Wholesale Orders</h2>
                    <div className="space-y-4">
                        {wholesaleOrders.map(order => (
                            <WholesaleOrderCard key={order.id} order={order} onStatusChange={handleWholesaleStatusChange} />
                        ))}
                    </div>
                </div>
            )}
            {hasRetail && (
                <div>
                    <h2 className="text-xl font-bold text-gray-800 mb-4">Your Assigned Retail Orders</h2>
                    <div className="space-y-4">
                        {retailOrders.map(order => (
                            <RetailOrderCard key={order.id} order={order} onStatusChange={handleRetailStatusChange} />
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
  }

  return (
    <div className="flex flex-col h-screen">
      <Header title={`Rider: ${rider.name}`} onBack={onBack} hideLanguageSwitcher />
      <main className="flex-grow overflow-y-auto p-4 bg-gray-50">
        {renderContent()}
      </main>
    </div>
  );
};

export default RiderDashboardScreen;