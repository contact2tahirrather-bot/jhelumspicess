import React, { useState } from 'react';
import RiderLoginScreen from './RiderLoginScreen';
import RiderDashboardScreen from './RiderDashboardScreen';
import { Rider } from '../../types';

interface RiderFlowProps {
  onBackToHome: () => void;
}

const RiderFlow: React.FC<RiderFlowProps> = ({ onBackToHome }) => {
  const [loggedInRider, setLoggedInRider] = useState<Rider | null>(null);

  if (loggedInRider) {
    return <RiderDashboardScreen rider={loggedInRider} onBack={onBackToHome} />;
  }
  
  return <RiderLoginScreen onBack={onBackToHome} onLoginSuccess={(rider) => setLoggedInRider(rider)} />;
};

export default RiderFlow;