import React, { useState } from 'react';
import Header from '../../components/Header';
import Logo from '../../components/Logo';
import { Rider } from '../../types';
import { supabase } from '../../lib/supabaseClient';

interface RiderLoginScreenProps {
  onBack: () => void;
  onLoginSuccess: (rider: Rider) => void;
}

const RiderLoginScreen: React.FC<RiderLoginScreenProps> = ({ onBack, onLoginSuccess }) => {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim() || !password.trim()) {
      setError('Please enter both your name and password.');
      return;
    }

    setLoading(true);
    
    const { data: rider, error: queryError } = await supabase
      .from('riders')
      .select('*')
      .eq('name', name.trim())
      .single();

    if (queryError) {
        const lowerErrorMessage = queryError.message.toLowerCase();
        if (lowerErrorMessage.includes('relation') && lowerErrorMessage.includes('does not exist')) {
            setError('Database setup error: The "riders" table is missing. Please run the SQL script in `lib/supabaseClient.ts`.');
        } else {
            setError('Invalid name or password.');
        }
        console.error('Rider login error:', queryError);
    } else if (!rider) {
        setError('Invalid name or password.');
    } else if (rider.password === password) {
        onLoginSuccess(rider as Rider);
    } else {
        setError('Invalid name or password.');
    }

    setPassword(''); // Clear password field on failed attempt
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-screen bg-indigo-50">
      <Header title="Rider Access" onBack={onBack} hideLanguageSwitcher />
      <main className="flex-grow flex flex-col items-center justify-center p-6">
        <Logo className="w-24 h-24" />
        <h2 className="text-2xl font-bold text-gray-800 mt-4">Rider Login</h2>
        
        <form onSubmit={handleSubmit} className="w-full max-w-xs mt-8 space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">Your Name</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-indigo-600 text-white font-semibold py-2 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-gray-400"
          >
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>
      </main>
    </div>
  );
};

export default RiderLoginScreen;