import React, { useState } from 'react';
import Header from '../../components/Header';
import { RETAIL_PRODUCTS, WAZWAN_PRODUCTS, ADMIN_WHATSAPP_NUMBER } from '../../constants';
import RetailFooter from '../../components/RetailFooter';
import { useSubmissions } from '../../hooks/useSubmissions';
import { RetailProduct } from '../../types';

interface WazwanEnquiryScreenProps {
  onBack: () => void;
}

interface SpiceQuantity {
  quantity: string;
  unit: 'kg' | 'g';
}

const SpiceInputCard: React.FC<{
    spice: RetailProduct;
    quantity: string;
    unit: 'kg' | 'g';
    onQuantityChange: (id: string, qty: string) => void;
    onUnitChange: (id: string, unit: 'kg' | 'g') => void;
}> = ({ spice, quantity, unit, onQuantityChange, onUnitChange }) => {
    return (
        <div className="bg-white p-3 rounded-lg border border-gray-200 shadow-sm flex items-center gap-3">
            <img src={spice.imageUrl} alt={spice.name} className="w-16 h-16 object-cover rounded-md flex-shrink-0" />
            <div className="flex-grow">
                <label htmlFor={`spice-qty-${spice.id}`} className="block text-sm font-medium text-gray-800 mb-1">{spice.name}</label>
                <div className="flex items-center gap-2">
                    <input
                        type="text"
                        id={`spice-qty-${spice.id}`}
                        value={quantity}
                        onChange={(e) => onQuantityChange(spice.id, e.target.value)}
                        placeholder="Qty"
                        className="block w-full text-right border-gray-300 rounded-md shadow-sm focus:ring-amber-500 focus:border-amber-500"
                    />
                    <select
                        id={`spice-unit-${spice.id}`}
                        value={unit}
                        onChange={(e) => onUnitChange(spice.id, e.target.value as 'kg' | 'g')}
                        className="block w-auto border-gray-300 rounded-md shadow-sm focus:ring-amber-500 focus:border-amber-500"
                    >
                        <option value="kg">kg</option>
                        <option value="g">g</option>
                    </select>
                </div>
            </div>
        </div>
    );
};


const WazwanEnquiryScreen: React.FC<WazwanEnquiryScreenProps> = ({ onBack }) => {
  const [name, setName] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [location, setLocation] = useState('');
  const [mobile, setMobile] = useState('');
  const [mobileError, setMobileError] = useState('');
  const [secondaryMobile, setSecondaryMobile] = useState('');
  const [secondaryMobileError, setSecondaryMobileError] = useState('');
  const [address, setAddress] = useState('');
  const [tramiCount, setTramiCount] = useState('');
  const [tramiCountError, setTramiCountError] = useState('');
  
  const [spiceQuantities, setSpiceQuantities] = useState<Record<string, SpiceQuantity>>({});

  const [isSubmitted, setIsSubmitted] = useState(false);
  const { addSubmission } = useSubmissions();

  const handleQuantityChange = (productId: string, quantity: string) => {
    if (/^\d*\.?\d*$/.test(quantity)) {
        setSpiceQuantities(prev => ({
            ...prev,
            [productId]: {
                quantity,
                unit: prev[productId]?.unit || 'kg', // Default to kg
            },
        }));
    }
  };

  const handleUnitChange = (productId: string, unit: 'kg' | 'g') => {
      setSpiceQuantities(prev => ({
          ...prev,
          [productId]: {
              quantity: prev[productId]?.quantity || '',
              unit,
          },
      }));
  };
  
  const handleTramiChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d*$/.test(value)) {
        setTramiCount(value);
        if (value.trim() && parseInt(value, 10) <= 0) {
            setTramiCountError('Please enter a valid number.');
        } else {
            setTramiCountError('');
        }
    }
  };

  const handleMobileChange = (e: React.ChangeEvent<HTMLInputElement>, isSecondary = false) => {
    const value = e.target.value;
    if (/^\d*$/.test(value) && value.length <= 10) {
      if (isSecondary) {
        setSecondaryMobile(value);
        setSecondaryMobileError(value.length > 0 && value.length < 10 ? 'Must be 10 digits.' : '');
      } else {
        setMobile(value);
        setMobileError(value.length > 0 && value.length < 10 ? 'Mobile number must be 10 digits.' : '');
      }
    }
  };
  
  const handleAutoCalculate = () => {
    const guestCount = parseInt(tramiCount, 10);
    if (isNaN(guestCount) || guestCount <= 0) {
        setTramiCountError('Please enter a valid number of guests to calculate.');
        return;
    }

    // A "Trami" is a platter for 4 guests. We calculate based on the number of "Trami units".
    const tramiUnits = Math.ceil(guestCount / 4);

    const specialQuantities: Record<string, number> = {
      'Black Cardamom (Badi Elaichi)': 20,
      'Green Cardamom (Elaichi)': 20,
      'Clove (Laung)': 20,
      'Zeera (Cumin Seeds)': 20,
    };
    const defaultQuantity = 50;

    const newSpiceQuantities: Record<string, SpiceQuantity> = {};

    RETAIL_PRODUCTS.forEach(spice => {
      const baseAmount = specialQuantities[spice.name] || defaultQuantity;
      const calculatedAmount = baseAmount * tramiUnits;
      
      newSpiceQuantities[spice.id] = {
        quantity: String(calculatedAmount),
        unit: 'g' // The recipe is in grams, so we default the unit to 'g'
      };
    });

    setSpiceQuantities(newSpiceQuantities);
    // Scroll down to the list so user can see the result
    const element = document.getElementById('spice-list-header');
    element?.scrollIntoView({ behavior: 'smooth' });
  };


  const validateForm = (): boolean => {
    let isValid = true;
    // Reset errors
    setMobileError('');
    setSecondaryMobileError('');
    setTramiCountError('');

    if (mobile.length !== 10) {
      setMobileError('Mobile number must be 10 digits.');
      isValid = false;
    }

    if (secondaryMobile && secondaryMobile.length !== 10) {
      setSecondaryMobileError('Secondary mobile must be 10 digits.');
      isValid = false;
    }

    // FIX: Explicitly type 'item' to resolve TypeScript error where it was inferred as 'unknown'.
    const hasSpices = Object.values(spiceQuantities).some((item: SpiceQuantity) => 
        item && item.quantity.trim() !== '' && parseFloat(item.quantity) > 0
    );
    const hasTramiCount = tramiCount.trim() && parseInt(tramiCount, 10) > 0;

    if (!hasSpices && !hasTramiCount) {
        alert('Please either enter the number of guests, or specify the quantity for at least one spice.');
        isValid = false;
    }
    
    if (tramiCount.trim() && parseInt(tramiCount, 10) <= 0) {
        setTramiCountError('Please enter a valid number of guests.');
        isValid = false;
    }

    if (!isValid) {
        // A single alert is better UX than multiple
        alert('Please correct the errors in the form before submitting.');
    }

    return isValid;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
        return;
    }
    
    const requiredSpices = RETAIL_PRODUCTS
        .filter(p => spiceQuantities[p.id] && parseFloat(spiceQuantities[p.id].quantity || '0') > 0)
        .map(p => {
            const item = spiceQuantities[p.id];
            return `- ${p.name}: ${item.quantity} ${item.unit}`;
        })
        .join('\n');

    const tramiText = tramiCount.trim() ? `*Event Size:*\nApprox. *${tramiCount}* Trami / Guests.` : '';
    const spicesText = requiredSpices ? `*Required Spices & Quantities:*\n${requiredSpices}` : '';
    
    const orderDetails = [tramiText, spicesText].filter(Boolean).join('\n\n');

    const message = `
New Wazwan & Event Enquiry!

*Name:* ${name}
*Mobile:* ${mobile}
*Secondary Mobile:* ${secondaryMobile || 'N/A'}
*Event Date:* ${eventDate}
*Event Location:* ${location}
*Address:* ${address}

${orderDetails}
    `.trim().replace(/\n\s*\n/g, '\n\n');
    
    addSubmission({ type: 'Wazwan Enquiry', message });

    const whatsappUrl = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
        <div className="flex flex-col h-screen bg-gray-50">
            <Header title="Enquiry Submitted" onBack={onBack} />
            <div className="flex-grow flex flex-col items-center justify-center text-center p-6">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h2 className="mt-4 text-2xl font-bold text-gray-800">Thank You!</h2>
                <p className="mt-2 text-gray-600 max-w-sm">
                    Your enquiry has been sent. Our team will contact you shortly to confirm the details and provide a quote.
                </p>
                <button onClick={onBack} className="mt-8 bg-amber-800 text-white font-semibold py-2 px-6 rounded-lg hover:bg-amber-900 transition-colors">
                    Back to Home
                </button>
            </div>
            <RetailFooter />
        </div>
    )
  }
  
  const [wazwanHeroProduct] = WAZWAN_PRODUCTS;
  const allSpices = RETAIL_PRODUCTS;

  return (
    <div className="flex flex-col h-screen">
      <Header title="Wazwan & Event Enquiry" onBack={onBack} />
      <main className="flex-grow overflow-y-auto p-4 bg-amber-50/50">
        <div className="mb-6 rounded-lg shadow-md overflow-hidden">
            <img 
              src="https://i.postimg.cc/QddLsV31/Wazwan_trami_full.jpg" 
              alt={wazwanHeroProduct.name} 
              className="w-full h-48 object-cover" />
        </div>

        <div className="p-4 mb-4 bg-amber-100 border-l-4 border-amber-500 rounded-r-lg">
            <h2 className="font-bold text-amber-900">For Large Kitchens & Traditional Cooking</h2>
            <p className="text-sm text-amber-800 mt-1">
                Please fill in your event details. You can either provide the number of guests for a quote on our special Wazwan blend, or specify exact quantities for individual spices below.
            </p>
        </div>

        <form onSubmit={handleSubmit} className="w-full mt-4 space-y-6">
          <div className="bg-white p-4 rounded-lg border border-gray-200">
             <h3 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">Event & Contact Details</h3>
             <div className="space-y-4">
                 <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">Your Name</label>
                    <input type="text" id="name" required value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-500 focus:border-amber-500" />
                  </div>
                  <div>
                    <label htmlFor="mobile" className="block text-sm font-medium text-gray-700">Mobile Number</label>
                    <input 
                        type="tel" 
                        id="mobile" 
                        required 
                        value={mobile} 
                        onChange={(e) => handleMobileChange(e, false)} 
                        maxLength={10}
                        className={`mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-500 focus:border-amber-500 ${mobileError ? 'border-red-500' : ''}`}
                    />
                    {mobileError && <p className="text-xs text-red-600 mt-1">{mobileError}</p>}
                  </div>
                  <div>
                    <label htmlFor="secondaryMobile" className="block text-sm font-medium text-gray-700">Secondary Mobile (Optional)</label>
                    <input 
                        type="tel" 
                        id="secondaryMobile" 
                        value={secondaryMobile} 
                        onChange={(e) => handleMobileChange(e, true)}
                        maxLength={10}
                        className={`mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-500 focus:border-amber-500 ${secondaryMobileError ? 'border-red-500' : ''}`}
                    />
                    {secondaryMobileError && <p className="text-xs text-red-600 mt-1">{secondaryMobileError}</p>}
                  </div>
                   <div>
                    <label htmlFor="tramiCount" className="block text-sm font-medium text-gray-700">Number of Trami / Guests (Optional)</label>
                    <div className="mt-1 flex items-center gap-2">
                      <input
                          type="number"
                          id="tramiCount"
                          value={tramiCount}
                          onChange={handleTramiChange}
                          placeholder="e.g., 20"
                          className={`block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-500 focus:border-amber-500 ${tramiCountError ? 'border-red-500' : ''}`}
                      />
                      <button
                        type="button"
                        onClick={handleAutoCalculate}
                        disabled={!tramiCount || parseInt(tramiCount, 10) <= 0}
                        className="flex-shrink-0 px-4 py-2 bg-amber-600 text-white font-semibold rounded-md shadow-sm hover:bg-amber-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-sm"
                      >
                          Calculate Spices
                      </button>
                    </div>
                    {tramiCountError && <p className="text-xs text-red-600 mt-1">{tramiCountError}</p>}
                    <p className="text-xs text-gray-500 mt-1">Enter guests count and tap 'Calculate' to get a recommended spice list.</p>
                  </div>
                  <div>
                    <label htmlFor="eventDate" className="block text-sm font-medium text-gray-700">Event Date</label>
                    <input type="date" id="eventDate" required value={eventDate} onChange={e => setEventDate(e.target.value)} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-500 focus:border-amber-500" />
                  </div>
                  <div>
                    <label htmlFor="location" className="block text-sm font-medium text-gray-700">Event Location</label>
                    <input type="text" id="location" required value={location} onChange={e => setLocation(e.target.value)} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-500 focus:border-amber-500" />
                  </div>
                  <div>
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700">Delivery Address</label>
                    <textarea id="address" rows={3} required value={address} onChange={(e) => setAddress(e.target.value)} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-amber-500 focus:border-amber-500"></textarea>
                  </div>
             </div>
          </div>

          <div className="bg-white p-4 rounded-lg border border-gray-200">
            <h3 id="spice-list-header" className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">Specific Spice Requirements (Optional)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {allSpices.map(spice => (
                <SpiceInputCard
                  key={spice.id}
                  spice={spice}
                  quantity={spiceQuantities[spice.id]?.quantity || ''}
                  unit={spiceQuantities[spice.id]?.unit || 'kg'}
                  onQuantityChange={handleQuantityChange}
                  onUnitChange={handleUnitChange}
                />
              ))}
            </div>
          </div>
          
          <button 
            type="submit" 
            className="w-full bg-amber-800 text-white font-semibold py-3 rounded-lg hover:bg-amber-900 transition-colors flex items-center justify-center"
          >
            Submit Enquiry via WhatsApp
          </button>
        </form>
      </main>
      <RetailFooter/>
    </div>
  );
};

export default WazwanEnquiryScreen;