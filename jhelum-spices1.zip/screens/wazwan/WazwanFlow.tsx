
import React from 'react';
import WazwanEnquiryScreen from './WazwanEnquiryScreen';

interface WazwanFlowProps {
  onBackToHome: () => void;
}

const WazwanFlow: React.FC<WazwanFlowProps> = ({ onBackToHome }) => {
  return <WazwanEnquiryScreen onBack={onBackToHome} />;
};

export default WazwanFlow;
