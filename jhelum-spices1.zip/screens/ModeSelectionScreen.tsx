import React, { useState, useRef } from 'react';
import { UserMode } from '../types';
import Logo from '../components/Logo';
import Footer from '../components/Footer';
import { useLanguage } from '../hooks/useLanguage';

interface ModeSelectionScreenProps {
  onModeSelect: (mode: UserMode) => void;
}

const ModeCard: React.FC<{
  title: string;
  subtitle: string;
  icon: string;
  colorClasses: string;
  onClick: () => void;
}> = ({ title, subtitle, icon, colorClasses, onClick }) => (
  <button
    onClick={onClick}
    className={`w-full p-4 rounded-xl text-center shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 flex flex-col items-center justify-center h-40 ${colorClasses}`}
  >
    <div className="text-4xl mb-2">{icon}</div>
    <div>
      <h2 className="text-lg font-bold">{title}</h2>
      <p className="text-xs opacity-90 mt-1">{subtitle}</p>
    </div>
  </button>
);

const LanguageSwitcher: React.FC = () => {
  const { language, setLanguage } = useLanguage();
  const toggleLanguage = () => setLanguage(language === 'en' ? 'ur' : 'en');
  return (
    <button 
      onClick={toggleLanguage}
      className="absolute top-4 right-4 text-sm font-semibold text-blue-600 hover:text-blue-800 p-2 rounded-md transition-colors bg-blue-100/50"
      aria-label="Change language"
    >
      {language === 'en' ? 'اردو' : 'English'}
    </button>
  );
};

const ModeSelectionScreen: React.FC<ModeSelectionScreenProps> = ({ onModeSelect }) => {
  const [adminClickCount, setAdminClickCount] = useState(0);
  const adminClickTimeout = useRef<number | null>(null);

  const [riderClickCount, setRiderClickCount] = useState(0);
  const riderClickTimeout = useRef<number | null>(null);
  const { t } = useLanguage();

  const handleLogoClick = () => {
    if (adminClickTimeout.current) {
        clearTimeout(adminClickTimeout.current);
    }

    const newCount = adminClickCount + 1;
    setAdminClickCount(newCount);

    if (newCount === 5) {
        onModeSelect(UserMode.ADMIN);
        setAdminClickCount(0);
    } else {
        adminClickTimeout.current = window.setTimeout(() => {
            setAdminClickCount(0);
        }, 1500); // Reset after 1.5 seconds
    }
  };

  const handleFooterClick = () => {
    if (riderClickTimeout.current) {
        clearTimeout(riderClickTimeout.current);
    }
    
    const newCount = riderClickCount + 1;
    setRiderClickCount(newCount);
    
    if (newCount === 5) {
        onModeSelect(UserMode.RIDER);
        setRiderClickCount(0);
    } else {
        riderClickTimeout.current = window.setTimeout(() => {
            setRiderClickCount(0);
        }, 1500);
    }
  };

  return (
    <div className="flex flex-col items-center justify-between min-h-screen bg-white relative">
      <LanguageSwitcher />
      <header className="text-center pt-2 px-6">
        <div onClick={handleLogoClick} className="cursor-pointer" aria-label="Tap five times for admin access">
          <Logo className="w-48 h-48 mx-auto" />
        </div>
        <div className="-mt-2 text-center">
            <h1 className="text-3xl font-light text-gray-700">{t('modeSelection.welcome')}</h1>
            <h2 className="text-2xl font-serif text-gray-500 italic my-1">{t('modeSelection.to')}</h2>
            <h1 className="text-5xl font-bold text-red-600">Jhelum Spices</h1>
            <p className="text-gray-700 mt-4 text-lg font-serif italic">{t('modeSelection.tagline')}</p>
        </div>
      </header>
      <main className="w-full max-w-md my-8 px-6">
        <div className="grid grid-cols-2 gap-4">
            <ModeCard
              title={t('modeSelection.retailTitle')}
              subtitle={t('modeSelection.retailSubtitle')}
              icon="🟢"
              colorClasses="bg-green-100 text-green-800 border-t-4 border-green-500"
              onClick={() => onModeSelect(UserMode.RETAIL)}
            />
            <ModeCard
              title={t('modeSelection.wholesaleTitle')}
              subtitle={t('modeSelection.wholesaleSubtitle')}
              icon="🔵"
              colorClasses="bg-blue-100 text-blue-800 border-t-4 border-blue-500"
              onClick={() => onModeSelect(UserMode.WHOLESALE)}
            />
            <ModeCard
              title={t('modeSelection.wazwanTitle')}
              subtitle={t('modeSelection.wazwanSubtitle')}
              icon="🟤"
              colorClasses="bg-amber-100 text-amber-900 border-t-4 border-amber-500"
              onClick={() => onModeSelect(UserMode.WAZWAN)}
            />
            <ModeCard
              title={t('modeSelection.trackTitle')}
              subtitle={t('modeSelection.trackSubtitle')}
              icon="🚚"
              colorClasses="bg-gray-100 text-gray-800 border-t-4 border-gray-500"
              onClick={() => onModeSelect(UserMode.TRACK)}
            />
            <div className="col-span-2">
                 <ModeCard
                  title={t('modeSelection.feedbackTitle')}
                  subtitle={t('modeSelection.feedbackSubtitle')}
                  icon="⭐"
                  colorClasses="bg-purple-100 text-purple-800 border-t-4 border-purple-500"
                  onClick={() => onModeSelect(UserMode.FEEDBACK)}
                />
            </div>
            <div className="col-span-2">
                 <ModeCard
                  title={t('modeSelection.supportTitle')}
                  subtitle={t('modeSelection.supportSubtitle')}
                  icon="🎧"
                  colorClasses="bg-orange-100 text-orange-800 border-t-4 border-orange-500"
                  onClick={() => onModeSelect(UserMode.SUPPORT)}
                />
            </div>
        </div>
      </main>
      
      <div 
        onClick={handleFooterClick}
        className="w-full cursor-pointer"
        aria-label="Tap five times for rider access"
      >
        <Footer />
      </div>
    </div>
  );
};

export default ModeSelectionScreen;