import React, { useState, useMemo, useEffect } from 'react';
import { RETAIL_PRODUCTS_POWDER, RETAIL_PRODUCTS_WHOLE } from '../../constants';
import Header from '../../components/Header';
import { useShoppingCart } from '../../hooks/useShoppingCart';
import { RetailProduct, ProductSize } from '../../types';
import FlavorAssistant from '../../components/FlavorAssistant';
import { useLanguage } from '../../hooks/useLanguage';

interface RetailHomeScreenProps {
  onBack: () => void;
  onGoToCart: () => void;
}

const RetailHomeScreen: React.FC<RetailHomeScreenProps> = ({ onBack, onGoToCart }) => {
  const { cartCount, addToCart } = useShoppingCart();
  const { t } = useLanguage();
  
  const [activeCategory, setActiveCategory] = useState<'powder' | 'whole'>('powder');
  const [searchQuery, setSearchQuery] = useState('');

  const productsForCategory = useMemo(() => {
    return activeCategory === 'powder' ? RETAIL_PRODUCTS_POWDER : RETAIL_PRODUCTS_WHOLE;
  }, [activeCategory]);

  const filteredProducts = useMemo(() => {
      const translatedProducts = productsForCategory.map(p => ({
          ...p,
          translatedName: t(`products.${p.id}.name`, p.name)
      }));

      return translatedProducts.filter(p => {
        return !searchQuery || 
            p.translatedName.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.name.toLowerCase().includes(searchQuery.toLowerCase());
      });
  }, [searchQuery, t, productsForCategory]);
  
  const [selectedProductId, setSelectedProductId] = useState<string>(filteredProducts[0]?.id || '');
  
  const selectedProduct = useMemo(() => {
    return [...RETAIL_PRODUCTS_POWDER, ...RETAIL_PRODUCTS_WHOLE].find(p => p.id === selectedProductId);
  }, [selectedProductId]);

  const [selectedSize, setSelectedSize] = useState<ProductSize | undefined>(selectedProduct?.sizes[0]);
  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);
  
  useEffect(() => {
    const isSelectedProductVisible = filteredProducts.some(p => p.id === selectedProductId);
    if (!isSelectedProductVisible) {
        setSelectedProductId(filteredProducts[0]?.id || '');
    }
  }, [filteredProducts, selectedProductId]);

  useEffect(() => {
    if (selectedProduct) {
        setSelectedSize(selectedProduct.sizes[0]);
        setQuantity(1);
    }
  }, [selectedProduct]);

  const handleProductChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newProductId = e.target.value;
    setSelectedProductId(newProductId);
  };

  const handleAddToCart = () => {
    if (!selectedProduct || !selectedSize) return;
    addToCart(selectedProduct, selectedSize, quantity);
    setJustAdded(true);
    setTimeout(() => {
        setJustAdded(false);
    }, 1500);
  };
  
  const mainImageUrl = "https://i.postimg.cc/K8GPWJQs/file_00000000798471f8a821acf9da5e63e7.png";

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="header.productCatalog" onBack={onBack} />

      <main className="flex-grow overflow-y-auto pb-24">
        <div className="relative">
            <img src={mainImageUrl} alt="Jhelum Spices" className="w-full h-48 object-cover"/>
            <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                <h1 className="text-4xl font-bold text-white tracking-wider font-serif">Our Spices</h1>
            </div>
        </div>

        <div className="p-4">
          <input 
            type="search"
            placeholder="Search for spices..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div className="px-4 mb-2">
            <div className="flex border-b border-gray-300">
                <button 
                    onClick={() => setActiveCategory('powder')}
                    className={`flex-1 py-2 text-center font-semibold transition-colors duration-200 ${activeCategory === 'powder' ? 'border-b-2 border-red-600 text-red-600' : 'text-gray-500 hover:text-red-500'}`}
                >
                    {t('retail.powderSpices', 'Powder Spices')}
                </button>
                <button 
                    onClick={() => setActiveCategory('whole')}
                    className={`flex-1 py-2 text-center font-semibold transition-colors duration-200 ${activeCategory === 'whole' ? 'border-b-2 border-red-600 text-red-600' : 'text-gray-500 hover:text-red-500'}`}
                >
                    {t('retail.wholeSpices', 'Whole Spices')}
                </button>
            </div>
        </div>
        
        {filteredProducts.length > 0 ? (
          <div className="p-4 pt-2 space-y-4">
              <div className="p-4 bg-white rounded-lg shadow-md border border-gray-200">
                  <div className="grid grid-cols-3 gap-4 items-center">
                      <div className="col-span-1">
                          {selectedProduct && <img src={selectedProduct.imageUrl} alt={selectedProduct.name} className="w-full h-auto object-cover rounded-lg" />}
                      </div>
                      <div className="col-span-2">
                           <div className="relative mb-2">
                               <select 
                                   value={selectedProductId} 
                                   onChange={handleProductChange} 
                                   className="w-full font-bold text-lg bg-blue-600 text-white border-transparent rounded-md shadow-sm focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 py-2 pl-3 pr-8 appearance-none"
                                >
                                    {filteredProducts.map(p => (
                                        <option key={p.id} value={p.id} className="text-black bg-white">{p.translatedName}</option>
                                    ))}
                                </select>
                                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-white">
                                    <svg className="fill-current h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                                </div>
                           </div>
                            {selectedProduct && <p className="text-sm text-gray-600">{t(`products.${selectedProduct.id}.description`, selectedProduct.description)}</p>}
                      </div>
                  </div>
                 
                  {selectedProduct && (
                      <div className="mt-4 pt-4 border-t">
                          <div className="flex justify-between items-center">
                               <div className="flex-grow">
                                    <label htmlFor="size" className="text-sm font-medium text-gray-700">Size:</label>
                                    <select id="size" value={selectedSize?.size} onChange={e => setSelectedSize(selectedProduct.sizes.find(s => s.size === e.target.value))} className="mt-1 block w-full border-blue-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                        {selectedProduct.sizes.map(s => <option key={s.size} value={s.size}>{s.size} - ₹{s.price}</option>)}
                                    </select>
                               </div>
                               <div className="ml-4">
                                     <label htmlFor="quantity" className="text-sm font-medium text-gray-700">Qty:</label>
                                    <input type="number" id="quantity" value={quantity} onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 1))} min="1" className="mt-1 block w-20 text-center border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
                               </div>
                          </div>
                          <button onClick={handleAddToCart} className={`mt-4 w-full font-semibold py-2 px-4 rounded-lg transition-colors ${justAdded ? 'bg-green-600' : 'bg-red-600 hover:bg-red-700'} text-white`}>
                             {justAdded ? 'Added!' : 'Add to Cart'}
                          </button>
                      </div>
                  )}
              </div>
          </div>
        ) : (
            <div className="text-center p-8">
                <p className="text-gray-600">No products match your search criteria in this category.</p>
            </div>
        )}

        <FlavorAssistant />

      </main>
      
      {cartCount > 0 && (
        <div className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto p-4 z-30">
            <button onClick={onGoToCart} className="w-full bg-blue-600 text-white font-bold py-4 px-6 rounded-lg shadow-xl hover:bg-blue-700 transition-all transform hover:scale-105 flex justify-between items-center">
                <span>View Cart</span>
                <span className="bg-white text-blue-600 text-sm font-bold rounded-full h-7 w-7 flex items-center justify-center">
                    {cartCount}
                </span>
            </button>
        </div>
      )}
    </div>
  );
};

export default RetailHomeScreen;