import React from 'react';
import RetailFooter from '../../components/RetailFooter';

interface RetailOrderSuccessScreenProps {
  customerName: string;
  orderId: number | null;
  onBackToHome: () => void;
  paymentMethod: string;
}

const RetailOrderSuccessScreen: React.FC<RetailOrderSuccessScreenProps> = ({ customerName, orderId, onBackToHome, paymentMethod }) => {
  
  const isCod = paymentMethod === 'Cash on Delivery';

  const whatsNextContent = isCod ? (
     <>
        <h2 className="font-semibold text-gray-700">What's Next?</h2>
        <p className="mt-2">
            Our team will contact you on WhatsApp shortly to confirm your order details and delivery schedule. We are excited for you to experience the pure, fresh taste of Jhelum Spices.
        </p>
        <p className="mt-3 pt-3 border-t border-gray-200 font-medium text-gray-600">
            Need to make a change? You can request edits from the 'Track Order' screen until your order is out for delivery.
        </p>
    </>
  ) : (
    <>
        <h2 className="font-semibold text-gray-700">What's Next?</h2>
        <p className="mt-2">
            Thank you! Please ensure you have sent the payment confirmation screenshot on WhatsApp.
            <br/>
            <strong>Your order will be processed as soon as our team verifies the payment.</strong> You will receive a notification once it's confirmed.
        </p>
         <p className="mt-3 pt-3 border-t border-gray-200 font-medium text-gray-600">
            You can track your order status from the home screen.
        </p>
    </>
  );

  return (
    <div className="flex flex-col h-screen bg-white">
      <main className="flex-grow flex flex-col items-center justify-center text-center p-6">
        <div className="bg-green-100 p-4 rounded-full">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </div>
        <h1 className="mt-6 text-3xl font-bold text-gray-800">Order Submitted Successfully!</h1>
        <p className="mt-3 text-lg text-gray-600 max-w-md">
          Thank you, <span className="font-semibold">{customerName}</span>! Your order has been received.
        </p>
        
        {orderId && (
            <div className="mt-6 text-center">
                <p className="text-sm text-gray-600">Your Order ID is:</p>
                <p className="text-2xl font-bold text-blue-600 bg-blue-50 border border-blue-200 rounded-lg px-4 py-2 mt-1 inline-block">
                    #{orderId}
                </p>
                <p className="text-xs text-gray-500 mt-2">Use this ID to track your order status.</p>
            </div>
        )}

        <div className="mt-8 text-sm text-gray-500 bg-gray-50 p-4 rounded-lg border border-gray-200 max-w-md">
           {whatsNextContent}
        </div>
        <button onClick={onBackToHome} className="mt-8 bg-blue-600 text-white font-semibold py-3 px-8 rounded-lg hover:bg-blue-700 transition-colors">
          Back to Home
        </button>
      </main>
      <RetailFooter />
    </div>
  );
};

export default RetailOrderSuccessScreen;