import React, { useState } from 'react';
import RetailHomeScreen from './RetailHomeScreen';
import RetailCartScreen from './RetailCartScreen';
import RetailCheckoutScreen from './RetailCheckoutScreen';
import RetailOrderSuccessScreen from './RetailOrderSuccessScreen';
import RetailPaymentScreen from './RetailPaymentScreen';
import { CartItem } from '../../types';

interface RetailFlowProps {
  onBackToHome: () => void;
}

export interface CheckoutData {
    name: string;
    mobile: string;
    secondaryMobile: string;
    email: string;
    address: string;
    pincode: string;
    paymentMethod: string;
    cartItems: CartItem[];
    totalAmount: number; // This will be the finalTotal
    subtotal: number;
    discountCode?: string | null;
    discountAmount?: number;
}


type RetailScreen = 'home' | 'cart' | 'checkout' | 'payment' | 'orderSuccess';

const RetailFlow: React.FC<RetailFlowProps> = ({ onBackToHome }) => {
  const [screen, setScreen] = useState<RetailScreen>('home');
  const [customerName, setCustomerName] = useState('');
  const [orderId, setOrderId] = useState<number | null>(null);
  const [checkoutData, setCheckoutData] = useState<CheckoutData | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('cod');

  const handleOrderPlaced = (name: string, newOrderId: number, method: string) => {
    setCustomerName(name);
    setOrderId(newOrderId);
    setPaymentMethod(method);
    setCheckoutData(null); // Clear checkout data
    setScreen('orderSuccess');
  };

  const handleProceedToPayment = (data: CheckoutData) => {
    setCheckoutData(data);
    setScreen('payment');
  }

  const renderScreen = () => {
    switch (screen) {
      case 'home':
        return <RetailHomeScreen onBack={onBackToHome} onGoToCart={() => setScreen('cart')} />;
      case 'cart':
        return <RetailCartScreen onBack={() => setScreen('home')} onGoToCheckout={() => setScreen('checkout')} />;
      case 'checkout':
        return <RetailCheckoutScreen onBack={() => setScreen('cart')} onOrderPlaced={handleOrderPlaced} onProceedToPayment={handleProceedToPayment} />;
      case 'payment':
        if (!checkoutData) {
            // Should not happen, but as a fallback
            return <RetailCheckoutScreen onBack={() => setScreen('cart')} onOrderPlaced={handleOrderPlaced} onProceedToPayment={handleProceedToPayment} />;
        }
        return <RetailPaymentScreen onBack={() => setScreen('checkout')} checkoutData={checkoutData} onOrderConfirmed={handleOrderPlaced} />;
      case 'orderSuccess':
        return <RetailOrderSuccessScreen customerName={customerName} orderId={orderId} onBackToHome={onBackToHome} paymentMethod={paymentMethod} />;
      default:
        return <RetailHomeScreen onBack={onBackToHome} onGoToCart={() => setScreen('cart')} />;
    }
  };

  return <div className="flex flex-col h-full">{renderScreen()}</div>;
};

export default RetailFlow;