import React, { useState } from 'react';
import Header from '../../components/Header';
import { useShoppingCart } from '../../hooks/useShoppingCart';
import { ADMIN_WHATSAPP_NUMBER } from '../../constants';
import { useSubmissions } from '../../hooks/useSubmissions';
import { CheckoutData } from './RetailFlow';
import { useLanguage } from '../../hooks/useLanguage';

interface RetailCheckoutScreenProps {
  onBack: () => void;
  onOrderPlaced: (customerName: string, orderId: number, paymentMethod: string) => void;
  onProceedToPayment: (data: CheckoutData) => void;
}

const RetailCheckoutScreen: React.FC<RetailCheckoutScreenProps> = ({ onBack, onOrderPlaced, onProceedToPayment }) => {
  const { cartItems, clearCart, cartTotal, discountCode, discountAmount, finalTotal } = useShoppingCart();
  const { addSubmission } = useSubmissions();
  const { t } = useLanguage();
  
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [secondaryMobile, setSecondaryMobile] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [nameError, setNameError] = useState('');
  const [mobileError, setMobileError] = useState('');
  const [secondaryMobileError, setSecondaryMobileError] = useState('');
  const [addressError, setAddressError] = useState('');
  const [pincodeError, setPincodeError] = useState('');


  const handleMobileChange = (e: React.ChangeEvent<HTMLInputElement>, isSecondary = false) => {
    const value = e.target.value;
    if (/^\d*$/.test(value) && value.length <= 10) {
      if (isSecondary) {
        setSecondaryMobile(value);
        if (value.length > 0 && value.length < 10) {
          setSecondaryMobileError('Must be 10 digits.');
        } else {
          setSecondaryMobileError('');
        }
      } else {
        setMobile(value);
        if (value.length > 0 && value.length < 10) {
          setMobileError('Mobile number must be 10 digits.');
        } else {
          setMobileError('');
        }
      }
    }
  };

  const handlePincodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d*$/.test(value) && value.length <= 6) {
      setPincode(value);
      if (value.length > 0 && value.length < 6) {
        setPincodeError('Pincode must be 6 digits.');
      } else {
        setPincodeError('');
      }
    }
  };

  const validateForm = (): boolean => {
    let isValid = true;
    setNameError('');
    setMobileError('');
    setSecondaryMobileError('');
    setAddressError('');
    setPincodeError('');

    if (!name.trim()) {
        setNameError('Full name is required.');
        isValid = false;
    }
    if (!address.trim()) {
        setAddressError('Address is required.');
        isValid = false;
    }
    if (mobile.trim().length !== 10) {
      setMobileError('Mobile number must be 10 digits.');
      isValid = false;
    }
    if (secondaryMobile.trim() && secondaryMobile.trim().length !== 10) {
      setSecondaryMobileError('Must be 10 digits.');
      isValid = false;
    }
    if (pincode.trim().length !== 6) {
      setPincodeError('Pincode must be 6 digits.');
      isValid = false;
    }

    if (!isValid) {
        alert('Please correct the errors in the form.');
    }
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    if (!validateForm()) {
      return;
    }

    const cleanedData = {
      name: name.trim(),
      mobile: mobile.trim(),
      secondaryMobile: secondaryMobile.trim(),
      email: email.trim(),
      address: address.trim(),
      pincode: pincode.trim(),
    };

    const checkoutData: CheckoutData = { 
        ...cleanedData,
        paymentMethod, 
        cartItems, 
        totalAmount: finalTotal,
        subtotal: cartTotal,
        discountCode,
        discountAmount 
    };

    if (paymentMethod === 'online') {
        onProceedToPayment(checkoutData);
    } else {
        setIsSubmitting(true);
        const orderItems = cartItems.map(item => 
          `- ${item.product.name} (${item.size.size}) x ${item.quantity} = ₹${item.size.price * item.quantity}`
        ).join('\n');

        const discountText = discountCode 
            ? `Discount (${discountCode}): -₹${discountAmount.toFixed(2)}\n` 
            : '';

        const message = `
New Retail Order from Jhelum Spices App!

*Customer Details:*
Name: ${cleanedData.name}
Mobile: ${cleanedData.mobile}
Secondary Mobile: ${cleanedData.secondaryMobile || 'N/A'}
Email: ${cleanedData.email || 'N/A'}
Address: ${cleanedData.address}
Pincode: ${cleanedData.pincode}

*Order Items:*
${orderItems}

*Order Summary:*
Subtotal: ₹${cartTotal.toFixed(2)}
${discountText}*Total Amount:* ₹${finalTotal.toFixed(2)}

*Payment Method:* Cash on Delivery
        `.trim().replace(/\n\s*\n/g, '\n\n');
        
        const { data: newSubmission, error } = await addSubmission({
            type: 'Retail Order',
            message: message,
            customer_name: cleanedData.name,
            customer_mobile: cleanedData.mobile,
            customer_address: cleanedData.address,
            customer_pincode: cleanedData.pincode,
            total_amount: finalTotal,
            payment_method: 'Cash on Delivery'
        });

        if (newSubmission) {
            const finalMessage = `Order ID: #${newSubmission.id}\n\n${message}`;
            const whatsappUrl = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(finalMessage)}`;
            window.open(whatsappUrl, '_blank');

            clearCart();
            onOrderPlaced(cleanedData.name, newSubmission.id, 'Cash on Delivery');
        } else {
            // The global DatabaseErrorScreen is handling this. This log is for debugging.
            console.warn("Order placement failed (UI will show details):", error);
        }
        setIsSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="header.checkout" onBack={onBack} />
      <main className="flex-grow overflow-y-auto p-4">
        <form id="checkout-form" onSubmit={handleSubmit} noValidate>
          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-lg font-semibold border-b pb-2 mb-4">Shipping Information</h2>
            <div className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
                <input 
                    type="text" 
                    id="name" 
                    required 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    className={`mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 ${nameError ? 'border-red-500' : ''}`}
                />
                {nameError && <p className="text-xs text-red-600 mt-1">{nameError}</p>}
              </div>
              <div>
                <label htmlFor="mobile" className="block text-sm font-medium text-gray-700">Mobile Number</label>
                <input 
                  type="tel" 
                  id="mobile" 
                  required 
                  value={mobile} 
                  onChange={(e) => handleMobileChange(e, false)} 
                  maxLength={10}
                  className={`mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 ${mobileError ? 'border-red-500' : ''}`}
                />
                {mobileError && <p className="text-xs text-red-600 mt-1">{mobileError}</p>}
              </div>
               <div>
                <label htmlFor="secondaryMobile" className="block text-sm font-medium text-gray-700">Secondary Mobile (Optional)</label>
                <input 
                  type="tel" 
                  id="secondaryMobile" 
                  value={secondaryMobile} 
                  onChange={(e) => handleMobileChange(e, true)}
                  maxLength={10}
                  className={`mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 ${secondaryMobileError ? 'border-red-500' : ''}`}
                />
                {secondaryMobileError && <p className="text-xs text-red-600 mt-1">{secondaryMobileError}</p>}
              </div>
               <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email (Optional)</label>
                <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" />
              </div>
              <div>
                <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
                <textarea 
                    id="address" 
                    rows={3} 
                    required 
                    value={address} 
                    onChange={(e) => setAddress(e.target.value)} 
                    className={`mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 ${addressError ? 'border-red-500' : ''}`}
                ></textarea>
                {addressError && <p className="text-xs text-red-600 mt-1">{addressError}</p>}
              </div>
               <div>
                <label htmlFor="pincode" className="block text-sm font-medium text-gray-700">Pincode</label>
                <input 
                  type="tel" 
                  id="pincode" 
                  required 
                  value={pincode} 
                  onChange={handlePincodeChange}
                  maxLength={6}
                  className={`mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 ${pincodeError ? 'border-red-500' : ''}`} 
                />
                {pincodeError && <p className="text-xs text-red-600 mt-1">{pincodeError}</p>}
              </div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mt-4">
            <h2 className="text-lg font-semibold border-b pb-2 mb-4">Payment Method</h2>
            <div className="space-y-2">
              <label className={`flex items-center p-3 rounded-lg border cursor-pointer ${paymentMethod === 'cod' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}>
                <input type="radio" name="payment" value="cod" checked={paymentMethod === 'cod'} onChange={(e) => setPaymentMethod(e.target.value)} className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" />
                <span className="ml-3 text-sm font-medium text-gray-800">Cash on Delivery (COD)</span>
              </label>
              <label className={`flex items-center p-3 rounded-lg border cursor-pointer ${paymentMethod === 'online' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}>
                <input type="radio" name="payment" value="online" checked={paymentMethod === 'online'} onChange={(e) => setPaymentMethod(e.target.value)} className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" />
                <span className="ml-3 text-sm font-medium text-gray-800">Pay Online (UPI, Cards, etc.)</span>
              </label>
            </div>
          </div>
        </form>
      </main>
      <footer className="p-4 bg-white border-t border-gray-200">
        <button 
          type="submit" 
          form="checkout-form" 
          disabled={isSubmitting}
          className="w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400"
        >
          {isSubmitting ? 'Placing Order...' : (paymentMethod === 'cod' ? 'Place Order & Send on WhatsApp' : 'Proceed to Payment')}
        </button>
      </footer>
    </div>
  );
};

export default RetailCheckoutScreen;