import React, { useState } from 'react';
import Header from '../../components/Header';
import { useShoppingCart } from '../../hooks/useShoppingCart';
import { ADMIN_WHATSAPP_NUMBER } from '../../constants';
import { useSubmissions } from '../../hooks/useSubmissions';
import { CheckoutData } from './RetailFlow';
import { useLanguage } from '../../hooks/useLanguage';

interface RetailPaymentScreenProps {
  onBack: () => void;
  onOrderConfirmed: (customerName: string, orderId: number, paymentMethod: string) => void;
  checkoutData: CheckoutData;
}

const UPI_ID = 'contact2ht@oksbi';
const BRAND_NAME = 'Jhelum Spices';

const RetailPaymentScreen: React.FC<RetailPaymentScreenProps> = ({ onBack, onOrderConfirmed, checkoutData }) => {
  const { clearCart } = useShoppingCart();
  const { addSubmission } = useSubmissions();
  const { t } = useLanguage();
  const [isConfirming, setIsConfirming] = useState(false);
  
  const { 
    name, 
    mobile, 
    secondaryMobile, 
    email, 
    address, 
    pincode, 
    cartItems, 
    totalAmount, // This is the finalTotal
    subtotal,
    discountCode,
    discountAmount
  } = checkoutData;

  const upiLink = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(BRAND_NAME)}&am=${totalAmount.toFixed(2)}`;
  
  const handleConfirm = async () => {
    setIsConfirming(true);

    const orderItems = cartItems.map(item => 
      `- ${t(`products.${item.product.id}.name`, item.product.name)} (${item.size.size}) x ${item.quantity} = ₹${item.size.price * item.quantity}`
    ).join('\n');

    const discountText = discountCode && discountAmount
      ? `Discount (${discountCode}): -₹${discountAmount.toFixed(2)}\n`
      : '';

    const messageForDb = `
New Retail Order from Jhelum Spices App!

*Customer Details:*
Name: ${name}
Mobile: ${mobile}
Secondary Mobile: ${secondaryMobile || 'N/A'}
Email: ${email || 'N/A'}
Address: ${address}
Pincode: ${pincode}

*Order Items:*
${orderItems}

*Order Summary:*
Subtotal: ₹${subtotal.toFixed(2)}
${discountText}*Total Amount:* ₹${totalAmount.toFixed(2)}

*Payment Method:* Pay Online (Pending Confirmation)
*Transaction ID:* PENDING_WHATSAPP_CONFIRMATION
    `.trim().replace(/\n\s*\n/g, '\n\n');
    
    const { data: newSubmission, error } = await addSubmission({
        type: 'Retail Order',
        message: messageForDb,
        customer_name: name,
        customer_mobile: mobile,
        customer_address: address,
        customer_pincode: pincode,
        total_amount: totalAmount,
        payment_method: 'Pay Online',
        status: 'Pending Payment Confirmation',
        transaction_id: 'PENDING_WHATSAPP_CONFIRMATION'
    });
    
    if (newSubmission) {
        const messageForWhatsapp = `Hello Jhelum Spices,\n\nI have just completed the payment of ₹${totalAmount.toFixed(2)} for my Order ID: #${newSubmission.id}.\n\nPlease find the payment confirmation screenshot attached. Thank you!`;
        const whatsappUrl = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(messageForWhatsapp)}`;
        
        window.open(whatsappUrl, '_blank');
        clearCart();
        onOrderConfirmed(name, newSubmission.id, 'Pay Online');
    } else {
        console.warn("Order confirmation failed (UI will show details):", error);
    }
    setIsConfirming(false);
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="header.completePayment" onBack={onBack} />
      <main className="flex-grow overflow-y-auto p-4 text-center">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="mb-4">
                <p className="text-sm text-gray-600">Total Amount to Pay</p>
                <p className="text-4xl font-bold text-gray-900 tracking-tight">
                    ₹{totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
            </div>
            <h2 className="text-lg font-semibold text-gray-800">1. Pay using any UPI App</h2>
            <div className="my-4 p-4 bg-gray-100 border border-gray-200 rounded-lg">
                <p className="text-sm text-gray-600">Pay to UPI ID:</p>
                <p className="text-xl font-bold text-gray-900 select-all font-mono tracking-wider">{UPI_ID}</p>
            </div>

            <a 
                href={upiLink}
                className="mt-4 inline-block w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
                Pay with UPI App
            </a>
            <p className="text-xs text-gray-500 mt-2">(For mobile users with UPI apps installed)</p>
        </div>

        <div className="bg-blue-50 p-6 rounded-lg shadow-sm border-2 border-blue-200 mt-4">
            <h3 className="text-lg font-bold text-blue-800 flex items-center justify-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                2. Important Final Step
            </h3>
            <p className="text-sm text-gray-700 mt-2 leading-relaxed">
                After you have paid, tap the big button below to open WhatsApp.
                <br />
                You must then <strong className="underline">manually attach your payment screenshot</strong> in the WhatsApp chat and send it to us.
            </p>
            <p className="text-xs text-blue-600 mt-2">Your order will only be confirmed after we verify your screenshot.</p>
        </div>
      </main>
      <footer className="p-4 bg-white border-t border-gray-200">
        <button 
            onClick={handleConfirm}
            disabled={isConfirming}
            className="w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.894 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 4.315 1.847 6.033l-1.011 3.713 3.717-1.005zm-2.905-7.446c-.187-.306-.307-.514-.424-.514h-.105c-.117 0-.273.085-.411.272-.136.186-.532.512-.532 1.229 0 .718.544 1.424.618 1.522.072.099 1.03 1.636 2.512 2.213.37.142.66.187.82.232.26.072.518.062.71.037.217-.037.533-.217.604-.424s.072-.466.05-.514c-.02-.048-.117-.073-.254-.121-.137-.048-1.29-.636-1.492-.707-.202-.072-.347-.121-.492.121-.121.22-.492.707-.604.832-.113.125-.226.142-.37.099-.144-.043-.631-.237-1.2-.742-.44-.389-.723-.886-.811-1.034s-.089-.225-.011-.347c.079-.121.166-.202.226-.263.06-.062.121-.107.18-.182.06-.075.03-.125-.01-.182-.04-.058-.493-1.176-.673-1.612z" /></svg>
          {isConfirming ? 'Submitting...' : 'I have paid, Confirm via WhatsApp'}
        </button>
      </footer>
    </div>
  );
};

export default RetailPaymentScreen;