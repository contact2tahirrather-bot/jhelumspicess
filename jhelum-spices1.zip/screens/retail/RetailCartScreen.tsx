import React, { useState } from 'react';
import Header from '../../components/Header';
import { useShoppingCart } from '../../hooks/useShoppingCart';
import { DISCOUNT_CODES, AUTOMATIC_DISCOUNT_MINIMUM_AMOUNT } from '../../constants';
import { useLanguage } from '../../hooks/useLanguage';

interface RetailCartScreenProps {
  onBack: () => void;
  onGoToCheckout: () => void;
}

const RetailCartScreen: React.FC<RetailCartScreenProps> = ({ onBack, onGoToCheckout }) => {
  const { 
    cartItems, 
    updateQuantity, 
    removeFromCart, 
    clearCart, 
    cartTotal,
    applyDiscount,
    removeDiscount,
    discountCode,
    discountAmount,
    finalTotal,
  } = useShoppingCart();
  const { t } = useLanguage();
  
  const [promoCodeInput, setPromoCodeInput] = useState('');
  const [promoMessage, setPromoMessage] = useState<{ text: string, type: 'success' | 'error' } | null>(null);

  const appliedDiscountDetails = discountCode ? DISCOUNT_CODES.find(d => d.code === discountCode) : null;

  const handleApplyPromoCode = (codeToApply: string) => {
    if (!codeToApply.trim()) return;

    const result = applyDiscount(codeToApply);
    if (result.success) {
        setPromoMessage({ text: result.message, type: 'success' });
        setPromoCodeInput('');
    } else {
        setPromoMessage({ text: result.message, type: 'error' });
    }
  };
  
  const handleRemovePromoCode = () => {
      removeDiscount();
      setPromoCodeInput('');
      setPromoMessage(null);
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="header.yourCart" onBack={onBack} />
      {cartItems.length === 0 ? (
        <div className="flex-grow flex flex-col items-center justify-center text-center p-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          <h2 className="mt-4 text-xl font-semibold text-gray-700">Your cart is empty</h2>
          <p className="mt-2 text-gray-500">Looks like you haven't added anything to your cart yet.</p>
          <button onClick={onBack} className="mt-6 bg-blue-600 text-white font-semibold py-2 px-6 rounded-lg hover:bg-blue-700 transition-colors">
            Start Shopping
          </button>
        </div>
      ) : (
        <>
          <main className="flex-grow overflow-y-auto p-4">
            <div className="flex justify-end items-center mb-4">
                <button onClick={clearCart} className="text-sm text-red-600 hover:underline">Clear Cart</button>
            </div>
            <ul className="divide-y divide-gray-200">
              {cartItems.map(item => (
                <li key={`${item.product.id}-${item.size.size}`} className="flex py-4 items-center gap-4">
                  <img src={item.product.imageUrl} alt={item.product.name} className="w-16 h-16 object-cover rounded-md flex-shrink-0" />
                  <div className="flex-grow">
                    <h3 className="font-semibold text-gray-800">{t(`products.${item.product.id}.name`, item.product.name)}</h3>
                    <p className="text-sm text-gray-500">{item.size.size} - ₹{item.size.price}</p>
                     <p className="text-sm font-semibold text-gray-700 mt-1">Subtotal: ₹{item.size.price * item.quantity}</p>
                  </div>
                  <div className="flex items-center">
                     <input 
                      type="number"
                      value={item.quantity}
                      min="1"
                      onChange={(e) => updateQuantity(item.product.id, item.size.size, parseInt(e.target.value))}
                      className="w-16 text-center border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                    <button onClick={() => removeFromCart(item.product.id, item.size.size)} className="ml-2 p-1 text-gray-400 hover:text-blue-500">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </li>
              ))}
            </ul>
            
            {cartTotal >= AUTOMATIC_DISCOUNT_MINIMUM_AMOUNT && !discountCode && (
                <div className="mt-6 p-4 bg-green-50 border-2 border-dashed border-green-400 rounded-lg text-center">
                    <p className="font-semibold text-green-800">You've unlocked a special offer!</p>
                    <p className="text-sm text-green-700 mt-1">Your order is over ₹{AUTOMATIC_DISCOUNT_MINIMUM_AMOUNT}.</p>
                    <button
                        onClick={() => handleApplyPromoCode('SPECIALOFFER10')}
                        className="mt-3 bg-green-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-700 transition-colors shadow-md"
                    >
                        Apply 6% Discount
                    </button>
                </div>
            )}
            
            <div className="my-6 text-center">
                <button 
                    onClick={onBack} 
                    className="bg-red-600 text-white font-semibold py-2 px-6 rounded-lg hover:bg-red-700 transition-colors"
                >
                    Add More Items
                </button>
            </div>

            {!discountCode && (
                 <div className="mt-6 p-4 bg-white rounded-lg border border-gray-200">
                    <label htmlFor="promo-code" className="text-sm font-medium text-gray-700">Enter Promo Code</label>
                    <div className="mt-1 flex rounded-md shadow-sm">
                        <input
                            type="text"
                            id="promo-code"
                            value={promoCodeInput}
                            onChange={(e) => setPromoCodeInput(e.target.value.toUpperCase())}
                            className="flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-l-md focus:ring-blue-500 focus:border-blue-500 sm:text-sm border-gray-300"
                            placeholder="HAVE A CODE?"
                        />
                        <button
                            type="button"
                            onClick={() => handleApplyPromoCode(promoCodeInput)}
                            disabled={!promoCodeInput}
                            className="inline-flex items-center px-4 py-2 border border-transparent rounded-r-md bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-1 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
                        >
                            Apply
                        </button>
                    </div>
                     {promoMessage && (
                        <p className={`mt-2 text-sm ${promoMessage.type === 'success' ? 'text-green-600' : 'text-red-600'}`}>
                            {promoMessage.text}
                        </p>
                    )}
                </div>
            )}
          </main>
          <footer className="p-4 bg-white border-t border-gray-200">
             <div className="space-y-2 mb-4">
                <div className="flex justify-between items-center text-gray-700">
                    <span>Subtotal:</span>
                    <span>₹{cartTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                
                {appliedDiscountDetails && cartTotal < appliedDiscountDetails.minimumAmount && (
                    <div className="text-center text-sm text-orange-600 bg-orange-50 p-2 rounded-md my-2">
                        Add items worth ₹{(appliedDiscountDetails.minimumAmount - cartTotal).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} more to keep your discount.
                    </div>
                )}
                
                {discountCode && discountAmount > 0 && (
                    <div className="flex justify-between items-center text-green-600 font-medium">
                        <span>Discount ({appliedDiscountDetails?.description}):</span>
                        <span>- ₹{discountAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                )}
                <div className="flex justify-between items-center text-gray-900 border-t pt-2">
                    <span className="text-lg font-semibold">Total:</span>
                    <span className="text-xl font-bold">₹{finalTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                 {discountCode && (
                    <button onClick={handleRemovePromoCode} className="text-xs text-blue-600 hover:underline">Remove Discount</button>
                )}
            </div>
            <button onClick={onGoToCheckout} className="w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors">
              Proceed to Checkout
            </button>
          </footer>
        </>
      )}
    </div>
  );
};

export default RetailCartScreen;