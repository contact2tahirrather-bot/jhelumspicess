

import React, { useState } from 'react';
import Header from '../../components/Header';
import Logo from '../../components/Logo';
import { ADMIN_PASSWORD } from '../../constants';

interface AdminLoginScreenProps {
  onBack: () => void;
  onLoginSuccess: () => void;
}

const AdminLoginScreen: React.FC<AdminLoginScreenProps> = ({ onBack, onLoginSuccess }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setError('');
      onLoginSuccess();
    } else {
      setError('Incorrect password. Please try again.');
      setPassword('');
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <Header title="Admin Access" onBack={onBack} hideLanguageSwitcher />
      <main className="flex-grow flex flex-col items-center justify-center p-6">
        <Logo className="w-24 h-24" />
        <h2 className="text-2xl font-bold text-gray-800 mt-4">Administrator Login</h2>
        <form onSubmit={handleSubmit} className="w-full max-w-xs mt-8 space-y-4">
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-gray-500 focus:border-gray-500"
              required
            />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            className="w-full bg-gray-800 text-white font-semibold py-2 rounded-lg hover:bg-gray-900 transition-colors"
          >
            Login
          </button>
        </form>
      </main>
    </div>
  );
};

export default AdminLoginScreen;