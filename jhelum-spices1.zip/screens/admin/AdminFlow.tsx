import React, { useState } from 'react';
import AdminLoginScreen from './AdminLoginScreen';
import AdminDashboardScreen from './AdminDashboardScreen';
import AdminReportsScreen from './AdminReportsScreen';
import AdminManageRidersScreen from './AdminManageRidersScreen';
import AdminManageWholesaleScreen from './AdminManageWholesaleScreen';

interface AdminFlowProps {
  onBackToHome: () => void;
}

type AdminScreen = 'dashboard' | 'reports' | 'manageRiders' | 'manageWholesale';

const AdminFlow: React.FC<AdminFlowProps> = ({ onBackToHome }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [screen, setScreen] = useState<AdminScreen>('dashboard');

  if (!isAuthenticated) {
    return <AdminLoginScreen onBack={onBackToHome} onLoginSuccess={() => setIsAuthenticated(true)} />;
  }

  switch (screen) {
    case 'reports':
      return <AdminReportsScreen onBack={() => setScreen('dashboard')} />;
    case 'manageRiders':
      return <AdminManageRidersScreen onBack={() => setScreen('dashboard')} />;
    case 'manageWholesale':
      return <AdminManageWholesaleScreen onBack={() => setScreen('dashboard')} />;
    case 'dashboard':
    default:
      return <AdminDashboardScreen 
        onBack={onBackToHome} 
        onGoToReports={() => setScreen('reports')} 
        onGoToManageRiders={() => setScreen('manageRiders')}
        onGoToManageWholesale={() => setScreen('manageWholesale')}
      />;
  }
};

export default AdminFlow;