import React, { useState, useEffect } from 'react';
import Header from '../../components/Header';
import { WholesaleUser } from '../../types';
import { supabase } from '../../lib/supabaseClient';

interface AdminManageWholesaleScreenProps {
  onBack: () => void;
}

const AdminManageWholesaleScreen: React.FC<AdminManageWholesaleScreenProps> = ({ onBack }) => {
  const [users, setUsers] = useState<WholesaleUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Form state
  const [businessName, setBusinessName] = useState('');
  const [password, setPassword] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  
  // Edit and submission state
  const [editingUser, setEditingUser] = useState<WholesaleUser | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionError, setSubmissionError] = useState<string | null>(null);

  const handleSupabaseError = (error: any) => {
    const lowerErrorMessage = error.message.toLowerCase();

    if (lowerErrorMessage.includes('relation') && lowerErrorMessage.includes('does not exist')) {
        setError('Database Update Required.\n\nThe "wholesale_users" table is missing. Please run the full SQL setup script from `lib/supabaseClient.ts` in your Supabase SQL Editor to create it.');
    } else if (lowerErrorMessage.includes('permission denied')) { // RLS error
        setError('Permission Denied.\n\nPlease ensure Row Level Security (RLS) is enabled and the correct policies are in place for the "wholesale_users" table. See `lib/supabaseClient.ts` for instructions.');
    } else {
        setError(`Failed to load users: ${error.message}.\n\nPlease check your internet connection and Supabase setup.`);
    }
  }

  const fetchUsers = async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from('wholesale_users')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching wholesale users:', error);
      handleSupabaseError(error);
    } else {
      setUsers(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchUsers();
  }, []);
  
  const resetForm = () => {
    setBusinessName('');
    setPassword('');
    setContactNumber('');
    setEditingUser(null);
    setSubmissionError(null);
  };
  
  const handleEditClick = (user: WholesaleUser) => {
    setEditingUser(user);
    setBusinessName(user.business_name);
    setPassword(user.password);
    setContactNumber(user.contact_number || '');
    setSubmissionError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionError(null);

    if (!businessName.trim() || !password.trim() || !contactNumber.trim()) {
      setSubmissionError('Please provide business name, password, and contact number.');
      return;
    }
    
    setIsSubmitting(true);
    try {
      if (editingUser) {
        // Update logic
        const { data, error } = await supabase
          .from('wholesale_users')
          .update({
            business_name: businessName.trim(),
            password: password.trim(),
            contact_number: contactNumber.trim()
          })
          .eq('id', editingUser.id)
          .select()
          .single();
        
        if (error) {
          console.error("Supabase update error:", error);
          const errorDetails = `Message: ${error.message}\nDetails: ${error.details || 'N/A'}`;
          setSubmissionError(`UPDATE FAILED:\n${errorDetails}\n\nThis is often due to a database security rule (RLS) or a unique constraint violation (duplicate business name). Please run the SQL script from the instructions.`);
        } else if (data) {
          setUsers(users.map(u => u.id === editingUser.id ? data : u));
          resetForm();
        } else {
          setSubmissionError("UPDATE FAILED: The operation completed without errors, but no data was returned. This strongly suggests a Row Level Security policy is preventing the action. Please run the SQL script from the instructions to fix your security policies.");
        }

      } else {
        // Add logic
        const { data, error } = await supabase
          .from('wholesale_users')
          .insert([{ 
            business_name: businessName.trim(), 
            password: password.trim(),
            contact_number: contactNumber.trim(),
          }])
          .select()
          .single();

        if (error) {
          console.error("Supabase insert error:", error);
          const errorDetails = `Message: ${error.message}\nDetails: ${error.details || 'N/A'}`;
          setSubmissionError(`ADD FAILED:\n${errorDetails}\n\nThis is often due to a database security rule (RLS) or a unique constraint violation (duplicate business name). Please run the SQL script from the instructions.`);
        } else if (data) {
          setUsers([data, ...users]);
          resetForm();
        } else {
          setSubmissionError("ADD FAILED: The operation completed without errors, but no data was returned. This strongly suggests a Row Level Security policy is preventing the action. Please run the SQL script from the instructions to fix your security policies.");
        }
      }
    } catch (e: any) {
      console.error("Unhandled error in handleSubmit:", e);
      setSubmissionError(`An unexpected error occurred: ${e.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteUser = async (userId: number) => {
    if (window.confirm('Are you sure you want to delete this wholesale user?')) {
      setSubmissionError(null);
      const { error } = await supabase
        .from('wholesale_users')
        .delete()
        .eq('id', userId);
      
      if (error) {
        console.error("Supabase delete error:", error);
        const errorDetails = `Message: ${error.message}\nDetails: ${error.details || 'N/A'}`;
        setSubmissionError(`DELETE FAILED:\n${errorDetails}\n\nThis is often due to a database security rule. Please ensure the latest SQL script has been run.`);
      } else {
        setUsers(users.filter(u => u.id !== userId));
        if (editingUser && editingUser.id === userId) {
            resetForm();
        }
      }
    }
  };

  const renderContent = () => {
    if (loading) {
      return <div className="text-center p-4">Loading wholesale users...</div>;
    }
    if (error) {
      return <div className="text-center p-4 text-red-600 bg-red-50 rounded-lg whitespace-pre-wrap">{error}</div>;
    }
    return (
      <div className="space-y-4">
        <form onSubmit={handleSubmit} className="p-4 bg-white rounded-lg border border-gray-200 shadow-sm space-y-4">
          <h3 className="font-semibold text-lg text-gray-800">{editingUser ? 'Edit Wholesale User' : 'Add New Wholesale User'}</h3>
          <div className="grid sm:grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="businessName" className="block text-sm font-medium text-gray-700 mb-1">Business Name</label>
              <input 
                id="businessName"
                type="text" 
                placeholder="Business Name"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className="border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 w-full"
                required
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input 
                id="password"
                type="text" 
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 w-full"
                required
              />
            </div>
            <div>
              <label htmlFor="contactNumber" className="block text-sm font-medium text-gray-700 mb-1">Contact Number</label>
              <input 
                id="contactNumber"
                type="tel" 
                placeholder="e.g., 91..."
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                className="border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 w-full"
                required
              />
            </div>
          </div>

          {submissionError && (
            <div className="p-3 my-2 bg-red-50 border border-red-300 text-red-800 text-sm rounded-lg whitespace-pre-wrap">
              {submissionError}
            </div>
          )}
          
          <div className="flex items-center gap-4 pt-2">
             <button type="submit" disabled={isSubmitting} className="w-full bg-purple-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed">
              {isSubmitting ? (editingUser ? 'Updating...' : 'Adding...') : (editingUser ? 'Update User' : 'Add User')}
            </button>
            {editingUser && (
                <button type="button" onClick={resetForm} className="w-full bg-gray-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors">
                    Cancel Edit
                </button>
            )}
          </div>
        </form>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <h3 className="font-semibold text-lg text-gray-800 mb-2">Existing Users</h3>
          <ul className="divide-y divide-gray-200">
            {users.length === 0 ? (
              <li className="py-3 text-sm text-gray-500">No wholesale users added yet.</li>
            ) : (
              users.map(user => (
                <li key={user.id} className="py-3 flex justify-between items-center flex-wrap gap-2">
                  <div className="flex-grow">
                    <p className="font-medium text-gray-800">{user.business_name}</p>
                    <div className="text-sm text-gray-500 space-x-4">
                        <span>Password: <span className="font-mono bg-gray-100 px-1 rounded">{user.password}</span></span>
                        {user.contact_number && <span>Contact: <span className="font-medium">{user.contact_number}</span></span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                     <button onClick={() => handleEditClick(user)} className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        Edit
                    </button>
                    <button onClick={() => handleDeleteUser(user.id)} className="text-red-500 hover:text-red-700 text-sm font-medium">
                        Delete
                    </button>
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="Manage Wholesale" onBack={onBack} hideLanguageSwitcher />
      <main className="flex-grow overflow-y-auto p-4">
        {renderContent()}
      </main>
    </div>
  );
};

export default AdminManageWholesaleScreen;