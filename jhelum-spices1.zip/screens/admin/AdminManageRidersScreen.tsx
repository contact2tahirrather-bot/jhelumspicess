import React, { useState, useEffect } from 'react';
import Header from '../../components/Header';
import { Rider } from '../../types';
import { supabase } from '../../lib/supabaseClient';

interface AdminManageRidersScreenProps {
  onBack: () => void;
}

const AdminManageRidersScreen: React.FC<AdminManageRidersScreenProps> = ({ onBack }) => {
  const [riders, setRiders] = useState<Rider[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [newRiderName, setNewRiderName] = useState('');
  const [newRiderPassword, setNewRiderPassword] = useState('');
  const [newRiderContact, setNewRiderContact] = useState('');

  const fetchRiders = async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from('riders')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching riders:', error);
      setError(`Failed to load riders: ${error.message}`);
    } else {
      setRiders(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchRiders();
  }, []);

  const handleAddRider = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRiderName.trim() || !newRiderPassword.trim() || !newRiderContact.trim()) {
      alert('Please provide a name, password, and contact number for the new rider.');
      return;
    }

    const { data, error } = await supabase
      .from('riders')
      .insert([{ 
        name: newRiderName.trim(), 
        password: newRiderPassword.trim(),
        contact_number: newRiderContact.trim()
      }])
      .select()
      .single();

    if (error) {
      alert(`Error adding rider: ${error.message}`);
    } else if (data) {
      setRiders([data, ...riders]);
      setNewRiderName('');
      setNewRiderPassword('');
      setNewRiderContact('');
    }
  };

  const handleDeleteRider = async (riderId: number) => {
    if (window.confirm('Are you sure you want to delete this rider? This will unassign them from any active orders.')) {
      const { error } = await supabase
        .from('riders')
        .delete()
        .eq('id', riderId);
      
      if (error) {
        alert(`Error deleting rider: ${error.message}`);
      } else {
        setRiders(riders.filter(r => r.id !== riderId));
      }
    }
  };

  const renderContent = () => {
    if (loading) {
      return <div className="text-center p-4">Loading riders...</div>;
    }
    if (error) {
      return <div className="text-center p-4 text-red-600 bg-red-50 rounded-lg">{error}</div>;
    }
    return (
      <div className="space-y-4">
        <form onSubmit={handleAddRider} className="p-4 bg-white rounded-lg border border-gray-200 shadow-sm space-y-3">
          <h3 className="font-semibold text-lg text-gray-800">Add New Rider</h3>
          <div className="grid sm:grid-cols-3 gap-4">
            <input 
              type="text" 
              placeholder="Rider Name"
              value={newRiderName}
              onChange={(e) => setNewRiderName(e.target.value)}
              className="border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
            <input 
              type="text" 
              placeholder="Password"
              value={newRiderPassword}
              onChange={(e) => setNewRiderPassword(e.target.value)}
              className="border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
             <input 
              type="tel" 
              placeholder="Contact Number"
              value={newRiderContact}
              onChange={(e) => setNewRiderContact(e.target.value)}
              className="border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>
          <button type="submit" className="w-full bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
            Add Rider
          </button>
        </form>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <h3 className="font-semibold text-lg text-gray-800 mb-2">Existing Riders</h3>
          <ul className="divide-y divide-gray-200">
            {riders.length === 0 ? (
              <li className="py-3 text-sm text-gray-500">No riders added yet.</li>
            ) : (
              riders.map(rider => (
                <li key={rider.id} className="py-3 flex justify-between items-center">
                  <div>
                    <p className="font-medium text-gray-800">{rider.name}</p>
                    <div className="text-sm text-gray-500 space-x-4">
                        <span>Password: <span className="font-mono bg-gray-100 px-1 rounded">{rider.password}</span></span>
                        {rider.contact_number && <span>Contact: <span className="font-medium">{rider.contact_number}</span></span>}
                    </div>
                  </div>
                  <button onClick={() => handleDeleteRider(rider.id)} className="text-red-500 hover:text-red-700 text-sm font-medium">
                    Delete
                  </button>
                </li>
              ))
            )}
          </ul>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="Manage Riders" onBack={onBack} hideLanguageSwitcher />
      <main className="flex-grow overflow-y-auto p-4">
        {renderContent()}
      </main>
    </div>
  );
};

export default AdminManageRidersScreen;