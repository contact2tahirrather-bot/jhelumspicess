import React, { useState, useEffect, useMemo } from 'react';
import Header from '../../components/Header';
import { Submission, WholesaleOrder } from '../../types';
import { supabase } from '../../lib/supabaseClient';

interface AdminReportsScreenProps {
  onBack: () => void;
}

interface RetailReportData {
  totalRevenue: number;
  totalOrders: number;
  averageOrderValue: number;
  topSellingProducts: { name: string; count: number }[];
  dailySales: { date: string; total: number; orders: number }[];
}

interface WholesaleReportData {
    totalRevenue: number;
    totalOrders: number;
    totalDeliveredOrders: number;
    averageOrderValue: number;
    topPartners: { name: string; totalValue: number; totalOrders: number; }[];
    dailySales: { date: string; total: number; orders: number; }[];
}

interface WazwanReportData {
    totalEnquiries: number;
    totalGuests: number;
    dailyEnquiries: { date: string; count: number }[];
}


const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex items-center">
        <div className="p-3 rounded-full bg-teal-100 text-teal-600 mr-4">
            {icon}
        </div>
        <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className="text-2xl font-semibold text-gray-800">{value}</p>
        </div>
    </div>
);

const AdminReportsScreen: React.FC<AdminReportsScreenProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'retail' | 'wholesale' | 'wazwan'>('retail');
  
  const [retailOrders, setRetailOrders] = useState<Submission[]>([]);
  const [wholesaleOrders, setWholesaleOrders] = useState<WholesaleOrder[]>([]);
  const [wazwanEnquiries, setWazwanEnquiries] = useState<Submission[]>([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAllData = async () => {
      setLoading(true);
      setError(null);
      const [retailRes, wholesaleRes, wazwanRes] = await Promise.all([
        supabase.from('submissions').select('*').eq('type', 'Retail Order'),
        supabase.from('wholesale_orders').select('*, wholesale_users(business_name)'),
        supabase.from('submissions').select('*').eq('type', 'Wazwan Enquiry')
      ]);

      let errors: string[] = [];
      if (retailRes.error) errors.push(`Retail: ${retailRes.error.message}`);
      if (wholesaleRes.error) errors.push(`Wholesale: ${wholesaleRes.error.message}`);
      if (wazwanRes.error) errors.push(`Wazwan: ${wazwanRes.error.message}`);
      
      if (errors.length > 0) {
        setError(`Failed to load some report data:\n- ${errors.join('\n- ')}`);
      }

      setRetailOrders(retailRes.data || []);
      setWholesaleOrders(wholesaleRes.data || []);
      setWazwanEnquiries(wazwanRes.data || []);
      setLoading(false);
    };

    fetchAllData();
  }, []);

  const retailReportData = useMemo<RetailReportData | null>(() => {
    if (retailOrders.length === 0) return null;

    let totalRevenue = 0;
    const productCounts: Record<string, number> = {};
    const dailySales: Record<string, { total: number; orders: number }> = {};

    retailOrders.forEach(order => {
        const amount = order.total_amount || 0;
        totalRevenue += amount;
        
        const date = new Date(order.created_at).toLocaleDateString('en-CA'); // YYYY-MM-DD
        if (!dailySales[date]) dailySales[date] = { total: 0, orders: 0 };
        dailySales[date].total += amount;
        dailySales[date].orders += 1;

        const itemsMatch = order.message.match(/\*Order Items:\*\n([\s\S]*?)\n\*Order Summary:\*/);
        if (itemsMatch && itemsMatch[1]) {
            const itemsText = itemsMatch[1];
            const itemLines = itemsText.split('\n').filter(line => line.startsWith('- '));
            itemLines.forEach(line => {
                const productMatch = line.match(/- ([\w\s()]+) \(/);
                if (productMatch && productMatch[1]) {
                    const productName = productMatch[1].trim();
                    productCounts[productName] = (productCounts[productName] || 0) + 1;
                }
            });
        }
    });

    const totalOrders = retailOrders.length;
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

    const topSellingProducts = Object.entries(productCounts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
    
    const dailySalesArray = Object.entries(dailySales)
        .map(([date, data]) => ({ date, ...data }))
        .sort((a,b) => b.date.localeCompare(a.date));

    return { totalRevenue, totalOrders, averageOrderValue, topSellingProducts, dailySales: dailySalesArray };
  }, [retailOrders]);
  
  const wholesaleReportData = useMemo<WholesaleReportData | null>(() => {
    if (wholesaleOrders.length === 0) return null;

    const deliveredOrders = wholesaleOrders.filter(o => o.status === 'Delivered');
    const totalRevenue = deliveredOrders.reduce((sum, order) => sum + order.total_amount, 0);
    const totalOrders = wholesaleOrders.length;
    const averageOrderValue = deliveredOrders.length > 0 ? totalRevenue / deliveredOrders.length : 0;
    
    const partnerPerformance: Record<string, { totalValue: number, totalOrders: number }> = {};
    deliveredOrders.forEach(order => {
        const partnerName = order.wholesale_users?.business_name || 'Unknown Partner';
        if (!partnerPerformance[partnerName]) partnerPerformance[partnerName] = { totalValue: 0, totalOrders: 0 };
        partnerPerformance[partnerName].totalValue += order.total_amount;
        partnerPerformance[partnerName].totalOrders += 1;
    });

    const topPartners = Object.entries(partnerPerformance)
        .map(([name, data]) => ({ name, ...data }))
        .sort((a, b) => b.totalValue - a.totalValue)
        .slice(0, 5);

    const dailySales: Record<string, { total: number; orders: number }> = {};
    deliveredOrders.forEach(order => {
        const date = new Date(order.created_at).toLocaleDateString('en-CA');
        if (!dailySales[date]) dailySales[date] = { total: 0, orders: 0 };
        dailySales[date].total += order.total_amount;
        dailySales[date].orders += 1;
    });
    
    const dailySalesArray = Object.entries(dailySales).map(([date, data]) => ({ date, ...data })).sort((a,b) => b.date.localeCompare(a.date));

    return { totalRevenue, totalOrders, totalDeliveredOrders: deliveredOrders.length, averageOrderValue, topPartners, dailySales: dailySalesArray };
  }, [wholesaleOrders]);

  const wazwanReportData = useMemo<WazwanReportData | null>(() => {
    if (wazwanEnquiries.length === 0) return null;
    
    const totalEnquiries = wazwanEnquiries.length;
    let totalGuests = 0;
    const dailyEnquiries: Record<string, number> = {};

    wazwanEnquiries.forEach(enquiry => {
        const date = new Date(enquiry.created_at).toLocaleDateString('en-CA');
        dailyEnquiries[date] = (dailyEnquiries[date] || 0) + 1;
        const guestMatch = enquiry.message.match(/Approx\. \*(.+?)\* Trami \/ Guests/);
        if (guestMatch && guestMatch[1]) totalGuests += parseInt(guestMatch[1], 10) || 0;
    });

    const dailyEnquiriesArray = Object.entries(dailyEnquiries).map(([date, count]) => ({ date, count })).sort((a,b) => b.date.localeCompare(a.date));

    return { totalEnquiries, totalGuests, dailyEnquiries: dailyEnquiriesArray };
  }, [wazwanEnquiries]);


  const renderRetailReport = () => {
    if (!retailReportData) return <div className="text-center p-8 text-gray-600">No retail orders found.</div>;
    const { totalRevenue, totalOrders, averageOrderValue, topSellingProducts, dailySales } = retailReportData;
    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <StatCard title="Total Revenue" value={`₹${totalRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01" /></svg>} />
                <StatCard title="Total Orders" value={totalOrders.toString()} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>} />
                <StatCard title="Avg. Order Value" value={`₹${averageOrderValue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>} />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                 <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><h3 className="text-lg font-semibold text-gray-800 mb-3">Top Selling Products</h3><ul className="divide-y divide-gray-200">{topSellingProducts.map((p, i) => <li key={p.name} className="py-2 flex justify-between items-center text-sm"><span className="text-gray-600">{i + 1}. {p.name}</span><span className="font-semibold text-gray-800">{p.count} orders</span></li>)}</ul></div>
                 <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><h3 className="text-lg font-semibold text-gray-800 mb-3">Daily Sales</h3><div className="overflow-x-auto max-h-96"><table className="min-w-full"><thead><tr><th className="text-left text-xs font-semibold text-gray-600 uppercase p-2">Date</th><th className="text-right text-xs font-semibold text-gray-600 uppercase p-2">Orders</th><th className="text-right text-xs font-semibold text-gray-600 uppercase p-2">Total</th></tr></thead><tbody className="divide-y divide-gray-200">{dailySales.map(d => <tr key={d.date}><td>{new Date(d.date.replace(/-/g, '/')).toLocaleDateString('en-GB')}</td><td className="text-right">{d.orders}</td><td className="text-right">₹{d.total.toLocaleString('en-IN')}</td></tr>)}</tbody></table></div></div>
            </div>
        </div>
    );
  }
  
  const renderWholesaleReport = () => {
    if (!wholesaleReportData) return <div className="text-center p-8 text-gray-600">No wholesale orders found.</div>;
    const { totalRevenue, totalOrders, totalDeliveredOrders, averageOrderValue, topPartners, dailySales } = wholesaleReportData;
    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <StatCard title="Total Revenue (Delivered)" value={`₹${totalRevenue.toLocaleString('en-IN')}`} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01" /></svg>} />
                <StatCard title="Total Orders (All Time)" value={totalOrders.toString()} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10l2 2h8a1 1 0 001-1zM3 11V9a1 1 0 011-1h4l3 3v7" /></svg>} />
                <StatCard title="Avg. Delivered Order" value={`₹${averageOrderValue.toLocaleString('en-IN')}`} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>} />
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><h3 className="text-lg font-semibold text-gray-800 mb-3">Top 5 Partners (by Revenue)</h3><ul className="divide-y divide-gray-200">{topPartners.map((p, i) => <li key={p.name} className="py-2 flex justify-between items-center text-sm"><span className="text-gray-600">{i + 1}. {p.name}</span><span className="font-semibold text-gray-800">₹{p.totalValue.toLocaleString('en-IN')}</span></li>)}</ul></div>
        </div>
    );
  }

  const renderWazwanReport = () => {
    if (!wazwanReportData) return <div className="text-center p-8 text-gray-600">No Wazwan enquiries found.</div>;
    const { totalEnquiries, totalGuests, dailyEnquiries } = wazwanReportData;
    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <StatCard title="Total Enquiries" value={totalEnquiries.toLocaleString()} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" /><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" /></svg>} />
                <StatCard title="Total Guests Quoted For" value={totalGuests.toLocaleString()} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" /></svg>} />
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><h3 className="text-lg font-semibold text-gray-800 mb-3">Daily Enquiries</h3><div className="overflow-x-auto max-h-96"><table className="min-w-full"><thead><tr><th className="text-left text-xs font-semibold text-gray-600 uppercase p-2">Date</th><th className="text-right text-xs font-semibold text-gray-600 uppercase p-2">Enquiries</th></tr></thead><tbody className="divide-y divide-gray-200">{dailyEnquiries.map(d => <tr key={d.date}><td>{new Date(d.date.replace(/-/g, '/')).toLocaleDateString('en-GB')}</td><td className="text-right">{d.count}</td></tr>)}</tbody></table></div></div>
        </div>
    );
  }

  const renderContent = () => {
    if (loading) return <div className="text-center p-8">Generating reports...</div>;
    if (error) return <div className="text-center p-8 text-red-600 bg-red-50 rounded-lg whitespace-pre-wrap">{error}</div>;

    switch (activeTab) {
        case 'retail': return renderRetailReport();
        case 'wholesale': return renderWholesaleReport();
        case 'wazwan': return renderWazwanReport();
        default: return null;
    }
  };

  const TabButton: React.FC<{tab: 'retail' | 'wholesale' | 'wazwan', children: React.ReactNode}> = ({ tab, children }) => {
    const isActive = activeTab === tab;
    return (
        <button
            onClick={() => setActiveTab(tab)}
            className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${
                isActive
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
        >
            {children}
        </button>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="Sales Reports" onBack={onBack} hideLanguageSwitcher />
      <main className="flex-grow overflow-y-auto p-4">
        <div className="border-b border-gray-200 mb-4">
            <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                <TabButton tab="retail">Retail Sales</TabButton>
                <TabButton tab="wholesale">Wholesale Sales</TabButton>
                <TabButton tab="wazwan">Wazwan Enquiries</TabButton>
            </nav>
        </div>
        {renderContent()}
      </main>
    </div>
  );
};

export default AdminReportsScreen;