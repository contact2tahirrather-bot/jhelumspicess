import React, { useState, useEffect, useMemo } from 'react';
import Header from '../../components/Header';
import { Submission, OrderStatus, Rider, WholesaleOrder, WholesaleOrderStatus } from '../../types';
import { supabase } from '../../lib/supabaseClient';
import { ADMIN_WHATSAPP_NUMBER } from '../../constants';

interface AdminDashboardScreenProps {
  onBack: () => void;
  onGoToReports: () => void;
  onGoToManageRiders: () => void;
  onGoToManageWholesale: () => void;
}

const TypeBadge: React.FC<{ type: Submission['type'] }> = ({ type }) => {
    const colors = {
        'Retail Order': 'bg-green-100 text-green-800',
        'Wholesale Application': 'bg-blue-100 text-blue-800',
        'Wholesale Enquiry': 'bg-blue-100 text-blue-800',
        'Wazwan Enquiry': 'bg-amber-100 text-amber-800',
        'Feedback': 'bg-purple-100 text-purple-800',
        'Customer Support': 'bg-orange-100 text-orange-800',
    };
    return (
        <span className={`px-2 py-1 text-xs font-medium rounded-full ${colors[type] || 'bg-gray-100 text-gray-800'}`}>
            {type}
        </span>
    );
};

const orderStatusOptions: OrderStatus[] = ['Pending', 'Pending Payment Confirmation', 'Processing', 'Out for Delivery', 'Delivered'];
const wholesaleStatusOptions: WholesaleOrderStatus[] = ['Pending', 'Confirmed', 'Out for Delivery', 'Delivered', 'Cancelled'];

const AdminDashboardScreen: React.FC<AdminDashboardScreenProps> = ({ onBack, onGoToReports, onGoToManageRiders, onGoToManageWholesale }) => {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [wholesaleOrders, setWholesaleOrders] = useState<WholesaleOrder[]>([]);
  const [riders, setRiders] = useState<Rider[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [currentView, setCurrentView] = useState<'submissions' | 'wholesale'>('submissions');

  const handleSupabaseError = (error: any) => {
    if (error.code === '42P01') { // undefined_table
      setError('Database setup needed.\n\nOne of the required tables (e.g., "submissions", "riders", "wholesale_orders") does not exist. Please follow the setup instructions in the `lib/supabaseClient.ts` file.');
    } else if (error.message.includes('permission denied')) { // RLS error
        setError('Permission Denied.\n\nPlease ensure Row Level Security (RLS) is enabled and the correct policies are in place. See `lib/supabaseClient.ts` for instructions.');
    } else if (error.message.includes('foreign key constraint')) {
        setError('Database relationship error.\n\nPlease ensure you have run the latest SQL script from `lib/supabaseClient.ts` to set up the rider assignment feature correctly.');
    } else {
        setError(`Failed to load data: ${error.message}.\n\nPlease check your internet connection and Supabase setup.`);
    }
    setLoading(false); // Ensure loading is stopped on error
  }

  const fetchData = async () => {
      setLoading(true);
      setError(null);
      
      const [submissionsRes, ridersRes, wholesaleOrdersRes] = await Promise.all([
          supabase.from('submissions').select('*, riders(*)').order('created_at', { ascending: false }),
          supabase.from('riders').select('*').order('created_at', { ascending: false }),
          supabase.from('wholesale_orders').select('*, wholesale_users(*), riders(name, contact_number)').order('created_at', { ascending: false })
      ]);

      if (submissionsRes.error) {
          console.error('Error fetching submissions:', submissionsRes.error);
          handleSupabaseError(submissionsRes.error);
          return;
      }
      if (ridersRes.error) {
          console.error('Error fetching riders:', ridersRes.error);
          handleSupabaseError(ridersRes.error);
          return;
      }
      if (wholesaleOrdersRes.error) {
          console.error('Error fetching wholesale orders:', wholesaleOrdersRes.error);
          handleSupabaseError(wholesaleOrdersRes.error);
          return;
      }
      
      setSubmissions(submissionsRes.data as Submission[] || []);
      setRiders(ridersRes.data as Rider[] || []);
      setWholesaleOrders(wholesaleOrdersRes.data as WholesaleOrder[] || []);
      setLoading(false);
  };

  useEffect(() => {
    fetchData();

    const submissionsChannel = supabase.channel('submissions-admin')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'submissions' }, () => fetchData())
      .subscribe();
      
    const wholesaleChannel = supabase.channel('wholesale-orders-admin')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'wholesale_orders' }, () => fetchData())
      .subscribe();

    return () => {
      supabase.removeChannel(submissionsChannel);
      supabase.removeChannel(wholesaleChannel);
    };
  }, []);
  
  const handleAssignRider = async (submissionId: number, riderId: number | null) => {
    const originalSubmissions = [...submissions];
    const rider = riderId ? riders.find(r => r.id === riderId) : null;

    // Optimistic UI update
    setSubmissions(prev => prev.map(s => s.id === submissionId ? { ...s, rider_id: riderId, riders: rider } : s));

    const { error } = await supabase
        .from('submissions')
        .update({ rider_id: riderId })
        .eq('id', submissionId);

    if (error) {
        alert(`Failed to assign rider: ${error.message}`);
        setSubmissions(originalSubmissions); // Revert on error
    }
  };

  const handleStatusChange = async (submissionId: number, newStatus: OrderStatus) => {
    const originalSubmissions = [...submissions];
    const submission = submissions.find(s => s.id === submissionId);
    if (!submission) return;

    // Optimistic UI update
    setSubmissions(prev => prev.map(s => s.id === submissionId ? { ...s, status: newStatus } : s));

    const { error } = await supabase
        .from('submissions')
        .update({ status: newStatus })
        .eq('id', submissionId);

    if (error) {
        alert(`Failed to update status: ${error.message}`);
        setSubmissions(originalSubmissions); // Revert on error
    } else {
        // WhatsApp Notification Logic
        const contactNumber = submission.customer_mobile;
        const riderName = submission.riders?.name;

        if (contactNumber) {
            let message = '';
            switch(newStatus) {
                case 'Processing':
                    message = `Hello ${submission.customer_name}! Your Jhelum Spices order #${submission.id} is now being processed. We'll notify you again once it's out for delivery.`;
                    break;
                case 'Out for Delivery':
                    const riderInfo = riderName ? ` with our rider, ${riderName}` : '';
                    message = `Great news from Jhelum Spices! Your order #${submission.id} is out for delivery${riderInfo}.`;
                    break;
                case 'Delivered':
                    message = `Hello ${submission.customer_name}, your Jhelum Spices order #${submission.id} has been delivered. Thank you for your business!`;
                    break;
                default:
                    // No message for other statuses
                    return;
            }

            const formattedNumber = contactNumber.startsWith('91') ? contactNumber : `91${contactNumber}`;
            const whatsappUrl = `https://wa.me/${formattedNumber}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank');
        }
    }
  };
  
  const handleWholesaleStatusChange = async (orderId: number, newStatus: WholesaleOrderStatus) => {
    const originalOrders = [...wholesaleOrders];
    const order = wholesaleOrders.find(o => o.id === orderId);
    if (!order) return;
    
    // Optimistic UI update
    setWholesaleOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));

    const { error } = await supabase
        .from('wholesale_orders')
        .update({ status: newStatus })
        .eq('id', orderId);

    if (error) {
        alert(`Failed to update wholesale order status: ${error.message}`);
        setWholesaleOrders(originalOrders); // Revert
    } else {
        // Send WhatsApp notification on success
        const contactNumber = order.wholesale_users?.contact_number;

        if (contactNumber) {
            let message = '';
            switch(newStatus) {
                case 'Confirmed':
                    message = `Hello ${order.wholesale_users?.business_name}! Your Jhelum Spices wholesale order #${order.id} has been confirmed. The total amount is ₹${order.total_amount.toLocaleString()}. We will notify you again once it is dispatched.`;
                    break;
                case 'Out for Delivery':
                     message = `Great news from Jhelum Spices! Your wholesale order #${order.id} is out for delivery.`;
                     break;
                case 'Delivered':
                    message = `Hello ${order.wholesale_users?.business_name}, your Jhelum Spices wholesale order #${order.id} has been delivered. Thank you for your business!`;
                    break;
                case 'Cancelled':
                    message = `Hello ${order.wholesale_users?.business_name}. We're writing to inform you that your Jhelum Spices wholesale order #${order.id} has been cancelled. Please contact us for further details.`;
                    break;
                default:
                    // No message for 'Pending'
                    return;
            }
            
            const formattedNumber = contactNumber.startsWith('91') ? contactNumber : `91${contactNumber}`;
            const whatsappUrl = `https://wa.me/${formattedNumber}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank');
        }
    }
  };

  const handleAssignWholesaleRider = async (orderId: number, riderId: number | null) => {
    const originalOrders = [...wholesaleOrders];
    const rider = riderId ? riders.find(r => r.id === riderId) : null;
    
    // Optimistic UI update
    setWholesaleOrders(prev => prev.map(o => o.id === orderId ? { ...o, rider_id: riderId, riders: rider ? { name: rider.name, contact_number: rider.contact_number } : null } : o));

    const { error } = await supabase
        .from('wholesale_orders')
        .update({ rider_id: riderId })
        .eq('id', orderId);

    if (error) {
        alert(`Failed to assign rider to wholesale order: ${error.message}`);
        setWholesaleOrders(originalOrders); // Revert
    }
  };

  const escapeCsvCell = (cell: any): string => {
      const str = String(cell == null ? '' : cell);
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
  };

  const handleDownloadRetailCsv = () => {
    const retailOrders = submissions.filter(s => s.type === 'Retail Order');
    if (retailOrders.length === 0) return;

    const headers = [
        'ID', 'Type', 'Timestamp', 'Status', 'Rider Name', 'Customer Name', 'Customer Mobile', 
        'Address', 'Pincode', 'Total Amount', 'Payment Method', 'Transaction ID', 'Order Details',
    ];
    
    const rows = retailOrders.map(s => {
        const row = [
            s.id, s.type, new Date(s.created_at).toISOString(), s.status || 'N/A', s.riders?.name || 'Unassigned',
            s.customer_name || '', s.customer_mobile || '', s.customer_address || '', s.customer_pincode || '',
            s.total_amount || '', s.payment_method || '', s.transaction_id || '',
            s.message || '',
        ];
        return row.map(escapeCsvCell).join(',');
    });

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `jhelum_spices_retail_orders_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadWholesaleCsv = () => {
    if (wholesaleOrders.length === 0) return;
    
    const headers = [
      'Order ID', 'Timestamp', 'Business Name', 'Contact Number', 'Total Units', 'Total Amount', 'Status', 'Rider Name', 'Order Details'
    ];

    const rows = wholesaleOrders.map(o => {
      const row = [
        o.id, new Date(o.created_at).toISOString(), o.wholesale_users?.business_name || 'N/A', 
        o.wholesale_users?.contact_number || 'N/A', o.total_units, o.total_amount, o.status, o.riders?.name || 'Unassigned',
        o.order_details || ''
      ];
      return row.map(escapeCsvCell).join(',');
    });

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `jhelum_spices_wholesale_orders_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const handleDownloadWazwanCsv = () => {
    const wazwanEnquiries = submissions.filter(s => s.type === 'Wazwan Enquiry');
    if (wazwanEnquiries.length === 0) return;

    const headers = [
      'Enquiry ID', 'Timestamp', 'Customer Name', 'Customer Mobile', 'Event Date', 'Event Location', 'Delivery Address', 'Event Size (Guests)', 'Enquiry Details'
    ];
    
    const extractDetail = (message: string, regex: RegExp) => (message.match(regex) || [])[1] || 'N/A';

    const rows = wazwanEnquiries.map(s => {
        const row = [
            s.id, new Date(s.created_at).toISOString(),
            extractDetail(s.message, /\*Name:\* (.+)/m),
            extractDetail(s.message, /\*Mobile:\* (.+)/m),
            extractDetail(s.message, /\*Event Date:\* (.+)/m),
            extractDetail(s.message, /\*Event Location:\* (.+)/m),
            extractDetail(s.message, /\*Address:\* (.+)/m),
            extractDetail(s.message, /\*Event Size:\*\nApprox\. \*(.+?)\* Trami \/ Guests\./m),
            s.message || ''
        ];
        return row.map(escapeCsvCell).join(',');
    });

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `jhelum_spices_wazwan_enquiries_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const hasRetailOrders = useMemo(() => submissions.some(s => s.type === 'Retail Order'), [submissions]);
  const hasWazwanEnquiries = useMemo(() => submissions.some(s => s.type === 'Wazwan Enquiry'), [submissions]);


  const renderSubmissions = () => {
    return (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Submission</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Type</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Rider</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {submissions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-4 text-center text-sm text-gray-500">
                    No submissions found yet.
                  </td>
                </tr>
              ) : (
                submissions.map((submission) => (
                  <React.Fragment key={submission.id}>
                    <tr>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 align-top">
                        <div className="font-semibold text-gray-800">#{submission.id}</div>
                        <div>{new Date(submission.created_at).toLocaleString()}</div>
                      </td>
                      <td className="px-4 py-3 align-top">
                        <TypeBadge type={submission.type} />
                      </td>
                      <td className="px-4 py-3 align-top">
                        {submission.type === 'Retail Order' ? (
                            <select
                                value={submission.rider_id || ''}
                                onChange={(e) => handleAssignRider(submission.id, e.target.value ? parseInt(e.target.value) : null)}
                                className="block w-full text-sm border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                            >
                                <option value="">Unassigned</option>
                                {riders.map(rider => <option key={rider.id} value={rider.id}>{rider.name}</option>)}
                            </select>
                        ) : 'N/A'}
                      </td>
                      <td className="px-4 py-3 align-top">
                        {submission.type === 'Retail Order' && submission.status ? (
                            <select
                                value={submission.status}
                                onChange={(e) => handleStatusChange(submission.id, e.target.value as OrderStatus)}
                                className="block w-full text-sm border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                            >
                                {orderStatusOptions.map(status => <option key={status} value={status}>{status}</option>)}
                            </select>
                        ) : 'N/A'}
                      </td>
                      <td className="px-4 py-3 align-top text-center">
                        <button
                          onClick={() => setExpandedId(expandedId === submission.id ? null : submission.id)}
                          className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          {expandedId === submission.id ? 'Hide' : 'Show'} Message
                        </button>
                      </td>
                    </tr>
                    {expandedId === submission.id && (
                      <tr className="bg-gray-50">
                        <td colSpan={5} className="px-4 py-3 text-sm text-gray-800">
                          <h4 className="font-semibold mb-2">Full Message:</h4>
                          <pre className="whitespace-pre-wrap font-sans bg-white p-3 rounded-md border">{submission.message}</pre>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>
    );
  }

  const renderWholesaleOrders = () => {
    return (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Order</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Details</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Rider</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {wholesaleOrders.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-4 text-center text-sm text-gray-500">
                    No wholesale orders found yet.
                  </td>
                </tr>
              ) : (
                wholesaleOrders.map((order) => (
                  <React.Fragment key={order.id}>
                    <tr>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 align-top">
                        <div className="font-semibold text-gray-800">#{order.id}</div>
                        <div>{new Date(order.created_at).toLocaleString()}</div>
                      </td>
                      <td className="px-4 py-3 align-top text-sm">
                        <p className="font-semibold text-gray-800">{order.wholesale_users?.business_name || 'N/A'}</p>
                        <p>Units: <span className="font-medium">{order.total_units}</span></p>
                        <p>Total: <span className="font-medium">₹{order.total_amount.toLocaleString()}</span></p>
                      </td>
                       <td className="px-4 py-3 align-top">
                         <select
                            value={order.rider_id || ''}
                            onChange={(e) => handleAssignWholesaleRider(order.id, e.target.value ? parseInt(e.target.value) : null)}
                            className="block w-full text-sm border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        >
                            <option value="">Unassigned</option>
                            {riders.map(rider => <option key={rider.id} value={rider.id}>{rider.name}</option>)}
                        </select>
                       </td>
                       <td className="px-4 py-3 align-top">
                         <select
                            value={order.status}
                            onChange={(e) => handleWholesaleStatusChange(order.id, e.target.value as WholesaleOrderStatus)}
                            className="block w-full text-sm border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        >
                            {wholesaleStatusOptions.map(status => <option key={status} value={status}>{status}</option>)}
                        </select>
                       </td>
                      <td className="px-4 py-3 align-top text-center">
                        <button
                          onClick={() => setExpandedId(expandedId === order.id ? null : order.id)}
                          className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          {expandedId === order.id ? 'Hide' : 'Show'} Details
                        </button>
                      </td>
                    </tr>
                    {expandedId === order.id && (
                      <tr className="bg-gray-50">
                        <td colSpan={5} className="px-4 py-3 text-sm text-gray-800">
                          <h4 className="font-semibold mb-2">Full Order Details:</h4>
                          <pre className="whitespace-pre-wrap font-sans bg-white p-3 rounded-md border">{order.order_details}</pre>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <Header title="Admin Dashboard" onBack={onBack} hideLanguageSwitcher />
      <main className="flex-grow overflow-y-auto p-4 space-y-8">
        <div>
            <div className="flex justify-between items-center mb-4 gap-4 flex-wrap">
                <h2 className="text-xl font-bold text-gray-800">Management Center</h2>
                <div className="flex flex-wrap gap-2">
                    <button onClick={onGoToManageWholesale} className="bg-purple-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors text-sm">Manage Wholesale Users</button>
                    <button onClick={onGoToManageRiders} className="bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors text-sm">Manage Riders</button>
                    <button onClick={onGoToReports} className="bg-teal-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-teal-700 transition-colors text-sm">View Sales Reports</button>
                </div>
            </div>
            
             <div className="border-b border-gray-200">
                <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                    <button onClick={() => setCurrentView('submissions')} className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm ${currentView === 'submissions' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                        All Submissions
                    </button>
                    <button onClick={() => setCurrentView('wholesale')} className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm ${currentView === 'wholesale' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                        Wholesale Orders
                    </button>
                </nav>
            </div>
            
             <div className="mt-4 flex flex-wrap gap-2">
                {currentView === 'submissions' && (
                    <>
                        <button onClick={handleDownloadRetailCsv} className="bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm disabled:bg-gray-400" disabled={!hasRetailOrders}>Download Retail CSV</button>
                        <button onClick={handleDownloadWazwanCsv} className="bg-amber-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-amber-700 transition-colors text-sm disabled:bg-gray-400" disabled={!hasWazwanEnquiries}>Download Wazwan CSV</button>
                    </>
                )}
                {currentView === 'wholesale' && (
                    <button onClick={handleDownloadWholesaleCsv} className="bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm disabled:bg-gray-400" disabled={wholesaleOrders.length === 0}>Download Wholesale CSV</button>
                )}
            </div>
            
            <div className="mt-4">
                {loading ? <div className="text-center p-4">Loading...</div> : error ? <div className="text-center p-4 text-red-600 bg-red-50 rounded-lg whitespace-pre-wrap">{error}</div> : (currentView === 'submissions' ? renderSubmissions() : renderWholesaleOrders())}
            </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboardScreen;